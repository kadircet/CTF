// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;


// Referenced classes of package com.ego.android:
//            R

public static final class 
{

    public static final int abb_logo = 0x7f020000;
    public static final int action_bg = 0x7f020001;
    public static final int action_bg_select = 0x7f020002;
    public static final int action_bg_selector = 0x7f020003;
    public static final int add = 0x7f020004;
    public static final int airport = 0x7f020005;
    public static final int alarm = 0x7f020006;
    public static final int ankaray = 0x7f020007;
    public static final int ara = 0x7f020008;
    public static final int asti = 0x7f020009;
    public static final int back = 0x7f02000a;
    public static final int balloon_overlay_bg_selector = 0x7f02000b;
    public static final int balloon_overlay_close = 0x7f02000c;
    public static final int balloon_overlay_focused = 0x7f02000d;
    public static final int balloon_overlay_unfocused = 0x7f02000e;
    public static final int bg = 0x7f02000f;
    public static final int border = 0x7f020010;
    public static final int bus = 0x7f020011;
    public static final int bus_black = 0x7f020012;
    public static final int bus_ego = 0x7f020013;
    public static final int bus_ego_0 = 0x7f020014;
    public static final int bus_ego_1 = 0x7f020015;
    public static final int bus_ego_2 = 0x7f020016;
    public static final int bus_ego_3 = 0x7f020017;
    public static final int bus_ego_4 = 0x7f020018;
    public static final int bus_ego_5 = 0x7f020019;
    public static final int bus_ego_6 = 0x7f02001a;
    public static final int bus_ego_7 = 0x7f02001b;
    public static final int bus_ego_zemin = 0x7f02001c;
    public static final int bus_stop = 0x7f02001d;
    public static final int bus_stop_black = 0x7f02001e;
    public static final int bus_stop_map = 0x7f02001f;
    public static final int bus_stop_red = 0x7f020020;
    public static final int bus_stop_white = 0x7f020021;
    public static final int bus_stop_zemin = 0x7f020022;
    public static final int bus_white = 0x7f020023;
    public static final int cell_btn_bg = 0x7f020024;
    public static final int cell_btn_bg_select = 0x7f020025;
    public static final int cell_btn_bg_selector = 0x7f020026;
    public static final int check = 0x7f020027;
    public static final int check_big = 0x7f020028;
    public static final int clock = 0x7f020029;
    public static final int clock_black = 0x7f02002a;
    public static final int clock_white = 0x7f02002b;
    public static final int close = 0x7f02002c;
    public static final int delete = 0x7f02002d;
    public static final int download = 0x7f02002e;
    public static final int durak = 0x7f02002f;
    public static final int ego = 0x7f020030;
    public static final int ego_logo = 0x7f020031;
    public static final int email = 0x7f020032;
    public static final int favs = 0x7f020033;
    public static final int flag = 0x7f020034;
    public static final int flag_black = 0x7f020035;
    public static final int flag_white = 0x7f020036;
    public static final int hat = 0x7f020037;
    public static final int home = 0x7f020038;
    public static final int home_black = 0x7f020039;
    public static final int home_white = 0x7f02003a;
    public static final int ic_launcher = 0x7f02003b;
    public static final int image = 0x7f02003c;
    public static final int image_black = 0x7f02003d;
    public static final int image_white = 0x7f02003e;
    public static final int konum = 0x7f02003f;
    public static final int location = 0x7f020040;
    public static final int location_black = 0x7f020041;
    public static final int location_white = 0x7f020042;
    public static final int map = 0x7f020043;
    public static final int map_black = 0x7f020044;
    public static final int map_white = 0x7f020045;
    public static final int menu_abb = 0x7f020046;
    public static final int menu_adresara = 0x7f020047;
    public static final int menu_adresara_img = 0x7f020048;
    public static final int menu_bg_blue = 0x7f020049;
    public static final int menu_bg_blue_select = 0x7f02004a;
    public static final int menu_bg_blue_selector = 0x7f02004b;
    public static final int menu_bg_white = 0x7f02004c;
    public static final int menu_bg_white_select = 0x7f02004d;
    public static final int menu_bg_white_selector = 0x7f02004e;
    public static final int menu_cikis = 0x7f02004f;
    public static final int menu_duyurular = 0x7f020050;
    public static final int menu_duyurular_img = 0x7f020051;
    public static final int menu_ego = 0x7f020052;
    public static final int menu_favorilerim = 0x7f020053;
    public static final int menu_favorilerim_img = 0x7f020054;
    public static final int menu_hatara = 0x7f020055;
    public static final int menu_hatara_img = 0x7f020056;
    public static final int menu_nasilgiderim = 0x7f020057;
    public static final int menu_nasilgiderim_img = 0x7f020058;
    public static final int menu_neredeyim = 0x7f020059;
    public static final int menu_neredeyim_img = 0x7f02005a;
    public static final int menu_onemliyerler = 0x7f02005b;
    public static final int menu_onemliyerler_img = 0x7f02005c;
    public static final int menu_otobusnerede = 0x7f02005d;
    public static final int menu_otobusnerede_img = 0x7f02005e;
    public static final int menu_sorunbildir = 0x7f02005f;
    public static final int menu_sorunbildir_img = 0x7f020060;
    public static final int metro = 0x7f020061;
    public static final int minus = 0x7f020062;
    public static final int otobus = 0x7f020063;
    public static final int panel = 0x7f020064;
    public static final int pause = 0x7f020065;
    public static final int pin = 0x7f020066;
    public static final int pin_location = 0x7f020067;
    public static final int pin_select = 0x7f020068;
    public static final int pin_zemin_kirmizi = 0x7f020069;
    public static final int pin_zemin_yesil = 0x7f02006a;
    public static final int play = 0x7f02006b;
    public static final int play_white = 0x7f02006c;
    public static final int progress_style = 0x7f02006d;
    public static final int refresh = 0x7f02006e;
    public static final int refresh_big = 0x7f02006f;
    public static final int save = 0x7f020070;
    public static final int search = 0x7f020071;
    public static final int search_black = 0x7f020072;
    public static final int search_white = 0x7f020073;
    public static final int settings = 0x7f020074;
    public static final int shuffle_black = 0x7f020075;
    public static final int shuffle_white = 0x7f020076;
    public static final int sorgula = 0x7f020077;
    public static final int star_black = 0x7f020078;
    public static final int star_white = 0x7f020079;
    public static final int toolbar_bg = 0x7f02007a;
    public static final int toolbar_bg_select = 0x7f02007b;
    public static final int toolbar_bg_selector = 0x7f02007c;
    public static final int train = 0x7f02007d;
    public static final int yakinlik = 0x7f02007e;

    public ()
    {
    }
}
