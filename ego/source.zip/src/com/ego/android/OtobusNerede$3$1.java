// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.os.Handler;
import android.text.Editable;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            OtobusNerede, Global, Http

class this._cls1
    implements this._cls1
{

    final on this$1;

    public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
    {
        Action(s, s1, i, boolean1, s2);
    }

    is._cls0()
    {
        this$1 = this._cls1.this;
        super();
    }

    // Unreferenced inner class com/ego/android/OtobusNerede$3

/* anonymous class */
    class OtobusNerede._cls3
        implements Runnable
    {

        final OtobusNerede this$0;

        public void run()
        {
label0:
            {
                try
                {
                    handler.removeCallbacks(handlerRunnable);
                }
                catch (Exception exception) { }
                if (handlerStatus)
                {
                    handlerStatus = false;
                    CloseKeyboard();
                    String s = ((EditText)findViewById(0x7f090000)).getText().toString();
                    if (s.length() < 5)
                    {
                        break label0;
                    }
                    Global.App_Durak_Ara = ((EditText)findViewById(0x7f090000)).getText().toString();
                    Boolean boolean1 = Boolean.valueOf(((CheckBox)findViewById(0x7f090001)).isChecked());
                    OtobusNerede otobusnerede;
                    String as[];
                    String as1[];
                    if (boolean1.booleanValue())
                    {
                        ((LinearLayout)findViewById(0x7f090064)).setVisibility(0);
                    } else
                    {
                        ((LinearLayout)findViewById(0x7f090064)).setVisibility(8);
                    }
                    otobusnerede = OtobusNerede.this;
                    as = (new String[] {
                        "FNC", "DurakAra"
                    });
                    as1 = new String[4];
                    as1[0] = "QUERY";
                    as1[1] = s;
                    as1[2] = "TYPE";
                    as1[3] = boolean1.toString();
                    otobusnerede.http = new Http("DurakAra", "durak.asp", as, as1);
                    http.addObserver(new OtobusNerede._cls3._cls1());
                    dialog.show();
                    http.execute(new String[0]);
                }
                return;
            }
            Toast.makeText(getBaseContext(), "Durak Numaras\u0131\nEn Az 5 Basamakl\u0131 Say\u0131 Olmal\u0131!", 1).show();
        }


            
            {
                this$0 = OtobusNerede.this;
                super();
            }
    }

}
