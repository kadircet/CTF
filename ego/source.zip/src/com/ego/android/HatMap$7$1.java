// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.os.Handler;

// Referenced classes of package com.ego.android:
//            HatMap, Global, Http

class this._cls1
    implements ck
{

    final on this$1;

    public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
    {
        Action(s, s1, i, boolean1, s2);
    }

    is._cls0()
    {
        this$1 = this._cls1.this;
        super();
    }

    // Unreferenced inner class com/ego/android/HatMap$7

/* anonymous class */
    class HatMap._cls7
        implements Runnable
    {

        final HatMap this$0;

        public void run()
        {
            try
            {
                handler.removeCallbacks(handlerRunnable);
            }
            catch (Exception exception) { }
            if (handlerStatus)
            {
                handlerStatus = false;
                HatMap hatmap = HatMap.this;
                String as[] = {
                    "FNC", "OtobusAra"
                };
                String as1[] = new String[4];
                as1[0] = "QUERY";
                as1[1] = Global.App_Hat_No;
                as1[2] = "DURAK";
                as1[3] = Global.App_Durak_No;
                hatmap.http = new Http("OtobusAra", "hat.asp", as, as1);
                http.addObserver(new HatMap._cls7._cls1());
                http.execute(new String[0]);
            }
        }


            
            {
                this$0 = HatMap.this;
                super();
            }
    }

}
