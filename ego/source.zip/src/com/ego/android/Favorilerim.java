// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, Global, ListAdapterBtn, Tools, 
//            FavorilerimDurakDuzenle, FavorilerimHatDuzenle, OtobusNerede, HatBilgileri

public class Favorilerim extends Activity
{

    ProgressDialog dialog;
    Http httpDurak;
    Http httpHat;
    public TabHost tabhost;

    public Favorilerim()
    {
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        ListView listview;
        ArrayList arraylist;
        HashMap hashmap;
        Exception exception1;
        int j;
        HashMap hashmap1;
        Exception exception2;
        int k;
        String s3;
        String s4;
        HashMap hashmap2;
        ListView listview1;
        ArrayList arraylist1;
        HashMap hashmap3;
        Exception exception3;
        int l;
        HashMap hashmap4;
        Exception exception4;
        int i1;
        String s5;
        String s6;
        HashMap hashmap5;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Durak")) goto _L4; else goto _L3
_L3:
        listview1 = (ListView)findViewById(0x7f090033);
        arraylist1 = new ArrayList();
        hashmap3 = new HashMap();
        Global.durakArray = httpDurak.jArray;
        l = 0;
        hashmap4 = hashmap3;
_L11:
        i1 = httpDurak.jArray.length();
        if (l < i1) goto _L6; else goto _L5
_L5:
        hashmap4;
_L16:
        listview1.setAdapter(new ListAdapterBtn(this, arraylist1, 0x7f030018, new String[] {
            "no", "tanim", "aciklama", "btn"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048, 0x7f090047
        }, Boolean.valueOf(true)));
        listview1.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final Favorilerim this$0;

            public void onItemClick(AdapterView adapterview, View view, int j1, long l1)
            {
                Global.App_Durak_No = (String)((HashMap)((ListView)findViewById(0x7f090033)).getItemAtPosition(j1)).get("no");
                Intent intent = new Intent(getBaseContext(), com/ego/android/OtobusNerede);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = Favorilerim.this;
                super();
            }
        });
        listview1.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final Favorilerim this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int j1, long l1)
            {
                Global.App_Favorilerim_Durak_No = (String)((HashMap)((ListView)findViewById(0x7f090033)).getItemAtPosition(j1)).get("no");
                Intent intent = new Intent(getBaseContext(), com/ego/android/FavorilerimDurakDuzenle);
                startActivityForResult(intent, 0);
                return true;
            }

            
            {
                this$0 = Favorilerim.this;
                super();
            }
        });
_L4:
        if (!s.equals("Hat")) goto _L8; else goto _L7
_L7:
        listview = (ListView)findViewById(0x7f09002a);
        arraylist = new ArrayList();
        hashmap = new HashMap();
        Global.hatArray = httpHat.jArray;
        j = 0;
        hashmap1 = hashmap;
_L13:
        k = httpHat.jArray.length();
        if (j < k) goto _L10; else goto _L9
_L9:
        hashmap1;
_L15:
        listview.setAdapter(new ListAdapterBtn(this, arraylist, 0x7f03001b, new String[] {
            "no", "tanim", "aciklama", "btn"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048, 0x7f090047
        }, Boolean.valueOf(true)));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final Favorilerim this$0;

            public void onItemClick(AdapterView adapterview, View view, int j1, long l1)
            {
                Global.App_Hat_No = (String)((HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(j1)).get("no");
                Global.App_Durak_No = "";
                Global.App_Otobus_No = "";
                Intent intent = new Intent(getBaseContext(), com/ego/android/HatBilgileri);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = Favorilerim.this;
                super();
            }
        });
        listview.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final Favorilerim this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int j1, long l1)
            {
                Global.App_Favorilerim_Hat_No = (String)((HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(j1)).get("no");
                Intent intent = new Intent(getBaseContext(), com/ego/android/FavorilerimHatDuzenle);
                startActivityForResult(intent, 0);
                return true;
            }

            
            {
                this$0 = Favorilerim.this;
                super();
            }
        });
_L8:
        return;
_L6:
        String as1[] = httpDurak.JValue(l, "aciklama").replace("|", ";").split(";");
        s5 = as1[0];
        if (as1.length <= 1)
        {
            break MISSING_BLOCK_LABEL_546;
        }
        s6 = as1[1];
_L12:
        hashmap5 = new HashMap();
        hashmap5.put("id", (new StringBuilder()).append(l).toString());
        hashmap5.put("no", httpDurak.JValue(l, "no"));
        hashmap5.put("tanim", httpDurak.JValue(l, "tanim"));
        hashmap5.put("aciklama", s5);
        hashmap5.put("bgcolor", Tools.ToColor(s6));
        hashmap5.put("btn", (new StringBuilder("Durak;")).append(httpDurak.JValue(l, "no")).toString());
        arraylist1.add(hashmap5);
        l++;
        hashmap4 = hashmap5;
          goto _L11
        s6 = "";
          goto _L12
_L10:
        String as[] = httpHat.JValue(j, "aciklama").replace("|", ";").split(";");
        s3 = as[0];
        if (as.length <= 1)
        {
            break MISSING_BLOCK_LABEL_742;
        }
        s4 = as[1];
_L14:
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(j).toString());
        hashmap2.put("no", httpHat.JValue(j, "no"));
        hashmap2.put("tanim", httpHat.JValue(j, "tanim"));
        hashmap2.put("aciklama", s3);
        hashmap2.put("bgcolor", Tools.ToColor(s4));
        hashmap2.put("btn", (new StringBuilder("Hat;")).append(httpHat.JValue(j, "no")).toString());
        arraylist.add(hashmap2);
        j++;
        hashmap1 = hashmap2;
          goto _L13
        s4 = "";
          goto _L14
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
          goto _L13
        exception1;
          goto _L15
        exception2;
        hashmap1;
          goto _L15
        exception3;
          goto _L16
        exception4;
        hashmap4;
          goto _L16
    }

    public void DurakYenile()
    {
        String as[] = {
            "FNC", "FavoriAra"
        };
        String as1[] = new String[4];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        as1[2] = "TIP";
        as1[3] = "Durak";
        httpDurak = new Http("Durak", "favori.asp", as, as1);
        httpDurak.addObserver(new Http.Callback() {

            final Favorilerim this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = Favorilerim.this;
                super();
            }
        });
        dialog.show();
        if (Global.durakArray == null)
        {
            httpDurak.execute(new String[0]);
            return;
        } else
        {
            httpDurak.jArray = Global.durakArray;
            Action("Durak", null, 200, null, null);
            return;
        }
    }

    public void Ekle()
    {
        if (tabhost.getCurrentTab() == 0)
        {
            Global.App_Favorilerim_Durak_No = "";
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimDurakDuzenle), 0);
        }
        if (tabhost.getCurrentTab() == 1)
        {
            Global.App_Favorilerim_Hat_No = "";
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimHatDuzenle), 0);
        }
    }

    public void HatYenile()
    {
        String as[] = {
            "FNC", "FavoriAra"
        };
        String as1[] = new String[4];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        as1[2] = "TIP";
        as1[3] = "Hat";
        httpHat = new Http("Hat", "favori.asp", as, as1);
        httpHat.addObserver(new Http.Callback() {

            final Favorilerim this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = Favorilerim.this;
                super();
            }
        });
        dialog.show();
        if (Global.hatArray == null)
        {
            httpHat.execute(new String[0]);
            return;
        } else
        {
            httpHat.jArray = Global.hatArray;
            Action("Hat", null, 200, null, null);
            return;
        }
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        try
        {
            String as[] = s.split(";");
            if (as[0].equals("Durak"))
            {
                Global.App_Favorilerim_Durak_No = as[1];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimDurakDuzenle), 0);
            }
            if (as[0].equals("Hat"))
            {
                Global.App_Favorilerim_Hat_No = as[1];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimHatDuzenle), 0);
            }
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Ekle();
                return;
            }
            if (!s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (!Global.App_Favorilerim_Durak_Yenile.equals(""))
        {
            DurakYenile();
        }
        if (!Global.App_Favorilerim_Hat_Yenile.equals(""))
        {
            HatYenile();
        }
        Global.App_Favorilerim_Durak_Yenile = "";
        Global.App_Favorilerim_Hat_Yenile = "";
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03000a);
        dialog = Tools.Waiting(this);
        tabhost = (TabHost)findViewById(0x7f090031);
        tabhost.setup();
        android.widget.TabHost.TabSpec tabspec = tabhost.newTabSpec("Tab1");
        tabspec.setIndicator("Duraklar", getResources().getDrawable(0x7f02002f));
        tabspec.setContent(0x7f090032);
        tabhost.addTab(tabspec);
        android.widget.TabHost.TabSpec tabspec1 = tabhost.newTabSpec("Tab2");
        tabspec1.setIndicator("Hatlar", getResources().getDrawable(0x7f020037));
        tabspec1.setContent(0x7f090034);
        tabhost.addTab(tabspec1);
        tabhost.setCurrentTab(0);
        tabhost.getTabWidget().getChildAt(0).setOnClickListener(new android.view.View.OnClickListener() {

            final Favorilerim this$0;

            public void onClick(View view)
            {
                tabhost.setCurrentTab(0);
            }

            
            {
                this$0 = Favorilerim.this;
                super();
            }
        });
        tabhost.getTabWidget().getChildAt(1).setOnClickListener(new android.view.View.OnClickListener() {

            final Favorilerim this$0;

            public void onClick(View view)
            {
                tabhost.setCurrentTab(1);
            }

            
            {
                this$0 = Favorilerim.this;
                super();
            }
        });
        Global.App_Favorilerim_Durak_No = "";
        Global.App_Favorilerim_Durak_Yenile = "";
        Global.App_Favorilerim_Hat_No = "";
        Global.App_Favorilerim_Hat_Yenile = "";
        DurakYenile();
        HatYenile();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
