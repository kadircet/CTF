// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.ego.android:
//            Http, ListAdapterBtn, Global, KonumMap, 
//            Tools

public class HatDuraklar extends Activity
{

    ProgressDialog dialog;
    Http http;

    public HatDuraklar()
    {
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        ListView listview;
        ArrayList arraylist;
        HashMap hashmap;
        Exception exception1;
        JSONArray jsonarray;
        int j;
        HashMap hashmap1;
        Exception exception2;
        int k;
        JSONObject jsonobject;
        HashMap hashmap2;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Hat")) goto _L4; else goto _L3
_L3:
        ((TextView)findViewById(0x7f090035)).setText(http.JValue(0, "kod"));
        ((TextView)findViewById(0x7f09003a)).setText(http.JValue(0, "ad"));
        ((TextView)findViewById(0x7f09003b)).setText(http.JValue(0, "sure"));
        ((TextView)findViewById(0x7f09003c)).setText(http.JValue(0, "mesafe"));
        listview = (ListView)findViewById(0x7f090033);
        arraylist = new ArrayList();
        hashmap = new HashMap();
        jsonarray = http.JArray(0, "durak");
        j = 0;
        hashmap1 = hashmap;
_L7:
        k = jsonarray.length();
        if (j < k) goto _L6; else goto _L5
_L5:
        hashmap1;
_L8:
        listview.setAdapter(new ListAdapterBtn(this, arraylist, 0x7f030018, new String[] {
            "ad", "yer", "aciklama", "btn"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048, 0x7f090047
        }));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final HatDuraklar this$0;

            public void onItemClick(AdapterView adapterview, View view, int l, long l1)
            {
                HashMap hashmap3 = (HashMap)((ListView)findViewById(0x7f090033)).getItemAtPosition(l);
                Global.App_Adres_Sec = "DurakAra";
                Global.App_Durak_No = (String)hashmap3.get("ad");
                Global.App_Durak_Tanim = (String)hashmap3.get("yer");
                Intent intent = new Intent();
                setResult(10, intent);
                finish();
            }

            
            {
                this$0 = HatDuraklar.this;
                super();
            }
        });
        listview.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final HatDuraklar this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int l, long l1)
            {
                HashMap hashmap3 = (HashMap)((ListView)findViewById(0x7f090033)).getItemAtPosition(l);
                Global.App_Konum = (new StringBuilder("Durak ")).append((String)hashmap3.get("ad")).toString();
                Global.App_Konum_Adres = (String)hashmap3.get("yer");
                Global.App_Konum_Ilce = "-";
                Global.App_Konum_Lat = (String)hashmap3.get("lat");
                Global.App_Konum_Lng = (String)hashmap3.get("lng");
                Global.App_Konum_Durak_No = (String)hashmap3.get("ad");
                Global.App_Konum_Durak_Tanim = (String)hashmap3.get("yer");
                Intent intent = new Intent(getBaseContext(), com/ego/android/KonumMap);
                startActivityForResult(intent, 0);
                return true;
            }

            
            {
                this$0 = HatDuraklar.this;
                super();
            }
        });
_L4:
        return;
_L6:
        jsonobject = jsonarray.getJSONObject(j);
        hashmap2 = new HashMap();
        hashmap2.put("ad", jsonobject.getString("ad"));
        hashmap2.put("yer", jsonobject.getString("yer"));
        hashmap2.put("lat", jsonobject.getString("lat"));
        hashmap2.put("lng", jsonobject.getString("lng"));
        hashmap2.put("aciklama", jsonobject.getString("aciklama"));
        hashmap2.put("btn", (new StringBuilder("Durak;")).append(jsonobject.getString("ad")).append(";").append(jsonobject.getString("yer")).append(";").append(jsonobject.getString("lat")).append(";").append(jsonobject.getString("lng")).toString());
        arraylist.add(hashmap2);
        j++;
        hashmap1 = hashmap2;
          goto _L7
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception1;
          goto _L8
        exception2;
        hashmap1;
          goto _L8
    }

    public void HatYenile()
    {
        String as[] = {
            "FNC", "Hat"
        };
        String as1[] = new String[2];
        as1[0] = "QUERY";
        as1[1] = Global.App_Hat_No;
        http = new Http("Hat", "hat.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final HatDuraklar this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = HatDuraklar.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        try
        {
            String as[] = s.split(";");
            if (as[0].equals("Durak"))
            {
                Global.App_Konum = (new StringBuilder("Durak ")).append(as[1]).toString();
                Global.App_Konum_Adres = as[2];
                Global.App_Konum_Ilce = "-";
                Global.App_Konum_Lat = as[3];
                Global.App_Konum_Lng = as[4];
                Global.App_Konum_Durak_No = as[1];
                Global.App_Konum_Durak_Tanim = as[2];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/KonumMap), 0);
            }
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (!s.equals("2") && !s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030011);
        dialog = Tools.Waiting(this);
        ((TextView)findViewById(0x7f090035)).setText(Global.App_Hat_No);
        ((TextView)findViewById(0x7f09003a)).setText(Global.App_Hat_Tanim);
        HatYenile();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
