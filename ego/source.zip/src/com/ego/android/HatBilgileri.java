// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.ego.android:
//            Http, ListAdapter, ListAdapterBtn, Global, 
//            HatMap, KonumMap, FavorilerimHatDuzenle, Tools, 
//            OtobusNeredeMap

public class HatBilgileri extends Activity
{

    int SeciliDurak;
    int SeciliOtobus;
    ProgressDialog dialog;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    boolean pageStatus;
    public TabHost tabhost;

    public HatBilgileri()
    {
        pageStatus = false;
        handler = new Handler();
        handlerStatus = false;
        SeciliDurak = -1;
        SeciliOtobus = -1;
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        Exception exception1;
        ListView listview;
        ArrayList arraylist;
        HashMap hashmap;
        int j;
        Exception exception2;
        ListAdapter listadapter;
        JSONArray jsonarray;
        int k;
        HashMap hashmap1;
        Exception exception3;
        int l;
        JSONObject jsonobject;
        HashMap hashmap2;
        ListView listview1;
        ArrayList arraylist1;
        HashMap hashmap3;
        Exception exception4;
        ListView listview2;
        ArrayList arraylist2;
        HashMap hashmap4;
        Exception exception5;
        JSONArray jsonarray1;
        int i1;
        HashMap hashmap5;
        Exception exception6;
        int j1;
        JSONObject jsonobject1;
        HashMap hashmap6;
        JSONArray jsonarray2;
        int k1;
        HashMap hashmap7;
        Exception exception7;
        int l1;
        JSONObject jsonobject2;
        HashMap hashmap8;
        String s3;
        String s4;
        String s5;
        String s6;
        String s7;
        String s8;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        handlerStop();
        if (pageStatus) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if (i != 200) goto _L4; else goto _L3
_L3:
        if (!s.equals("Hat"))
        {
            continue; /* Loop/switch isn't completed */
        }
        ((TextView)findViewById(0x7f090035)).setText(http.JValue(0, "kod"));
        ((TextView)findViewById(0x7f09003a)).setText(http.JValue(0, "ad"));
        ((TextView)findViewById(0x7f09003b)).setText(http.JValue(0, "sure"));
        ((TextView)findViewById(0x7f09003c)).setText(http.JValue(0, "mesafe"));
        listview1 = (ListView)findViewById(0x7f09003d);
        arraylist1 = new ArrayList();
        hashmap3 = new HashMap();
        jsonarray2 = http.JArray(0, "saat");
        k1 = 0;
        hashmap7 = hashmap3;
_L15:
        l1 = jsonarray2.length();
        if (k1 < l1) goto _L6; else goto _L5
_L5:
        hashmap7;
_L22:
        try
        {
            listview1.setAdapter(new ListAdapter(this, arraylist1, 0x7f03001e, new String[] {
                "his", "hia", "cms", "cma", "pzs", "pza"
            }, new int[] {
                0x7f090045, 0x7f09004c, 0x7f090046, 0x7f09004d, 0x7f090048, 0x7f09004e
            }));
            listview2 = (ListView)findViewById(0x7f090033);
            arraylist2 = new ArrayList();
            hashmap4 = new HashMap();
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception1)
        {
            return;
        }
        SeciliDurak = -1;
        jsonarray1 = http.JArray(0, "durak");
        i1 = 0;
        hashmap5 = hashmap4;
_L16:
        j1 = jsonarray1.length();
        if (i1 < j1) goto _L8; else goto _L7
_L7:
        hashmap5;
_L18:
        listview2.setAdapter(new ListAdapterBtn(this, arraylist2, 0x7f030018, new String[] {
            "ad", "yer", "aciklama", "btn"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048, 0x7f090047
        }, Boolean.valueOf(true)));
        if (SeciliDurak > -1)
        {
            listview2.setSelection(SeciliDurak);
        }
        listview2.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final HatBilgileri this$0;

            public void onItemClick(AdapterView adapterview, View view, int i2, long l2)
            {
                ListView listview3;
                HashMap hashmap9;
                try
                {
                    listview3 = (ListView)findViewById(0x7f090033);
                }
                catch (Exception exception8)
                {
                    return;
                }
                Exception exception10;
                try
                {
                    if (SeciliDurak > -1)
                    {
                        listview3.getChildAt(SeciliDurak).setBackgroundColor(0x30262626);
                    }
                }
                catch (Exception exception9) { }
                SeciliDurak = i2;
                view.setBackgroundColor(Color.parseColor("#66FF0000"));
                ((ListAdapterBtn)listview3.getAdapter()).selected = i2;
                listview3.setSelection(i2);
                hashmap9 = (HashMap)listview3.getItemAtPosition(i2);
                try
                {
                    Global.App_Durak_No = (String)hashmap9.get("ad");
                    Global.App_Otobus_No = "";
                    tabhost.setCurrentTab(0);
                    OtobusYenile(0);
                    Toast.makeText(getBaseContext(), (new StringBuilder("Otob\374s Konumlar\u0131\n")).append((String)hashmap9.get("ad")).append(" Nolu Dura\u011Fa G\366re\nYeniden Hesapland\u0131.").toString(), 1).show();
                    return;
                }
                // Misplaced declaration of an exception variable
                catch (Exception exception10)
                {
                    return;
                }
            }

            
            {
                this$0 = HatBilgileri.this;
                super();
            }
        });
        listview2.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final HatBilgileri this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int i2, long l2)
            {
                HashMap hashmap9 = (HashMap)((ListView)findViewById(0x7f090033)).getItemAtPosition(i2);
                Global.App_Konum = (new StringBuilder("Durak ")).append((String)hashmap9.get("ad")).toString();
                Global.App_Konum_Adres = (String)hashmap9.get("yer");
                Global.App_Konum_Ilce = "-";
                Global.App_Konum_Lat = (String)hashmap9.get("lat");
                Global.App_Konum_Lng = (String)hashmap9.get("lng");
                Global.App_Konum_Durak_No = (String)hashmap9.get("ad");
                Global.App_Konum_Durak_Tanim = (String)hashmap9.get("yer");
                Intent intent = new Intent(getBaseContext(), com/ego/android/KonumMap);
                startActivityForResult(intent, 0);
                return true;
            }

            
            {
                this$0 = HatBilgileri.this;
                super();
            }
        });
        OtobusYenile(0);
        if (!s.equals("OtobusAra")) goto _L1; else goto _L9
_L9:
        listview = (ListView)findViewById(0x7f090010);
        arraylist = new ArrayList();
        hashmap = new HashMap();
        j = 0;
        SeciliOtobus = -1;
        jsonarray = http.JArray(0, "otobus");
        k = 0;
        hashmap1 = hashmap;
_L19:
        l = jsonarray.length();
        if (k < l) goto _L11; else goto _L10
_L10:
        hashmap1;
_L21:
        listadapter = new ListAdapter(this, arraylist, 0x7f03001d, new String[] {
            "kod", "plaka", "hiz", "sure", "aciklama", "arac"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048, 0x7f090049, 0x7f09004a, 0x7f09004b
        }, Boolean.valueOf(true));
        listview.setAdapter(listadapter);
        if (SeciliOtobus > -1)
        {
            listview.setSelection(SeciliOtobus);
        }
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final HatBilgileri this$0;

            public void onItemClick(AdapterView adapterview, View view, int i2, long l2)
            {
                ListView listview3 = (ListView)findViewById(0x7f090010);
                Intent intent;
                try
                {
                    if (SeciliOtobus > -1)
                    {
                        listview3.getChildAt(SeciliOtobus).setBackgroundColor(0x30262626);
                    }
                }
                catch (Exception exception8) { }
                SeciliOtobus = i2;
                view.setBackgroundColor(Color.parseColor("#66FF0000"));
                Global.App_Otobus_No = (String)((HashMap)listview3.getItemAtPosition(i2)).get("kod");
                intent = new Intent(getBaseContext(), com/ego/android/HatMap);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = HatBilgileri.this;
                super();
            }
        });
        listview.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final HatBilgileri this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int i2, long l2)
            {
                ListView listview3 = (ListView)findViewById(0x7f090010);
                Intent intent;
                try
                {
                    if (SeciliOtobus > -1)
                    {
                        listview3.getChildAt(SeciliOtobus).setBackgroundColor(0x30262626);
                    }
                }
                catch (Exception exception8) { }
                SeciliOtobus = i2;
                view.setBackgroundColor(Color.parseColor("#66FF0000"));
                Global.App_Otobus_No = (String)((HashMap)listview3.getItemAtPosition(i2)).get("kod");
                intent = new Intent(getBaseContext(), com/ego/android/OtobusNeredeMap);
                startActivityForResult(intent, 0);
                return true;
            }

            
            {
                this$0 = HatBilgileri.this;
                super();
            }
        });
        if (j <= 0) goto _L13; else goto _L12
_L12:
        if (Global.App_OtobusYenilemeSuresi <= 0) goto _L1; else goto _L14
_L14:
        OtobusYenile(Global.App_OtobusYenilemeSuresi);
        return;
_L6:
        jsonobject2 = jsonarray2.getJSONObject(k1);
        hashmap8 = new HashMap();
        s3 = jsonobject2.getString("his");
        s4 = "";
        if (jsonobject2.getString("his").length() <= 1)
        {
            break MISSING_BLOCK_LABEL_773;
        }
        s4 = "-";
        if (jsonobject2.getString("hia").length() > 1)
        {
            s4 = jsonobject2.getString("hia");
        }
        s5 = jsonobject2.getString("cms");
        s6 = "";
        if (jsonobject2.getString("cms").length() <= 1)
        {
            break MISSING_BLOCK_LABEL_827;
        }
        s6 = "-";
        if (jsonobject2.getString("cma").length() > 1)
        {
            s6 = jsonobject2.getString("cma");
        }
        s7 = jsonobject2.getString("pzs");
        s8 = "";
        if (jsonobject2.getString("pzs").length() <= 1)
        {
            break MISSING_BLOCK_LABEL_881;
        }
        s8 = "-";
        if (jsonobject2.getString("pza").length() > 1)
        {
            s8 = jsonobject2.getString("pza");
        }
        hashmap8.put("his", s3);
        hashmap8.put("hia", s4);
        hashmap8.put("cms", s5);
        hashmap8.put("cma", s6);
        hashmap8.put("pzs", s7);
        hashmap8.put("pza", s8);
        arraylist1.add(hashmap8);
        k1++;
        hashmap7 = hashmap8;
          goto _L15
_L8:
        jsonobject1 = jsonarray1.getJSONObject(i1);
        hashmap6 = new HashMap();
        hashmap6.put("ad", jsonobject1.getString("ad"));
        hashmap6.put("yer", jsonobject1.getString("yer"));
        hashmap6.put("lat", jsonobject1.getString("lat"));
        hashmap6.put("lng", jsonobject1.getString("lng"));
        hashmap6.put("aciklama", jsonobject1.getString("aciklama"));
        if (!Global.App_Durak_No.equals(jsonobject1.getString("ad")) && !Global.App_Durak_No.equals(jsonobject1.get("sno")))
        {
            break MISSING_BLOCK_LABEL_1206;
        }
        Global.App_Durak_No = jsonobject1.getString("ad");
        hashmap6.put("bgcolor", "#66FF0000");
        SeciliDurak = i1;
_L17:
        hashmap6.put("btn", (new StringBuilder("Durak;")).append(jsonobject1.getString("ad")).append(";").append(jsonobject1.getString("yer")).append(";").append(jsonobject1.getString("lat")).append(";").append(jsonobject1.getString("lng")).toString());
        arraylist2.add(hashmap6);
        i1++;
        hashmap5 = hashmap6;
          goto _L16
        hashmap6.put("bgcolor", "");
          goto _L17
        exception5;
          goto _L18
_L11:
        j++;
        jsonobject = jsonarray.getJSONObject(k);
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(k).toString());
        hashmap2.put("kod", jsonobject.getString("kod"));
        hashmap2.put("plaka", jsonobject.getString("plaka"));
        hashmap2.put("hiz", jsonobject.getString("hiz"));
        hashmap2.put("sure", jsonobject.getString("sure"));
        hashmap2.put("aciklama", jsonobject.getString("aciklama"));
        hashmap2.put("arac", jsonobject.getString("arac"));
        if (!Global.App_Otobus_No.equals(jsonobject.getString("kod")))
        {
            break MISSING_BLOCK_LABEL_1409;
        }
        SeciliOtobus = k;
        hashmap2.put("bgcolor", "#66FF0000");
_L20:
        arraylist.add(hashmap2);
        k++;
        hashmap1 = hashmap2;
          goto _L19
        hashmap2.put("bgcolor", "");
          goto _L20
        exception2;
          goto _L21
_L13:
        Toast.makeText(getBaseContext(), "Hat \334zerinde \u015Eu Anda Otob\374s Yok!", 1).show();
        return;
_L4:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception3;
        hashmap1;
          goto _L21
        exception6;
        hashmap5;
          goto _L18
        exception4;
          goto _L22
        exception7;
        hashmap7;
          goto _L22
    }

    public void Harita()
    {
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/HatMap), 0);
    }

    public void HatYenile()
    {
        String as[] = {
            "FNC", "Hat"
        };
        String as1[] = new String[2];
        as1[0] = "QUERY";
        as1[1] = Global.App_Hat_No;
        http = new Http("Hat", "hat.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final HatBilgileri this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = HatBilgileri.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        try
        {
            String as[] = s.split(";");
            if (as[0].equals("Durak"))
            {
                Global.App_Konum = (new StringBuilder("Durak ")).append(as[1]).toString();
                Global.App_Konum_Adres = as[2];
                Global.App_Konum_Ilce = "-";
                Global.App_Konum_Lat = as[3];
                Global.App_Konum_Lng = as[4];
                Global.App_Konum_Durak_No = as[1];
                Global.App_Konum_Durak_Tanim = as[2];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/KonumMap), 0);
            }
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void OtobusYenile(int i)
    {
        handlerStop();
        handlerRunnable = new Runnable() {

            final HatBilgileri this$0;

            public void run()
            {
                try
                {
                    handler.removeCallbacks(handlerRunnable);
                }
                catch (Exception exception) { }
                if (handlerStatus)
                {
                    handlerStatus = false;
                    HatBilgileri hatbilgileri = HatBilgileri.this;
                    String as[] = {
                        "FNC", "OtobusAra"
                    };
                    String as1[] = new String[4];
                    as1[0] = "QUERY";
                    as1[1] = Global.App_Hat_No;
                    as1[2] = "DURAK";
                    as1[3] = Global.App_Durak_No;
                    hatbilgileri.http = new Http("OtobusAra", "hat.asp", as, as1);
                    http.addObserver(new Http.Callback() {

                        final _cls5 this$1;

                        public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
                        {
                            Action(s, s1, i, boolean1, s2);
                        }

            
            {
                this$1 = _cls5.this;
                super();
            }
                    });
                    dialog.show();
                    http.execute(new String[0]);
                }
            }


            
            {
                this$0 = HatBilgileri.this;
                super();
            }
        };
        if (i == 0)
        {
            handlerStatus = true;
            handler.postDelayed(handlerRunnable, 0L);
            return;
        } else
        {
            handlerStatus = true;
            handler.postDelayed(handlerRunnable, i);
            return;
        }
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (!s.equals("0"))
        {
            handlerStop();
        }
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Harita();
                return;
            }
            if (s.equals("3"))
            {
                OtobusYenile(0);
                return;
            }
            if (s.equals("4"))
            {
                Global.App_Favorilerim_Hat_Ekle = Global.App_Hat_No;
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimHatDuzenle), 0);
                return;
            }
        }
    }

    public void handlerStop()
    {
        handlerStatus = false;
        try
        {
            handler.removeCallbacks(handlerRunnable);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        handlerStop();
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030010);
        dialog = Tools.Waiting(this);
        tabhost = (TabHost)findViewById(0x7f090031);
        tabhost.setup();
        android.widget.TabHost.TabSpec tabspec = tabhost.newTabSpec("Tab1");
        tabspec.setIndicator("Hattaki Otob\374sler", getResources().getDrawable(0x7f020011));
        tabspec.setContent(0x7f090032);
        tabhost.addTab(tabspec);
        android.widget.TabHost.TabSpec tabspec1 = tabhost.newTabSpec("Tab2");
        tabspec1.setIndicator("Hareket Saatleri", getResources().getDrawable(0x7f020029));
        tabspec1.setContent(0x7f090034);
        tabhost.addTab(tabspec1);
        android.widget.TabHost.TabSpec tabspec2 = tabhost.newTabSpec("Tab3");
        tabspec2.setIndicator("Duraklar\u0131", getResources().getDrawable(0x7f02002f));
        tabspec2.setContent(0x7f09003e);
        tabhost.addTab(tabspec2);
        int i = 0;
        do
        {
            if (i >= tabhost.getTabWidget().getChildCount())
            {
                tabhost.setCurrentTab(0);
                tabhost.getTabWidget().getChildAt(0).setOnClickListener(new android.view.View.OnClickListener() {

                    final HatBilgileri this$0;

                    public void onClick(View view)
                    {
                        tabhost.setCurrentTab(0);
                        OtobusYenile(0);
                    }

            
            {
                this$0 = HatBilgileri.this;
                super();
            }
                });
                tabhost.getTabWidget().getChildAt(1).setOnClickListener(new android.view.View.OnClickListener() {

                    final HatBilgileri this$0;

                    public void onClick(View view)
                    {
                        tabhost.setCurrentTab(1);
                    }

            
            {
                this$0 = HatBilgileri.this;
                super();
            }
                });
                tabhost.getTabWidget().getChildAt(2).setOnClickListener(new android.view.View.OnClickListener() {

                    final HatBilgileri this$0;

                    public void onClick(View view)
                    {
                        tabhost.setCurrentTab(2);
                    }

            
            {
                this$0 = HatBilgileri.this;
                super();
            }
                });
                HatYenile();
                return;
            }
            ((TextView)tabhost.getTabWidget().getChildAt(i).findViewById(0x1020016)).setTextSize(12F);
            i++;
        } while (true);
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    public void onResume()
    {
        super.onResume();
        pageStatus = true;
    }

    protected void onStop()
    {
        pageStatus = false;
        handlerStop();
        super.onStop();
    }
}
