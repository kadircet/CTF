// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.text.Editable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            OtobusNerede, Global, OtobusNeredeMap

class this._cls0
    implements android.widget.temLongClickListener
{

    final OtobusNerede this$0;

    public boolean onItemLongClick(AdapterView adapterview, View view, int i, long l)
    {
        HashMap hashmap = (HashMap)((ListView)findViewById(0x7f090010)).getItemAtPosition(i);
        Global.App_Hat_No = (String)hashmap.get("no");
        Global.App_Durak_No = ((EditText)findViewById(0x7f090000)).getText().toString();
        Global.App_Otobus_No = (String)hashmap.get("kod");
        Intent intent = new Intent(getBaseContext(), com/ego/android/OtobusNeredeMap);
        startActivityForResult(intent, 0);
        return true;
    }

    ()
    {
        this$0 = OtobusNerede.this;
        super();
    }
}
