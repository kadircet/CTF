// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.graphics.Point;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Projection;

// Referenced classes of package com.ego.android:
//            AdresMap, Tools

class this._cls0
    implements android.view.hListener
{

    final AdresMap this$0;

    public boolean onTouch(View view, MotionEvent motionevent)
    {
        if (motionevent.getAction() == 1)
        {
            if (lastTouchPositon != null)
            {
                com.google.android.maps.GeoPoint geopoint = mv.getProjection().fromPixels((int)motionevent.getX(), (int)motionevent.getY());
                int i = (int)motionevent.getX() - lastTouchPositon.x;
                int j = (int)motionevent.getY() - lastTouchPositon.y;
                int k = Math.abs(i);
                int l = Math.abs(j);
                if (k <= 10 && l <= 10)
                {
                    if (motionevent.getEventTime() - lastTouchTime >= 250L && motionevent.getEventTime() - lastTouchTime <= 1000L)
                    {
                        konumPosition = geopoint;
                        konumAdres = "";
                        konumIlce = "";
                        String as[] = Tools.GeoCoder(konumPosition);
                        if (!as[0].equals(""))
                        {
                            konumAdres = as[0];
                            konumIlce = as[1];
                            Toast.makeText(getBaseContext(), (new StringBuilder("Konum\n\n")).append(konumAdres).append("\n").append(konumIlce).toString(), 1).show();
                        }
                        Isaretle("Konum", konumPosition, 0, "");
                        lastTouchTime = -1L;
                        lastTouchDoubleTime = -1L;
                        lastTouchPositon = null;
                        return true;
                    }
                } else
                {
                    lastTouchTime = -1L;
                }
                lastTouchTime = -1L;
            } else
            {
                lastTouchTime = -1L;
            }
        }
        if (motionevent.getAction() == 0)
        {
            if (motionevent.getEventTime() - lastTouchDoubleTime < 250L)
            {
                mc.setZoom(1 + mv.getZoomLevel());
                mv.invalidate();
                lastTouchTime = -1L;
                lastTouchDoubleTime = -1L;
                lastTouchPositon = null;
                return true;
            }
            lastTouchPositon = new Point((int)motionevent.getX(), (int)motionevent.getY());
            lastTouchTime = motionevent.getEventTime();
            lastTouchDoubleTime = motionevent.getEventTime();
        }
        return false;
    }

    Controller()
    {
        this$0 = AdresMap.this;
        super();
    }
}
