// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.DialogInterface;
import android.content.Intent;

// Referenced classes of package com.ego.android:
//            SorunlarBildir

class this._cls0
    implements android.content.nClickListener
{

    final SorunlarBildir this$0;

    public void onClick(DialogInterface dialoginterface, int i)
    {
        CAMERA_PIC_ID = 10 * FotografId + FotografId;
        try
        {
            startActivityForResult(new Intent("android.intent.action.PICK", android.provider..Media.INTERNAL_CONTENT_URI), CAMERA_PIC_REQUEST);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    s.Media()
    {
        this$0 = SorunlarBildir.this;
        super();
    }
}
