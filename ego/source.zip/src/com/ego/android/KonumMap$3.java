// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.location.Location;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            KonumMap, Global, Map, Gps

class this._cls0
    implements k
{

    final KonumMap this$0;

    public void onComplete(Location location)
    {
        Exception exception1;
        com.google.android.maps.GeoPoint geopoint;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (location != null)
        {
            break MISSING_BLOCK_LABEL_169;
        }
        Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
        geopoint = Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString());
        locationAdres = "K\u0131z\u0131lay Meydan\u0131";
        locationIlce = "\307ankaya";
_L1:
        KonumMap.this.location = true;
        locationPosition = geopoint;
        Isaretle("Location", geopoint, 17, "");
        Toast.makeText(getBaseContext(), (new StringBuilder("Konumum\n\n")).append(locationAdres).append("\n").append(locationIlce).toString(), 1).show();
        return;
        try
        {
            geopoint = Map.GP((new StringBuilder()).append(location.getLatitude()).toString(), (new StringBuilder()).append(location.getLongitude()).toString());
            locationAdres = gps.GpsAdres;
            locationIlce = gps.GpsIlce;
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception1)
        {
            return;
        }
          goto _L1
    }

    k()
    {
        this$0 = KonumMap.this;
        super();
    }
}
