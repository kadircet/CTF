// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Dialog;
import android.view.View;
import android.widget.Button;

// Referenced classes of package com.ego.android:
//            Ayarlar

class val.dialogBox
    implements android.view.ckListener
{

    final Ayarlar this$0;
    private final Dialog val$dialogBox;

    public void onClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        val$dialogBox.dismiss();
        try
        {
            String as[] = s.split(";");
            deger[Integer.parseInt(as[0])] = as[1];
            Yenile();
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    istener()
    {
        this$0 = final_ayarlar;
        val$dialogBox = Dialog.this;
        super();
    }
}
