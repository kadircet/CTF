// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.graphics.Color;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.Toast;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            HatBilgileri, ListAdapterBtn, Global

class this._cls0
    implements android.widget.temClickListener
{

    final HatBilgileri this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        ListView listview;
        HashMap hashmap;
        try
        {
            listview = (ListView)findViewById(0x7f090033);
        }
        catch (Exception exception)
        {
            return;
        }
        Exception exception2;
        try
        {
            if (SeciliDurak > -1)
            {
                listview.getChildAt(SeciliDurak).setBackgroundColor(0x30262626);
            }
        }
        catch (Exception exception1) { }
        SeciliDurak = i;
        view.setBackgroundColor(Color.parseColor("#66FF0000"));
        ((ListAdapterBtn)listview.getAdapter()).selected = i;
        listview.setSelection(i);
        hashmap = (HashMap)listview.getItemAtPosition(i);
        try
        {
            Global.App_Durak_No = (String)hashmap.get("ad");
            Global.App_Otobus_No = "";
            tabhost.setCurrentTab(0);
            OtobusYenile(0);
            Toast.makeText(getBaseContext(), (new StringBuilder("Otob\374s Konumlar\u0131\n")).append((String)hashmap.get("ad")).append(" Nolu Dura\u011Fa G\366re\nYeniden Hesapland\u0131.").toString(), 1).show();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception2)
        {
            return;
        }
    }

    emClickListener()
    {
        this$0 = HatBilgileri.this;
        super();
    }
}
