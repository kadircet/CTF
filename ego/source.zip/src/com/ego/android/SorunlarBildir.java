// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.Editable;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.maps.GeoPoint;
import java.io.ByteArrayOutputStream;
import java.io.File;

// Referenced classes of package com.ego.android:
//            Http, Global, Gps, Tools, 
//            Map

public class SorunlarBildir extends Activity
{

    public int CAMERA_PIC_ID;
    public int CAMERA_PIC_REQUEST;
    public String Fotograf1_Data;
    public String Fotograf2_Data;
    public int FotografId;
    ProgressDialog dialog;
    Gps gps;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    boolean location;
    String locationAdres;
    String locationIlce;
    GeoPoint locationPosition;
    public String temporaryCameraFile;

    public SorunlarBildir()
    {
        location = false;
        locationAdres = "";
        locationIlce = "";
        handler = new Handler();
        handlerStatus = false;
        CAMERA_PIC_REQUEST = 1337;
        CAMERA_PIC_ID = 1;
        FotografId = 0;
        Fotograf1_Data = "";
        Fotograf2_Data = "";
        temporaryCameraFile = (new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()))).append("/temporaryCameraFile.jpg").toString();
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
label0:
        {
label1:
            {
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (i != 200)
                {
                    break label0;
                }
                if (s.equals("G\366nder"))
                {
                    if (!http.JValue(0, "status").equals("true"))
                    {
                        break label1;
                    }
                    (new android.app.AlertDialog.Builder(this)).setTitle("Bilgi").setMessage("Sorun Bize Ula\u015Ft\u0131.\n\u0130lginize Te\u015Fekk\374r Ederiz.").setNeutralButton("Tamam", new android.content.DialogInterface.OnClickListener() {

                        final SorunlarBildir this$0;

                        public void onClick(DialogInterface dialoginterface, int j)
                        {
                            finish();
                        }

            
            {
                this$0 = SorunlarBildir.this;
                super();
            }
                    }).show();
                }
                return;
            }
            if (!http.JValue(0, "error").equals(""))
            {
                Toast.makeText(getBaseContext(), http.JValue(0, "error"), 1).show();
                return;
            } else
            {
                Toast.makeText(getBaseContext(), "Sorun G\366nderilemedi!", 1).show();
                return;
            }
        }
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
    }

    public void CloseKeyboard()
    {
        ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(0x7f09002e).getWindowToken(), 0);
    }

    public void FotografCek(String s)
    {
        FotografId = Integer.parseInt(s);
        (new android.app.AlertDialog.Builder(this)).setTitle("Kaynak Se\347").setMessage("Foto\u011Fraf\u0131n Al\u0131naca\u011F\u0131 Kaynak ?").setPositiveButton("Kamera", new android.content.DialogInterface.OnClickListener() {

            final SorunlarBildir this$0;

            public void onClick(DialogInterface dialoginterface, int i)
            {
                CAMERA_PIC_ID = FotografId;
                try
                {
                    Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                    intent.putExtra("output", Uri.fromFile(new File(temporaryCameraFile)));
                    startActivityForResult(intent, CAMERA_PIC_REQUEST);
                    return;
                }
                catch (Exception exception)
                {
                    return;
                }
            }

            
            {
                this$0 = SorunlarBildir.this;
                super();
            }
        }).setNeutralButton("Galeri", new android.content.DialogInterface.OnClickListener() {

            final SorunlarBildir this$0;

            public void onClick(DialogInterface dialoginterface, int i)
            {
                CAMERA_PIC_ID = 10 * FotografId + FotografId;
                try
                {
                    startActivityForResult(new Intent("android.intent.action.PICK", android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI), CAMERA_PIC_REQUEST);
                    return;
                }
                catch (Exception exception)
                {
                    return;
                }
            }

            
            {
                this$0 = SorunlarBildir.this;
                super();
            }
        }).show();
    }

    public void FotografImage_OnClick(View view)
    {
        FotografCek(((ImageView)view).getTag().toString());
    }

    public void Fotograf_OnClick(View view)
    {
        FotografCek(((Button)view).getTag().toString());
    }

    public void Gonder()
    {
        String s = ((Spinner)findViewById(0x7f090068)).getSelectedItem().toString();
        String s1 = ((Spinner)findViewById(0x7f090069)).getSelectedItem().toString();
        String s2 = ((EditText)findViewById(0x7f09002e)).getText().toString();
        String s3 = ((EditText)findViewById(0x7f09006a)).getText().toString();
        if (s.equals("- Birim Se\347iniz -"))
        {
            Toast.makeText(getApplicationContext(), "\u0130lgili Birimi Se\347iniz!", 1).show();
            return;
        }
        if (s1.equals("- Konu Se\347iniz -"))
        {
            Toast.makeText(getApplicationContext(), "Konuyu Se\347iniz!", 1).show();
            return;
        }
        if (s3.equals(""))
        {
            Toast.makeText(getApplicationContext(), "Sorunun Detay\u0131n\u0131 Giriniz!", 1).show();
            return;
        }
        String s4 = s3.replaceAll("\n", "{E}");
        String s5 = "";
        String s6 = "";
        String s7 = "";
        if (location)
        {
            s5 = (new StringBuilder(String.valueOf(locationAdres))).append(" ").append(locationIlce).toString();
            s6 = (new StringBuilder()).append((double)locationPosition.getLatitudeE6() / 1000000D).toString();
            s7 = (new StringBuilder()).append((double)locationPosition.getLongitudeE6() / 1000000D).toString();
        }
        String as[] = {
            "FNC", "Sorun"
        };
        String as1[] = new String[26];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        as1[2] = "ADSOYAD";
        as1[3] = Global.Set_AdSoyad;
        as1[4] = "TELEFON";
        as1[5] = Global.Set_Telefon;
        as1[6] = "EPOSTA";
        as1[7] = Global.Set_EPosta;
        as1[8] = "BIRIM";
        as1[9] = s;
        as1[10] = "KONU";
        as1[11] = s1;
        as1[12] = "HATNO";
        as1[13] = s2;
        as1[14] = "SORUN";
        as1[15] = s4;
        as1[16] = "KONUM";
        as1[17] = s5;
        as1[18] = "KONUMLAT";
        as1[19] = s6;
        as1[20] = "KONUMLNG";
        as1[21] = s7;
        as1[22] = "FOTOGRAF1";
        as1[23] = Fotograf1_Data;
        as1[24] = "FOTOGRAF2";
        as1[25] = Fotograf2_Data;
        http = new Http("G\366nder", "sorun.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final SorunlarBildir this$0;

            public void onComplete(String s8, String s9, int i, Boolean boolean1, String s10)
            {
                Action(s8, s9, i, boolean1, s10);
            }

            
            {
                this$0 = SorunlarBildir.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void KlavyeC_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        if (s.equals("Sorun"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f09002e).getWindowToken(), 0);
        }
    }

    public void KlavyeX_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        if (s.equals("Baslik"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f09002e).getWindowToken(), 0);
            ((EditText)findViewById(0x7f09002e)).setText("");
            ((EditText)findViewById(0x7f09002e)).requestFocus();
        }
        inputmethodmanager.toggleSoftInput(2, 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void Location()
    {
        gps = new Gps(this);
        gps.addObserver(new Gps.Callback() {

            final SorunlarBildir this$0;

            public void onComplete(Location location1)
            {
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location1 == null)
                {
                    try
                    {
                        Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                        return;
                    }
                    catch (Exception exception1)
                    {
                        return;
                    }
                }
                if (gps.GpsAdres.equals(""))
                {
                    Toast.makeText(getBaseContext(), "Adres Bulunamad\u0131!", 1).show();
                    return;
                }
                location = true;
                locationPosition = Map.GP((new StringBuilder()).append(location1.getLatitude()).toString(), (new StringBuilder()).append(location1.getLongitude()).toString());
                locationAdres = gps.GpsAdres;
                locationIlce = gps.GpsIlce;
                ((TextView)findViewById(0x7f09006d)).setText((new StringBuilder(String.valueOf(locationAdres))).append("\n").append(locationIlce).toString());
                Toast.makeText(getBaseContext(), (new StringBuilder("Konumum\n\n")).append(locationAdres).append("\n").append(locationIlce).toString(), 1).show();
                return;
            }

            
            {
                this$0 = SorunlarBildir.this;
                super();
            }
        });
        gps.Start();
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final SorunlarBildir this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = SorunlarBildir.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void ToolBar_OnClick(View view)
    {
        CloseKeyboard();
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Runnable("Location");
                return;
            }
            if (s.equals("3"))
            {
                if (Fotograf1_Data.equals(""))
                {
                    FotografCek("1");
                    return;
                }
                if (Fotograf2_Data.equals(""))
                {
                    FotografCek("2");
                    return;
                } else
                {
                    Toast.makeText(getBaseContext(), "En Fazla 2 Adet\nFoto\u011Fraf \307ekebilirsiniz!", 1).show();
                    return;
                }
            }
            if (s.equals("4"))
            {
                Gonder();
                return;
            }
        }
    }

    public String getPath(Uri uri)
    {
        String as[] = {
            "_data"
        };
        Cursor cursor = getContentResolver().query(uri, as, null, null, null);
        cursor.moveToFirst();
        return cursor.getString(cursor.getColumnIndex(as[0]));
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        CloseKeyboard();
        setRequestedOrientation(1);
        if (i == CAMERA_PIC_REQUEST)
        {
            try
            {
                String s = temporaryCameraFile;
                if (CAMERA_PIC_ID == 11 || CAMERA_PIC_ID == 22)
                {
                    s = getPath(intent.getData());
                }
                Bitmap bitmap = scaleBitmap(BitmapFactory.decodeFile(s), 480, 640);
                ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 75, bytearrayoutputstream);
                byte abyte0[] = bytearrayoutputstream.toByteArray();
                if (CAMERA_PIC_ID == 1 || CAMERA_PIC_ID == 11)
                {
                    ((ImageView)findViewById(0x7f09006b)).setImageBitmap(bitmap);
                    Fotograf1_Data = Base64.encodeToString(abyte0, 0);
                }
                if (CAMERA_PIC_ID == 2 || CAMERA_PIC_ID == 22)
                {
                    ((ImageView)findViewById(0x7f09006c)).setImageBitmap(bitmap);
                    Fotograf2_Data = Base64.encodeToString(abyte0, 0);
                }
                byte[] _tmp = (byte[])null;
                System.gc();
            }
            catch (Exception exception)
            {
                System.gc();
                Toast.makeText(getBaseContext(), "Foto\u011Fraf \u0130\u015Flenirken\nHata Olu\u015Ftu!", 1).show();
            }
        }
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030034);
        CloseKeyboard();
        dialog = Tools.Waiting(this);
        Spinner spinner = (Spinner)findViewById(0x7f090068);
        ArrayAdapter arrayadapter = new ArrayAdapter(this, 0x1090008, Global.App_SorunBirim);
        arrayadapter.setDropDownViewResource(0x1090009);
        spinner.setAdapter(arrayadapter);
        Spinner spinner1 = (Spinner)findViewById(0x7f090069);
        ArrayAdapter arrayadapter1 = new ArrayAdapter(this, 0x1090008, Global.App_SorunKonu);
        arrayadapter1.setDropDownViewResource(0x1090009);
        spinner1.setAdapter(arrayadapter1);
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        CloseKeyboard();
        super.onStop();
    }

    public Bitmap scaleBitmap(Bitmap bitmap, int i, int j)
    {
        int k = i;
        int l = j;
        int i1;
        int j1;
        double d;
        double d1;
        Bitmap bitmap1;
        try
        {
            i1 = bitmap.getWidth();
            j1 = bitmap.getHeight();
        }
        catch (Exception exception)
        {
            System.gc();
            return bitmap;
        }
        if (k <= 0 && l <= 0)
        {
            return bitmap;
        }
        if (k <= 0 || l > 0) goto _L2; else goto _L1
_L1:
        l = (k * j1) / i1;
_L3:
        bitmap1 = Bitmap.createScaledBitmap(bitmap, k, l, true);
        bitmap.recycle();
        System.gc();
        return bitmap1;
_L2:
        if (k > 0 || l <= 0)
        {
            break MISSING_BLOCK_LABEL_94;
        }
        k = (l * i1) / j1;
          goto _L3
        d = (double)k / (double)l;
        d1 = (double)i1 / (double)j1;
        if (d1 <= d) goto _L5; else goto _L4
_L4:
        l = (k * j1) / i1;
          goto _L3
_L5:
        if (d1 >= d) goto _L3; else goto _L6
_L6:
        k = (l * i1) / j1;
          goto _L3
    }
}
