// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Ayarlar

class this._cls0
    implements android.widget.w.OnItemClickListener
{

    final Ayarlar this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        HashMap hashmap = (HashMap)((ListView)findViewById(0x7f090016)).getItemAtPosition(i);
        AyarSecim(3 + Integer.parseInt((String)hashmap.get("id")), (String)hashmap.get("tanim"), (new StringBuilder("\n")).append((String)hashmap.get("aciklama")).toString(), degerler[Integer.parseInt((String)hashmap.get("id"))].split(";"));
    }

    ()
    {
        this$0 = Ayarlar.this;
        super();
    }
}
