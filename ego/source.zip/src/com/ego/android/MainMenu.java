// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.TelephonyManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, Global, AdresAra, Duyurular, 
//            Favorilerim, HatAra, NasilGiderim, Neredeyim, 
//            OnemliYerler, OtobusNerede, Sorunlar, Panelim, 
//            Alarm, Ayarlar, Tools

public class MainMenu extends Activity
    implements LocationListener
{

    ProgressDialog dialog;
    String egoUser;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    boolean ilkCalisma;
    LocationListener locationListenerGps;
    LocationListener locationListenerNetwork;
    LocationManager locationManager;
    boolean locationStatus;

    public MainMenu()
    {
        locationStatus = false;
        handler = new Handler();
        handlerStatus = false;
        ilkCalisma = true;
        egoUser = "";
    }

    public void Abb_OnClick(View view)
    {
        Clear();
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("http://www.ego.gov.tr/mobil/web/index.asp?Page=ABB"));
        startActivity(intent);
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        String s3;
        String s5;
        Exception exception1;
        Exception exception2;
        JSONArray jsonarray;
        int j;
        int k;
        JSONArray jsonarray1;
        int l;
        int i1;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Connect")) goto _L4; else goto _L3
_L3:
        if (!http.JValue(0, "connect").equals("true")) goto _L6; else goto _L5
_L5:
        s3 = http.JValue(0, "status");
        String s4 = http.JValue(0, "update");
        s5 = http.JValue(0, "message");
        Global.App_HttpServis = http.JValue(0, "server");
        Global.App_Update = s4;
        Global.App_Message = s5;
        jsonarray1 = http.JArray(0, "sorunbirim");
        Global.App_SorunBirim.clear();
        Global.App_SorunBirim.add("- Birim Se\347iniz -");
        l = 0;
_L13:
        i1 = jsonarray1.length();
        if (l < i1) goto _L8; else goto _L7
_L7:
        jsonarray = http.JArray(0, "sorunkonu");
        Global.App_SorunKonu.clear();
        Global.App_SorunKonu.add("- Konu Se\347iniz -");
        j = 0;
_L14:
        k = jsonarray.length();
        if (j < k) goto _L10; else goto _L9
_L9:
        String s6 = http.JValue(0, "adsoyad");
        String s7 = http.JValue(0, "telefon");
        String s8 = http.JValue(0, "eposta");
        String s9 = http.JValue(0, "haritatipi");
        String s10 = http.JValue(0, "otobuskonumguncelleme");
        String s11 = http.JValue(0, "otobusotomatiktakip");
        String s12 = http.JValue(0, "hatdurakgorunumu");
        String s13 = http.JValue(0, "yakinlik");
        String s14 = http.JValue(0, "yaklasim");
        if (!s9.equals(""))
        {
            Global.Set_AdSoyad = s6;
            Global.Set_Telefon = s7;
            Global.Set_EPosta = s8;
            Global.Set_HaritaTipi = s9;
            Global.Set_OtobusKonumGuncelleme = s10;
            Global.Set_OtobusOtomatikTakip = s11;
            Global.Set_HatDurakGorunumu = s12;
            Global.Set_Yakinlik = s13;
            Global.Set_Yaklasim = s14;
            if (s10.equals("5 Saniye"))
            {
                Global.App_OtobusYenilemeSuresi = 5000;
            } else
            if (s10.equals("15 Saniye"))
            {
                Global.App_OtobusYenilemeSuresi = 15000;
            } else
            if (s10.equals("30 Saniye"))
            {
                Global.App_OtobusYenilemeSuresi = 30000;
            } else
            if (s10.equals("45 Saniye"))
            {
                Global.App_OtobusYenilemeSuresi = 45000;
            } else
            if (s10.equals("60 Saniye"))
            {
                Global.App_OtobusYenilemeSuresi = 60000;
            } else
            if (s10.equals("Kapal\u0131"))
            {
                Global.App_OtobusYenilemeSuresi = 0;
            }
        }
        if (s3.equals("true")) goto _L12; else goto _L11
_L11:
        if (!s5.equals(""))
        {
            Toast.makeText(getBaseContext(), (new StringBuilder("Bilgilendirme\n\n")).append(s5).toString(), 1).show();
        } else
        {
            Toast.makeText(getBaseContext(), "Servis Aktif De\u011Fil!", 1).show();
        }
        setResult(99);
        finish();
_L16:
        return;
_L8:
        Global.App_SorunBirim.add(jsonarray1.getString(l));
        l++;
          goto _L13
_L10:
        Global.App_SorunKonu.add(jsonarray.getString(j));
        j++;
          goto _L14
_L12:
        if (!s5.equals(""))
        {
            Toast.makeText(getBaseContext(), (new StringBuilder("Bilgilendirme\n\n")).append(s5).toString(), 1).show();
        }
        android.app.AlertDialog.Builder builder;
        android.content.DialogInterface.OnClickListener onclicklistener;
        if (http.JValue(0, "uid").equals(""))
        {
            Global.Device_ID = http.JValue(0, "euid");
            if (!Global.Device_ID.equals(egoUser))
            {
                Guncelle();
            }
        } else
        if (!Global.Device_ID.equals(egoUser))
        {
            try
            {
                OutputStreamWriter outputstreamwriter = new OutputStreamWriter(openFileOutput("EgoUser.txt", 0));
                outputstreamwriter.write((new StringBuilder("User Id:")).append(Global.Device_ID).toString());
                outputstreamwriter.close();
            }
            catch (Exception exception3) { }
        }
        LocationGps(60000);
_L4:
        if (s.equals("G\374ncelle") && http.JValue(0, "status").equals("true"))
        {
            Global.Set_AdSoyad = http.JValue(0, "adsoyad");
            Global.Set_Telefon = http.JValue(0, "telefon");
            Global.Set_EPosta = http.JValue(0, "eposta");
        }
        if (!Global.App_Update.equals("true")) goto _L16; else goto _L15
_L15:
        builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("G\374ncelle");
        builder.setMessage("Uygulamam\u0131n\nYeni Bir S\374r\374m\374 Var.");
        builder.setPositiveButton("Tamam", null);
        onclicklistener = new android.content.DialogInterface.OnClickListener() {

            final MainMenu this$0;

            public void onClick(DialogInterface dialoginterface, int j1)
            {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.ego.android&feature=top-free#?t=W251bGwsMSwyLDIwNSwiY29tLmVnby5hbmRyb2lkIl0."));
                startActivity(intent);
            }

            
            {
                this$0 = MainMenu.this;
                super();
            }
        };
        builder.setNeutralButton("G\374ncelle", onclicklistener);
        builder.show();
        Global.App_Update = "false";
        return;
_L6:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        setResult(99);
        finish();
        return;
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        setResult(99);
        finish();
        return;
        exception2;
          goto _L9
        exception1;
          goto _L7
    }

    public void AdresAra_OnClick(View view)
    {
        Clear();
        Global.App_Adres_Status = "Menu";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/AdresAra), 0);
    }

    public void Bilgilendirme()
    {
        Clear();
        final Dialog dialogBox = new Dialog(this);
        dialogBox.setTitle("Bilgilendirme");
        dialogBox.requestWindowFeature(1);
        dialogBox.setContentView(0x7f030005);
        dialogBox.getWindow().setGravity(48);
        dialogBox.setCanceledOnTouchOutside(true);
        ((ImageView)dialogBox.findViewById(0x7f090020)).setOnClickListener(new android.view.View.OnClickListener() {

            final MainMenu this$0;
            private final Dialog val$dialogBox;

            public void onClick(View view)
            {
                dialogBox.dismiss();
            }

            
            {
                this$0 = MainMenu.this;
                dialogBox = dialog1;
                super();
            }
        });
        String s = (new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf("\n"))).append("1.Uygulama verilerini Internet Ba\u011Flant\u0131s\u0131 \374zerinden sa\u011Flamaktad\u0131r.\n\n").toString()))).append("2.Uygulaman\u0131n baz\u0131 b\366l\374mlerinde Konum Servisi kullan\u0131larak Konumunuz tespit edilmektedir.\n\n").toString()))).append("3.Uygulaman\u0131n baz\u0131 b\366l\374mlerinde Kamera ve Galeri Servisleri \u0130zniniz do\u011Frultusunda kulllan\u0131lmaktad\u0131r.\n\n").toString()))).append("4.Sizinle ileti\u015Fim Kurabilmemiz i\347in Kullan\u0131c\u0131 Bilgilerinizi giriniz.\n\n").toString()))).append("Kullan\u0131c\u0131 Bilgilerinizi Ayarlar b\366l\374m\374nden girebilirsiniz.").toString();
        ((TextView)dialogBox.findViewById(0x7f09001f)).setText("Bilgilendirme");
        ((TextView)dialogBox.findViewById(0x7f090021)).setText(s);
        dialogBox.show();
    }

    public void Clear()
    {
        if (!Global.Clear())
        {
            handlerStatus = true;
            StartApplication();
        }
    }

    public void CloseApplication()
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Uygulamadan \307\u0131k");
        builder.setMessage("Uygulamadan \307\u0131kmak \u0130stiyormusunuz?");
        builder.setPositiveButton("Hay\u0131r", null);
        builder.setNeutralButton("\307\u0131k", new android.content.DialogInterface.OnClickListener() {

            final MainMenu this$0;

            public void onClick(DialogInterface dialoginterface, int i)
            {
                LocationStop();
                setResult(99);
                finish();
            }

            
            {
                this$0 = MainMenu.this;
                super();
            }
        });
        builder.show();
    }

    public void Duyurular_OnClick(View view)
    {
        Clear();
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/Duyurular), 0);
    }

    public void Ego_OnClick(View view)
    {
        Clear();
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("http://www.ego.gov.tr/mobil/web/index.asp?Page=EGO"));
        startActivity(intent);
    }

    public void Favorilerim_OnClick(View view)
    {
        Clear();
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/Favorilerim), 0);
    }

    public void Guncelle()
    {
        String s;
        dialog.show();
        s = "";
        java.io.FileInputStream fileinputstream2;
        BufferedReader bufferedreader2;
        fileinputstream2 = openFileInput("EgoUser.txt");
        bufferedreader2 = new BufferedReader(new InputStreamReader(fileinputstream2));
        String s5;
        s = bufferedreader2.readLine();
        s5 = s.replace("User Id:", "");
        s = s5;
_L4:
        String s1;
        Exception exception1;
        String s2;
        Exception exception2;
        OutputStreamWriter outputstreamwriter;
        Exception exception3;
        String as[];
        Exception exception4;
        Exception exception5;
        String as1[];
        Exception exception6;
        java.io.FileInputStream fileinputstream;
        BufferedReader bufferedreader;
        Exception exception7;
        String s3;
        java.io.FileInputStream fileinputstream1;
        BufferedReader bufferedreader1;
        Exception exception8;
        String s4;
        try
        {
            fileinputstream2.close();
        }
        catch (Exception exception) { }
        s1 = "";
        fileinputstream1 = openFileInput("EgoFavori.txt");
        bufferedreader1 = new BufferedReader(new InputStreamReader(fileinputstream1));
        s4 = bufferedreader1.readLine();
        s1 = s4;
_L1:
        try
        {
            fileinputstream1.close();
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception1) { }
        s2 = "";
        fileinputstream = openFileInput("EgoFavoriHat.txt");
        bufferedreader = new BufferedReader(new InputStreamReader(fileinputstream));
        s3 = bufferedreader.readLine();
        s2 = s3;
_L2:
        try
        {
            fileinputstream.close();
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception2) { }
        try
        {
            outputstreamwriter = new OutputStreamWriter(openFileOutput("EgoUser.txt", 0));
            outputstreamwriter.write((new StringBuilder("User Id:")).append(Global.Device_ID).toString());
            outputstreamwriter.close();
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception3) { }
        if (!s.equals("") || !s1.equals("") || !s2.equals(""))
        {
            try
            {
                as = (new String[] {
                    "FNC", "Guncelle"
                });
                as1 = new String[8];
                as1[0] = "UID";
                as1[1] = Global.Device_ID;
                as1[2] = "KULLANICI";
                as1[3] = s;
                as1[4] = "DURAK";
                as1[5] = s1;
                as1[6] = "HAT";
                as1[7] = s2;
                http = new Http("G\374ncelle", "kullanici.asp", as, as1);
                http.addObserver(new Http.Callback() {

                    final MainMenu this$0;

                    public void onComplete(String s6, String s7, int i, Boolean boolean1, String s8)
                    {
                        Action(s6, s7, i, boolean1, s8);
                    }

            
            {
                this$0 = MainMenu.this;
                super();
            }
                });
                http.execute(new String[0]);
                return;
            }
            // Misplaced declaration of an exception variable
            catch (Exception exception4) { }
            try
            {
                dialog.dismiss();
                return;
            }
            // Misplaced declaration of an exception variable
            catch (Exception exception5)
            {
                return;
            }
        }
        try
        {
            dialog.dismiss();
            return;
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception6)
        {
            return;
        }
        exception8;
          goto _L1
        exception7;
          goto _L2
        Exception exception9;
        exception9;
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void HatAra_OnClick(View view)
    {
        Clear();
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/HatAra), 0);
    }

    public void LoadApplication()
    {
        String s;
        dialog.show();
        s = "";
        java.io.FileInputStream fileinputstream;
        BufferedReader bufferedreader;
        fileinputstream = openFileInput("EgoUser.txt");
        bufferedreader = new BufferedReader(new InputStreamReader(fileinputstream));
        String s3;
        s = bufferedreader.readLine();
        s3 = s.replace("User Id:", "");
        s = s3;
_L2:
        TelephonyManager telephonymanager;
        String s1;
        String s2;
        String as[];
        String as1[];
        try
        {
            fileinputstream.close();
        }
        catch (Exception exception) { }
        egoUser = s;
        telephonymanager = (TelephonyManager)getBaseContext().getSystemService("phone");
        s1 = (new StringBuilder()).append(telephonymanager.getDeviceId()).toString();
        s2 = (new StringBuilder()).append(telephonymanager.getSimSerialNumber()).toString();
        Global.Device_ID = (new UUID((new StringBuilder()).append(android.provider.Settings.Secure.getString(getContentResolver(), "android_id")).toString().hashCode(), (long)s1.hashCode() << 32 | (long)s2.hashCode())).toString();
        Global.Device_Manufacturer = Build.MANUFACTURER;
        Global.Device_Name = (new StringBuilder(String.valueOf(Build.MODEL))).append(" ").append(android.os.Build.VERSION.RELEASE).toString();
        as = (new String[] {
            "FNC", "Connect"
        });
        as1 = new String[2];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        http = new Http("Connect", "tools.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final MainMenu this$0;

            public void onComplete(String s4, String s5, int i, Boolean boolean1, String s6)
            {
                Action(s4, s5, i, boolean1, s6);
            }

            
            {
                this$0 = MainMenu.this;
                super();
            }
        });
        http.execute(new String[0]);
        return;
        Exception exception1;
        exception1;
        if (true) goto _L2; else goto _L1
_L1:
    }

    public void LocationGps(int i)
    {
        LocationStop();
        locationManager = (LocationManager)getSystemService("location");
        boolean flag = locationManager.isProviderEnabled("gps");
        boolean flag1 = locationManager.isProviderEnabled("network");
        if (!flag && !flag1)
        {
            locationStatus = false;
            return;
        }
        Global.App_Gps_Wait = true;
        Location location = null;
        if (flag)
        {
            locationManager.requestLocationUpdates("gps", 5000L, 5F, this);
            location = locationManager.getLastKnownLocation("gps");
            if (location != null)
            {
                onLocationChanged(location);
            }
        }
        if (location != null && flag1)
        {
            locationManager.requestLocationUpdates("network", 15000L, 15F, this);
            Location location1 = locationManager.getLastKnownLocation("network");
            if (location1 != null)
            {
                onLocationChanged(location1);
            }
        }
        (new Handler()).postDelayed(new Runnable() {

            final MainMenu this$0;

            public void run()
            {
                LocationStop();
            }

            
            {
                this$0 = MainMenu.this;
                super();
            }
        }, i);
        locationStatus = true;
    }

    public void LocationStop()
    {
        locationStatus = false;
        try
        {
            locationManager.removeUpdates(this);
        }
        catch (Exception exception) { }
        try
        {
            locationManager.removeUpdates(locationListenerGps);
        }
        catch (Exception exception1) { }
        try
        {
            locationManager.removeUpdates(locationListenerNetwork);
        }
        catch (Exception exception2) { }
        Global.App_Gps_Wait = false;
    }

    public void NasilGiderim_OnClick(View view)
    {
        Clear();
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/NasilGiderim), 0);
    }

    public void Neredeyim_OnClick(View view)
    {
        Clear();
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/Neredeyim), 0);
    }

    public void OnemliYerler_OnClick(View view)
    {
        Clear();
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/OnemliYerler), 0);
    }

    public void OtobusNerede_OnClick(View view)
    {
        Clear();
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/OtobusNerede), 0);
    }

    public void SorunBildir_OnClick(View view)
    {
        Clear();
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/Sorunlar), 0);
    }

    public void StartApplication()
    {
        handlerRunnable = new Runnable() {

            final MainMenu this$0;

            public void run()
            {
                try
                {
                    handler.removeCallbacks(handlerRunnable);
                }
                catch (Exception exception) { }
                if (handlerStatus)
                {
                    handlerStatus = false;
                    LoadApplication();
                }
            }

            
            {
                this$0 = MainMenu.this;
                super();
            }
        };
        handler.postDelayed(handlerRunnable, 0L);
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                Clear();
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/Panelim), 0);
                return;
            }
            if (s.equals("2"))
            {
                Clear();
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/Alarm), 0);
                return;
            }
            if (s.equals("3"))
            {
                Clear();
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/Ayarlar), 0);
                return;
            }
            if (s.equals("4"))
            {
                CloseApplication();
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        Global.App_Alarm_Acik = false;
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030026);
        dialog = Tools.Waiting(this);
        if (ilkCalisma)
        {
            ilkCalisma = false;
            handlerStatus = true;
            StartApplication();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "\307\u0131k\u0131\u015F");
        menu.add(0, 2, 2, "Bilgilendirme");
        return true;
    }

    public void onLocationChanged(Location location)
    {
        if (location != null) goto _L2; else goto _L1
_L1:
        Iterator iterator = locationManager.getAllProviders().iterator();
_L4:
        boolean flag = iterator.hasNext();
        if (flag) goto _L3; else goto _L2
_L2:
        if (location != null)
        {
            Global.App_Gps_Location = location;
        }
        return;
_L3:
        Location location1;
        String s = (String)iterator.next();
        location1 = locationManager.getLastKnownLocation(s);
        location = location1;
          goto _L4
        Exception exception;
        exception;
          goto _L2
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 41;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        CloseApplication();
        continue; /* Loop/switch isn't completed */
_L3:
        Bilgilendirme();
        if (true) goto _L1; else goto _L4
_L4:
    }

    public void onProviderDisabled(String s)
    {
    }

    public void onProviderEnabled(String s)
    {
    }

    public void onStatusChanged(String s, int i, Bundle bundle)
    {
    }

    protected void onStop()
    {
        super.onStop();
    }
}
