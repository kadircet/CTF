// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import java.util.ArrayList;

// Referenced classes of package com.ego.android:
//            Gps

class >
    implements llback
{

    final Gps this$0;

    public void onComplete(String s, ArrayList arraylist)
    {
        GeoAction(s, arraylist);
    }

    llback()
    {
        this$0 = Gps.this;
        super();
    }
}
