// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import java.util.ArrayList;

// Referenced classes of package com.ego.android:
//            AdresAra

class this._cls0
    implements k
{

    final AdresAra this$0;

    public void onComplete(String s, ArrayList arraylist)
    {
        GeoAction(s, arraylist);
    }

    k()
    {
        this$0 = AdresAra.this;
        super();
    }
}
