// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SimpleAdapter;
import java.util.ArrayList;
import java.util.HashMap;

public class ListAdapterBtn extends SimpleAdapter
{

    Boolean bgColor;
    ArrayList listMap;
    int selected;
    String selectedColor;

    public ListAdapterBtn(Context context, ArrayList arraylist, int i, String as[], int ai[])
    {
        super(context, arraylist, i, as, ai);
        selected = -1;
        selectedColor = "#66FF0000";
        listMap = arraylist;
        bgColor = Boolean.valueOf(false);
    }

    public ListAdapterBtn(Context context, ArrayList arraylist, int i, String as[], int ai[], Boolean boolean1)
    {
        super(context, arraylist, i, as, ai);
        selected = -1;
        selectedColor = "#66FF0000";
        listMap = arraylist;
        bgColor = boolean1;
    }

    public View getView(int i, View view, ViewGroup viewgroup)
    {
        View view1;
        view1 = super.getView(i, view, viewgroup);
        view1.setBackgroundColor(0x30262626);
        if (!bgColor.booleanValue()) goto _L2; else goto _L1
_L1:
        HashMap hashmap = (HashMap)listMap.get(i);
        if (selected != -1) goto _L4; else goto _L3
_L3:
        if (!((String)hashmap.get("bgcolor")).equals(""))
        {
            view1.setBackgroundColor(Color.parseColor((String)hashmap.get("bgcolor")));
        }
_L2:
        Exception exception1;
        try
        {
            Button button = (Button)view1.findViewById(0x7f090047);
            button.setTag(button.getText().toString());
        }
        catch (Exception exception)
        {
            return view1;
        }
        return view1;
_L4:
        if (i != selected) goto _L2; else goto _L5
_L5:
        view1.setBackgroundColor(Color.parseColor(selectedColor));
          goto _L2
        exception1;
          goto _L2
    }
}
