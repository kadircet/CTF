// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            HatBilgileri, Global, OtobusNeredeMap

class this._cls0
    implements android.widget.temLongClickListener
{

    final HatBilgileri this$0;

    public boolean onItemLongClick(AdapterView adapterview, View view, int i, long l)
    {
        ListView listview = (ListView)findViewById(0x7f090010);
        Intent intent;
        try
        {
            if (SeciliOtobus > -1)
            {
                listview.getChildAt(SeciliOtobus).setBackgroundColor(0x30262626);
            }
        }
        catch (Exception exception) { }
        SeciliOtobus = i;
        view.setBackgroundColor(Color.parseColor("#66FF0000"));
        Global.App_Otobus_No = (String)((HashMap)listview.getItemAtPosition(i)).get("kod");
        intent = new Intent(getBaseContext(), com/ego/android/OtobusNeredeMap);
        startActivityForResult(intent, 0);
        return true;
    }

    ()
    {
        this$0 = HatBilgileri.this;
        super();
    }
}
