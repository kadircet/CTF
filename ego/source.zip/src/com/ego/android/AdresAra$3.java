// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.os.Handler;

// Referenced classes of package com.ego.android:
//            AdresAra

class this._cls0
    implements Runnable
{

    final AdresAra this$0;

    public void run()
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (handlerStatus)
        {
            handlerStatus = false;
            Location();
        }
    }

    ()
    {
        this$0 = AdresAra.this;
        super();
    }
}
