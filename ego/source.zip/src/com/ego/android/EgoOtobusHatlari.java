// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;

// Referenced classes of package com.ego.android:
//            Tools, MainMenu

public class EgoOtobusHatlari extends Activity
{

    ProgressDialog dialog;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    boolean ilkCalisma;

    public EgoOtobusHatlari()
    {
        handler = new Handler();
        handlerStatus = true;
        ilkCalisma = true;
    }

    public void CloseApplication(int i)
    {
        if (i > 0)
        {
            long l = i;
            try
            {
                Thread.sleep(l);
            }
            catch (Exception exception) { }
        }
        finish();
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        CloseApplication(0);
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(0x7f030009);
        dialog = Tools.Waiting(this);
        if (ilkCalisma)
        {
            ilkCalisma = false;
            handlerRunnable = new Runnable() {

                final EgoOtobusHatlari this$0;

                public void run()
                {
                    try
                    {
                        dialog.dismiss();
                    }
                    catch (Exception exception) { }
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Intent intent = new Intent(getBaseContext(), com/ego/android/MainMenu);
                        startActivityForResult(intent, 0);
                    }
                }

            
            {
                this$0 = EgoOtobusHatlari.this;
                super();
            }
            };
            dialog.show();
            handler.postDelayed(handlerRunnable, 1000L);
            return;
        } else
        {
            CloseApplication(0);
            return;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "\307\u0131k\u0131\u015F");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 1: default 24
    //                   1 30;
           goto _L1 _L2
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        CloseApplication(0);
        if (true) goto _L1; else goto _L3
_L3:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
