// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Ayarlar, Global, Tools, ListAdapter, 
//            Http, SorunlarBildir, SorunlarListe

public class Sorunlar extends Activity
{

    ProgressDialog dialog;
    Http http;

    public Sorunlar()
    {
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i == 200)
        {
            s.equals("");
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
            return;
        }
    }

    public void Ayarlar()
    {
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/Ayarlar), 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Ayarlar();
                return;
            }
            if (!s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (j == 10)
        {
            ((EditText)findViewById(0x7f090013)).setText(Global.Set_AdSoyad);
            ((EditText)findViewById(0x7f090014)).setText(Global.Set_Telefon);
            ((EditText)findViewById(0x7f090015)).setText(Global.Set_EPosta);
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030033);
        dialog = Tools.Waiting(this);
        ((EditText)findViewById(0x7f090013)).setText(Global.Set_AdSoyad);
        ((EditText)findViewById(0x7f090014)).setText(Global.Set_Telefon);
        ((EditText)findViewById(0x7f090015)).setText(Global.Set_EPosta);
        ListView listview = (ListView)findViewById(0x7f090067);
        ArrayList arraylist = new ArrayList();
        new HashMap();
        HashMap hashmap = new HashMap();
        hashmap.put("id", "0");
        hashmap.put("tanim", "Sorun Bildir");
        hashmap.put("aciklama", "Sorun, \326neri veya Dileklerinizi Kuruma Bildirme");
        arraylist.add(hashmap);
        HashMap hashmap1 = new HashMap();
        hashmap1.put("id", "1");
        hashmap1.put("tanim", "Bildirdi\u011Fim Sorunlar");
        hashmap1.put("aciklama", "Bildirdi\u011Finiz Sorunlar\u0131n Listesi ve Detay\u0131");
        arraylist.add(hashmap1);
        listview.setAdapter(new ListAdapter(this, arraylist, 0x7f03001f, new String[] {
            "tanim", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046
        }));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final Sorunlar this$0;

            public void onItemClick(AdapterView adapterview, View view, int i, long l)
            {
                HashMap hashmap2 = (HashMap)((ListView)findViewById(0x7f090067)).getItemAtPosition(i);
                if (Global.Set_AdSoyad.equals("") || Global.Set_Telefon.equals("") || Global.Set_EPosta.equals(""))
                {
                    Toast.makeText(getBaseContext(), "Kullan\u0131c\u0131 Bilgilerinizi\nAyarlar B\366l\374m\374nden Giriniz!", 1).show();
                } else
                {
                    if (hashmap2.get("id") == "0")
                    {
                        Intent intent = new Intent(getBaseContext(), com/ego/android/SorunlarBildir);
                        startActivityForResult(intent, 0);
                    }
                    if (hashmap2.get("id") == "1")
                    {
                        Intent intent1 = new Intent(getBaseContext(), com/ego/android/SorunlarListe);
                        startActivityForResult(intent1, 0);
                        return;
                    }
                }
            }

            
            {
                this$0 = Sorunlar.this;
                super();
            }
        });
        if (Global.Set_AdSoyad.equals("") || Global.Set_Telefon.equals("") || Global.Set_EPosta.equals(""))
        {
            Toast.makeText(getBaseContext(), "Kullan\u0131c\u0131 Bilgilerinizi\nAyarlar B\366l\374m\374nden Giriniz!", 1).show();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
