// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.util.FloatMath;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package com.ego.android:
//            BalloonItemizedOverlay, Global

public final class Map
{

    public Map()
    {
    }

    public static void CloseBalloon(MapView mapview)
    {
        Iterator iterator = mapview.getOverlays().iterator();
        do
        {
            Overlay overlay;
            do
            {
                if (!iterator.hasNext())
                {
                    return;
                }
                overlay = (Overlay)iterator.next();
            } while (!(overlay instanceof BalloonItemizedOverlay));
            ((BalloonItemizedOverlay)overlay).hideBalloon();
        } while (true);
    }

    static double Distance(float f, float f1, float f2, float f3)
    {
        float f4 = f / 57.294F;
        float f5 = f1 / 57.294F;
        float f6 = f2 / 57.294F;
        float f7 = f3 / 57.294F;
        float f8 = FloatMath.cos(f4) * FloatMath.cos(f5) * FloatMath.cos(f6) * FloatMath.cos(f7);
        float f9 = FloatMath.cos(f4) * FloatMath.sin(f5) * FloatMath.cos(f6) * FloatMath.sin(f7);
        return 6366000D * Math.acos(FloatMath.sin(f4) * FloatMath.sin(f6) + (f8 + f9));
    }

    static double Distance(String s, String s1, String s2, String s3)
    {
        return Distance(Float.parseFloat(s), Float.parseFloat(s1), Float.parseFloat(s2), Float.parseFloat(s3));
    }

    public static GeoPoint GP(String s, String s1)
    {
        double d;
        double d2;
        d = Double.parseDouble(s);
        d2 = Double.parseDouble(s1);
        double d1 = d2;
_L1:
        Exception exception;
        GeoPoint geopoint;
        try
        {
            geopoint = new GeoPoint((int)(d * 1000000D), (int)(d1 * 1000000D));
        }
        catch (Exception exception1)
        {
            return null;
        }
        return geopoint;
        exception;
        d = Global.App_Merkez_Lat;
        d1 = Global.App_Merkez_Lng;
          goto _L1
    }
}
