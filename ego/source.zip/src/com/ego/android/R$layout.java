// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;


// Referenced classes of package com.ego.android:
//            R

public static final class 
{

    public static final int adresara = 0x7f030000;
    public static final int adresmap = 0x7f030001;
    public static final int alarm = 0x7f030002;
    public static final int ayarlar = 0x7f030003;
    public static final int balloon_map_overlay = 0x7f030004;
    public static final int dialog = 0x7f030005;
    public static final int duraktangecenhatlar = 0x7f030006;
    public static final int duyurular = 0x7f030007;
    public static final int duyurulardetay = 0x7f030008;
    public static final int egootobushatlari = 0x7f030009;
    public static final int favorilerim = 0x7f03000a;
    public static final int favorilerimdurak = 0x7f03000b;
    public static final int favorilerimdurakduzenle = 0x7f03000c;
    public static final int favorilerimhat = 0x7f03000d;
    public static final int favorilerimhatduzenle = 0x7f03000e;
    public static final int hatara = 0x7f03000f;
    public static final int hatbilgileri = 0x7f030010;
    public static final int hatduraklar = 0x7f030011;
    public static final int hatmap = 0x7f030012;
    public static final int konummap = 0x7f030013;
    public static final int listadres = 0x7f030014;
    public static final int listadresbtn = 0x7f030015;
    public static final int listayar = 0x7f030016;
    public static final int listdurak = 0x7f030017;
    public static final int listdurakbtn = 0x7f030018;
    public static final int listduyuru = 0x7f030019;
    public static final int listhat = 0x7f03001a;
    public static final int listhatbtn = 0x7f03001b;
    public static final int listhatdurak = 0x7f03001c;
    public static final int listhatotobus = 0x7f03001d;
    public static final int listhatsaat = 0x7f03001e;
    public static final int listmenu = 0x7f03001f;
    public static final int listonemliyer = 0x7f030020;
    public static final int listonemliyerbtn = 0x7f030021;
    public static final int listotobus = 0x7f030022;
    public static final int listotobusbtn = 0x7f030023;
    public static final int listpanel = 0x7f030024;
    public static final int listsorun = 0x7f030025;
    public static final int mainmenu = 0x7f030026;
    public static final int nasilgiderim = 0x7f030027;
    public static final int nasilgiderimdetay = 0x7f030028;
    public static final int nasilgiderimliste = 0x7f030029;
    public static final int nasilgiderimmap = 0x7f03002a;
    public static final int neredeyim = 0x7f03002b;
    public static final int onemliyerler = 0x7f03002c;
    public static final int onemliyerlerdetay = 0x7f03002d;
    public static final int otobusnerede = 0x7f03002e;
    public static final int otobusneredemap = 0x7f03002f;
    public static final int panelim = 0x7f030030;
    public static final int panelimduzenle = 0x7f030031;
    public static final int progress = 0x7f030032;
    public static final int sorunlar = 0x7f030033;
    public static final int sorunlarbildir = 0x7f030034;
    public static final int sorunlardetay = 0x7f030035;
    public static final int sorunlarliste = 0x7f030036;
    public static final int template = 0x7f030037;
    public static final int yakindakiduraklar = 0x7f030038;
    public static final int yakindakidurakvehatlar = 0x7f030039;
    public static final int yakindakihatlar = 0x7f03003a;

    public ()
    {
    }
}
