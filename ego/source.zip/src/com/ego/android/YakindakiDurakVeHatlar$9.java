// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Dialog;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

// Referenced classes of package com.ego.android:
//            YakindakiDurakVeHatlar, Global, FavorilerimDurakDuzenle, OtobusNerede

class val.dialogBox
    implements android.view.._cls9
{

    final YakindakiDurakVeHatlar this$0;
    private final Dialog val$dialogBox;

    public void onClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        val$dialogBox.dismiss();
        try
        {
            String as[] = s.split(";");
            if (as[0].equals("Durak"))
            {
                if (as[1].equals("0"))
                {
                    Global.App_Favorilerim_Durak_Ekle = as[2];
                    Intent intent1 = new Intent(getBaseContext(), com/ego/android/FavorilerimDurakDuzenle);
                    startActivityForResult(intent1, 0);
                }
                if (as[1].equals("1"))
                {
                    Global.App_Durak_No = as[2];
                    Intent intent = new Intent(getBaseContext(), com/ego/android/OtobusNerede);
                    startActivityForResult(intent, 0);
                }
            }
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    ()
    {
        this$0 = final_yakindakidurakvehatlar;
        val$dialogBox = Dialog.this;
        super();
    }
}
