// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.widget.Button;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;
import com.google.android.maps.Projection;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package com.ego.android:
//            BalloonOverlayView

public abstract class BalloonItemizedOverlay extends ItemizedOverlay
{

    private BalloonOverlayView balloonView;
    public String button1Title;
    public String button2Title;
    public String button3Title;
    public String itemText;
    public String itemTitle;
    private MapView mapView;
    final MapController mc;

    public BalloonItemizedOverlay(Drawable drawable, MapView mapview)
    {
        super(drawable);
        itemTitle = "";
        itemText = "";
        button1Title = "";
        button2Title = "";
        button3Title = "";
        mapView = mapview;
        mc = mapview.getController();
    }

    private void hideOtherBalloons(List list)
    {
        Iterator iterator = list.iterator();
        do
        {
            Overlay overlay;
            do
            {
                if (!iterator.hasNext())
                {
                    return;
                }
                overlay = (Overlay)iterator.next();
            } while (!(overlay instanceof BalloonItemizedOverlay) || overlay == this);
            ((BalloonItemizedOverlay)overlay).hideBalloon();
        } while (true);
    }

    public void buttonClick(int i)
    {
    }

    public void hideBalloon()
    {
        if (balloonView != null)
        {
            balloonView.setVisibility(8);
        }
    }

    protected final boolean onTap(int i)
    {
        com.google.android.maps.GeoPoint geopoint = createItem(i).getPoint();
        if (balloonView != null) goto _L2; else goto _L1
_L1:
        balloonView = new BalloonOverlayView(mapView.getContext(), 0);
        balloonView.addObserver(new BalloonOverlayView.Callback() {

            final BalloonItemizedOverlay this$0;

            public void onButtonClick(int j)
            {
                hideBalloon();
                buttonClick(j);
            }

            
            {
                this$0 = BalloonItemizedOverlay.this;
                super();
            }
        });
        boolean flag = false;
_L5:
        com.google.android.maps.MapView.LayoutParams layoutparams;
        Projection projection;
        Point point;
        com.google.android.maps.GeoPoint geopoint1;
        try
        {
            balloonView.setVisibility(8);
            setButton1(button1Title);
            setButton2(button2Title);
            setButton3(button3Title);
            List list = mapView.getOverlays();
            if (list.size() > 1)
            {
                hideOtherBalloons(list);
            }
            balloonView.setData(createItem(i));
            if (!itemTitle.equals(""))
            {
                balloonView.setTitle(itemTitle);
            }
            if (!itemText.equals(""))
            {
                balloonView.setText(itemText);
            }
            layoutparams = new com.google.android.maps.MapView.LayoutParams(-2, -2, geopoint, 81);
            layoutparams.mode = 0;
            balloonView.setVisibility(0);
        }
        catch (Exception exception)
        {
            return true;
        }
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_281;
        }
        balloonView.setLayoutParams(layoutparams);
_L3:
        projection = mapView.getProjection();
        point = new Point();
        projection.toPixels(geopoint, point);
        point.offset(0, -75);
        geopoint1 = projection.fromPixels(point.x, point.y);
        mc.setCenter(geopoint1);
        return true;
        mapView.addView(balloonView, layoutparams);
          goto _L3
_L2:
        flag = true;
        if (true) goto _L5; else goto _L4
_L4:
    }

    public void setButton1(String s)
    {
        Button button = (Button)balloonView.findViewById(0x7f09001c);
        button.setVisibility(8);
        if (!s.equals(""))
        {
            button.setText(s);
            button.setVisibility(0);
        }
    }

    public void setButton2(String s)
    {
        Button button = (Button)balloonView.findViewById(0x7f09001d);
        button.setVisibility(8);
        if (!s.equals(""))
        {
            button.setText(s);
            button.setVisibility(0);
        }
    }

    public void setButton3(String s)
    {
        Button button = (Button)balloonView.findViewById(0x7f09001e);
        button.setVisibility(8);
        if (!s.equals(""))
        {
            button.setText(s);
            button.setVisibility(0);
        }
    }

    public void setText(String s)
    {
        itemText = s;
    }

    public void setTitle(String s)
    {
        itemTitle = s;
    }
}
