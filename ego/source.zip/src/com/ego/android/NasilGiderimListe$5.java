// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            NasilGiderimListe, Global, NasilGiderimDetay

class this._cls0
    implements android.widget.ickListener
{

    final NasilGiderimListe this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        Global.App_NasilGiderim = (HashMap)((ListView)findViewById(0x7f09005f)).getItemAtPosition(i);
        Intent intent = new Intent(getBaseContext(), com/ego/android/NasilGiderimDetay);
        startActivityForResult(intent, 0);
    }

    ckListener()
    {
        this$0 = NasilGiderimListe.this;
        super();
    }
}
