// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

// Referenced classes of package com.ego.android:
//            BalloonItemizedOverlay

public class MapOverlay extends BalloonItemizedOverlay
{
    public static interface Callback
    {

        public abstract void onButtonClick(String s, OverlayItem overlayitem, String as[], int i);
    }


    private Set callbacks;
    private String m_action;
    private OverlayItem m_overlay;
    private ArrayList m_overlays;
    private String m_parameters[];

    public MapOverlay(Drawable drawable, MapView mapview)
    {
        super(boundCenter(drawable), mapview);
        m_overlays = new ArrayList();
        m_action = "";
        callbacks = new HashSet();
        m_action = "";
        m_parameters = null;
        button1Title = "";
        button2Title = "";
        button3Title = "";
    }

    public MapOverlay(String s, Drawable drawable, MapView mapview)
    {
        super(boundCenter(drawable), mapview);
        m_overlays = new ArrayList();
        m_action = "";
        callbacks = new HashSet();
        m_action = s;
        m_parameters = null;
        button1Title = "";
        button2Title = "";
        button3Title = "";
    }

    public MapOverlay(String s, Drawable drawable, MapView mapview, String as[], String s1, String s2, String s3)
    {
        super(boundCenter(drawable), mapview);
        m_overlays = new ArrayList();
        m_action = "";
        callbacks = new HashSet();
        m_action = s;
        m_parameters = as;
        button1Title = s1;
        button2Title = s2;
        button3Title = s3;
    }

    public void addObserver(Callback callback)
    {
        callbacks.add(callback);
    }

    public void addOverlay(OverlayItem overlayitem)
    {
        m_overlays.add(overlayitem);
        m_overlay = overlayitem;
        populate();
    }

    public void buttonClick(int i)
    {
        Iterator iterator = callbacks.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                return;
            }
            ((Callback)iterator.next()).onButtonClick(m_action, m_overlay, m_parameters, i);
        } while (true);
    }

    protected OverlayItem createItem(int i)
    {
        return (OverlayItem)m_overlays.get(i);
    }

    public void draw(Canvas canvas, MapView mapview, boolean flag)
    {
        super.draw(canvas, mapview, false);
    }

    public void setText(String s)
    {
        itemText = s;
    }

    public void setTitle(String s)
    {
        itemTitle = s;
    }

    public int size()
    {
        return m_overlays.size();
    }
}
