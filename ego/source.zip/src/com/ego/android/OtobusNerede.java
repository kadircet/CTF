// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, ListAdapterBtn, Global, ListAdapter, 
//            AdresAra, FavorilerimDurak, OtobusNeredeMap, Gps, 
//            Tools, YakindakiDuraklar, HatBilgileri

public class OtobusNerede extends Activity
{

    ProgressDialog dialog;
    Gps gps;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    boolean pageStatus;

    public OtobusNerede()
    {
        pageStatus = false;
        handler = new Handler();
        handlerStatus = false;
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        Exception exception1;
        boolean flag;
        ListView listview;
        ArrayList arraylist;
        HashMap hashmap;
        String s3;
        int j;
        int k;
        HashMap hashmap1;
        Exception exception2;
        Boolean boolean2;
        int l;
        HashMap hashmap2;
        Exception exception3;
        Exception exception4;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        handlerStop();
        if (pageStatus) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if (i != 200) goto _L4; else goto _L3
_L3:
        try
        {
            flag = s.equals("FavoriAra");
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception1)
        {
            return;
        }
        if (!flag) goto _L6; else goto _L5
_L5:
        if (http.JValue(0, "no").equals("")) goto _L8; else goto _L7
_L7:
        ((EditText)findViewById(0x7f090000)).setText(http.JValue(0, "no"));
        Toast.makeText(getBaseContext(), "Favori Dura\u011F\u0131n\u0131z", 1).show();
_L6:
        if (!s.equals("DurakAra")) goto _L1; else goto _L9
_L9:
        listview = (ListView)findViewById(0x7f090010);
        arraylist = new ArrayList();
        hashmap = new HashMap();
        s3 = ((EditText)findViewById(0x7f090000)).getText().toString();
        j = 0;
        k = 0;
        hashmap1 = hashmap;
_L20:
        l = http.jArray.length();
        if (k < l) goto _L11; else goto _L10
_L10:
        hashmap1;
_L22:
        boolean2 = Boolean.valueOf(((CheckBox)findViewById(0x7f090001)).isChecked());
        if (j != 0) goto _L13; else goto _L12
_L12:
        if (!http.JString("status").equals("false")) goto _L15; else goto _L14
_L14:
        Toast.makeText(getBaseContext(), http.JString("error"), 1).show();
_L13:
        if (!boolean2.booleanValue()) goto _L17; else goto _L16
_L16:
        listview.setAdapter(new ListAdapterBtn(this, arraylist, 0x7f030023, new String[] {
            "no", "tanim", "kod", "plaka", "hiz", "sure", "aciklama", "arac", "btn"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090049, 0x7f09004a, 0x7f09004b, 0x7f09004f, 0x7f090048, 0x7f090050, 0x7f090047
        }));
_L21:
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final OtobusNerede this$0;

            public void onItemClick(AdapterView adapterview, View view, int i1, long l1)
            {
                HashMap hashmap3 = (HashMap)((ListView)findViewById(0x7f090010)).getItemAtPosition(i1);
                Global.App_Hat_No = (String)hashmap3.get("no");
                Global.App_Durak_No = ((EditText)findViewById(0x7f090000)).getText().toString();
                Global.App_Otobus_No = (String)hashmap3.get("kod");
                Intent intent = new Intent(getBaseContext(), com/ego/android/HatBilgileri);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = OtobusNerede.this;
                super();
            }
        });
        listview.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final OtobusNerede this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int i1, long l1)
            {
                HashMap hashmap3 = (HashMap)((ListView)findViewById(0x7f090010)).getItemAtPosition(i1);
                Global.App_Hat_No = (String)hashmap3.get("no");
                Global.App_Durak_No = ((EditText)findViewById(0x7f090000)).getText().toString();
                Global.App_Otobus_No = (String)hashmap3.get("kod");
                Intent intent = new Intent(getBaseContext(), com/ego/android/OtobusNeredeMap);
                startActivityForResult(intent, 0);
                return true;
            }

            
            {
                this$0 = OtobusNerede.this;
                super();
            }
        });
        if (!boolean2.booleanValue() || j <= 0) goto _L1; else goto _L18
_L18:
        if (Global.App_OtobusYenilemeSuresi <= 0) goto _L1; else goto _L19
_L19:
        Yenile(Global.App_OtobusYenilemeSuresi);
        return;
_L8:
        try
        {
            ((InputMethodManager)getSystemService("input_method")).toggleSoftInput(2, 0);
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception4) { }
          goto _L6
_L11:
        j++;
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(k).toString());
        hashmap2.put("no", http.JValue(k, "hatkod"));
        hashmap2.put("tanim", http.JValue(k, "hatad"));
        hashmap2.put("aciklama", http.JValue(k, "aciklama"));
        hashmap2.put("arac", http.JValue(k, "arac"));
        hashmap2.put("kod", http.JValue(k, "kod"));
        hashmap2.put("plaka", http.JValue(k, "plaka"));
        hashmap2.put("hiz", http.JValue(k, "hiz"));
        hashmap2.put("sure", http.JValue(k, "sure"));
        hashmap2.put("btn", (new StringBuilder(String.valueOf(http.JValue(k, "hatkod")))).append(";").append(s3).append(";").append(http.JValue(k, "kod")).toString());
        arraylist.add(hashmap2);
        k++;
        hashmap1 = hashmap2;
          goto _L20
_L15:
label0:
        {
            if (!boolean2.booleanValue())
            {
                break label0;
            }
            Toast.makeText(getBaseContext(), "Dura\u011Fa Yakla\u015Fan \u015Eu Anda Otob\374s Yok!", 1).show();
        }
          goto _L13
        Toast.makeText(getBaseContext(), "Duraktan Ge\347en Hat Yok!", 1).show();
          goto _L13
_L17:
        listview.setAdapter(new ListAdapter(this, arraylist, 0x7f03001a, new String[] {
            "no", "tanim", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048
        }));
          goto _L21
_L4:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception2;
        hashmap1;
          goto _L22
        exception3;
          goto _L22
    }

    public void CloseKeyboard()
    {
        ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(0x7f090000).getWindowToken(), 0);
    }

    public void DurakAra()
    {
        Global.App_Adres_Sec = "DurakAra";
        Global.App_Durak_No = "";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/AdresAra), 0);
    }

    public void Favorilerim_OnClick(View view)
    {
        CloseKeyboard();
        handlerStop();
        Global.App_Durak_Sec = "Favorilerim";
        Global.App_Favorilerim_Durak_No = "";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimDurak), 0);
    }

    public void KlavyeX_OnClick(View view)
    {
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        ((EditText)findViewById(0x7f090000)).setText("");
        ((EditText)findViewById(0x7f090000)).requestFocus();
        inputmethodmanager.toggleSoftInput(2, 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        try
        {
            String as[] = s.split(";");
            if (as.length == 3)
            {
                Global.App_Hat_No = as[0];
                Global.App_Durak_No = as[1];
                Global.App_Otobus_No = as[2];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/OtobusNeredeMap), 0);
            }
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void Location()
    {
        gps = new Gps(this);
        gps.addObserver(new Gps.Callback() {

            final OtobusNerede this$0;

            public void onComplete(Location location)
            {
                Intent intent;
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location == null)
                {
                    try
                    {
                        Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                        return;
                    }
                    catch (Exception exception1)
                    {
                        return;
                    }
                }
                if (gps.GpsAdres.equals(""))
                {
                    Toast.makeText(getBaseContext(), "Adres Bulunamad\u0131!", 1).show();
                    return;
                }
                Global.App_Adres_Adres = gps.GpsAdres;
                Global.App_Adres_Ilce = gps.GpsIlce;
                Global.App_Adres_Lat = gps.GpsLat;
                Global.App_Adres_Lng = gps.GpsLng;
                Global.App_Adres_Query = "";
                Global.App_Adres_Sec = "DurakAra";
                Global.App_Durak_No = "";
                intent = new Intent(getBaseContext(), com/ego/android/YakindakiDuraklar);
                startActivityForResult(intent, 0);
                return;
            }

            
            {
                this$0 = OtobusNerede.this;
                super();
            }
        });
        gps.Start();
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final OtobusNerede this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = OtobusNerede.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void Sorgula_OnClick(View view)
    {
        CloseKeyboard();
        Yenile(0);
    }

    public void ToolBar_OnClick(View view)
    {
        CloseKeyboard();
        String s = view.getTag().toString();
        if (!s.equals("0"))
        {
            handlerStop();
        }
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Runnable("Location");
                return;
            }
            if (s.equals("3"))
            {
                DurakAra();
                return;
            }
            if (s.equals("4"))
            {
                Yenile(0);
                return;
            }
        }
    }

    public void Yenile(int i)
    {
        handlerStop();
        handlerRunnable = new Runnable() {

            final OtobusNerede this$0;

            public void run()
            {
label0:
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        CloseKeyboard();
                        String s = ((EditText)findViewById(0x7f090000)).getText().toString();
                        if (s.length() < 5)
                        {
                            break label0;
                        }
                        Global.App_Durak_Ara = ((EditText)findViewById(0x7f090000)).getText().toString();
                        Boolean boolean1 = Boolean.valueOf(((CheckBox)findViewById(0x7f090001)).isChecked());
                        OtobusNerede otobusnerede;
                        String as[];
                        String as1[];
                        if (boolean1.booleanValue())
                        {
                            ((LinearLayout)findViewById(0x7f090064)).setVisibility(0);
                        } else
                        {
                            ((LinearLayout)findViewById(0x7f090064)).setVisibility(8);
                        }
                        otobusnerede = OtobusNerede.this;
                        as = (new String[] {
                            "FNC", "DurakAra"
                        });
                        as1 = new String[4];
                        as1[0] = "QUERY";
                        as1[1] = s;
                        as1[2] = "TYPE";
                        as1[3] = boolean1.toString();
                        otobusnerede.http = new Http("DurakAra", "durak.asp", as, as1);
                        http.addObserver(new Http.Callback() {

                            final _cls3 this$1;

                            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
                            {
                                Action(s, s1, i, boolean1, s2);
                            }

            
            {
                this$1 = _cls3.this;
                super();
            }
                        });
                        dialog.show();
                        http.execute(new String[0]);
                    }
                    return;
                }
                Toast.makeText(getBaseContext(), "Durak Numaras\u0131\nEn Az 5 Basamakl\u0131 Say\u0131 Olmal\u0131!", 1).show();
            }


            
            {
                this$0 = OtobusNerede.this;
                super();
            }
        };
        if (i == 0)
        {
            handlerStatus = true;
            handler.postDelayed(handlerRunnable, 0L);
            return;
        } else
        {
            handlerStatus = true;
            handler.postDelayed(handlerRunnable, i);
            return;
        }
    }

    public void handlerStop()
    {
        handlerStatus = false;
        try
        {
            handler.removeCallbacks(handlerRunnable);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        handlerStop();
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (Global.App_Durak_Sec.equals("Favorilerim"))
        {
            if (j == 10 && !Global.App_Favorilerim_Durak_No.equals(""))
            {
                ((EditText)findViewById(0x7f090000)).setText(Global.App_Favorilerim_Durak_No);
                Sorgula_OnClick(null);
            }
            Global.App_Durak_Sec = "";
            Global.App_Favorilerim_Durak_No = "";
        }
        if (Global.App_Adres_Sec.equals("DurakAra"))
        {
            if (j == 10 && !Global.App_Durak_No.equals(""))
            {
                ((EditText)findViewById(0x7f090000)).setText(Global.App_Durak_No);
                Sorgula_OnClick(null);
            }
            Global.App_Adres_Sec = "";
            Global.App_Durak_No = "";
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03002e);
        dialog = Tools.Waiting(this);
        ((EditText)findViewById(0x7f090000)).setText(Global.App_Durak_Ara);
        if (!Global.App_Durak_No.equals(""))
        {
            ((EditText)findViewById(0x7f090000)).setText(Global.App_Durak_No);
            Global.App_Durak_No = "";
            Sorgula_OnClick(null);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    public void onResume()
    {
        super.onResume();
        pageStatus = true;
    }

    protected void onStop()
    {
        pageStatus = false;
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        CloseKeyboard();
        handlerStop();
        super.onStop();
    }
}
