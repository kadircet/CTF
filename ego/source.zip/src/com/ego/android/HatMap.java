// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.ego.android:
//            Global, Http, Map, MapDraw, 
//            MapOverlay, Gps, YakindakiDurakVeHatlar, DuraktanGecenHatlar, 
//            FavorilerimDurakDuzenle, Tools

public class HatMap extends MapActivity
{

    GeoPoint BekledigimDurak;
    boolean DuraklariGoster;
    boolean IlkGoster;
    boolean OtobusBilgisiText;
    String OtobusNo;
    boolean OtobusleriTakipEt;
    Menu appMenu;
    ProgressDialog dialog;
    Gps gps;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    long lastTouchDoubleTime;
    List lo;
    boolean location;
    String locationAdres;
    String locationIlce;
    int locationOverlay;
    GeoPoint locationPosition;
    ArrayList lstmapDurak;
    ArrayList lstmapYol;
    MapController mc;
    MapView mv;
    int otobusOverlay;
    boolean pageStatus;
    SeekBar seekBar;
    TextView seekBarNumber;
    int zoom;

    public HatMap()
    {
        pageStatus = true;
        lastTouchDoubleTime = -1L;
        location = false;
        locationAdres = "";
        locationIlce = "";
        locationOverlay = -1;
        otobusOverlay = -1;
        handler = new Handler();
        handlerStatus = false;
        lstmapYol = new ArrayList();
        lstmapDurak = new ArrayList();
        IlkGoster = true;
        DuraklariGoster = true;
        OtobusleriTakipEt = true;
        BekledigimDurak = null;
        OtobusNo = "";
        zoom = Integer.parseInt(Global.Set_Yaklasim);
        OtobusBilgisiText = false;
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        HashMap hashmap;
        Exception exception1;
        int j;
        Exception exception2;
        int k;
        Exception exception3;
        JSONArray jsonarray;
        int l;
        int i1;
        int j1;
        JSONObject jsonobject;
        int k1;
        int l1;
        JSONObject jsonobject1;
        GeoPoint geopoint;
        boolean flag;
        int i2;
        int j2;
        byte byte0;
        String s3;
        JSONArray jsonarray1;
        int k2;
        HashMap hashmap1;
        Exception exception4;
        int l2;
        JSONObject jsonobject2;
        HashMap hashmap2;
        String as1[];
        int i3;
        HashMap hashmap3;
        Exception exception5;
        int j3;
        String as2[];
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (pageStatus) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if (i != 200) goto _L4; else goto _L3
_L3:
        if (!s.equals("Hat"))
        {
            continue; /* Loop/switch isn't completed */
        }
        hashmap = new HashMap();
        lstmapYol.clear();
        lstmapDurak.clear();
        ((TextView)findViewById(0x7f09003f)).setText((new StringBuilder(String.valueOf(http.JValue(0, "kod")))).append(" - ").append(http.JValue(0, "ad")).toString());
        as1 = http.JValue(0, "yol").split(" ");
        i3 = 0;
        hashmap3 = hashmap;
_L21:
        j3 = as1.length;
        if (i3 < j3) goto _L6; else goto _L5
_L5:
        Isaretle("Yol", null, zoom, "");
        hashmap = hashmap3;
_L26:
        j = 0;
        jsonarray1 = http.JArray(0, "durak");
        k2 = 0;
        hashmap1 = hashmap;
_L22:
        l2 = jsonarray1.length();
        if (k2 < l2) goto _L8; else goto _L7
_L7:
        Isaretle("Durak", null, zoom, "");
        hashmap1;
_L25:
        seekBar.setProgress(0);
        seekBar.setMax(j - 1);
        seekBarNumber.setText("1");
        mv.invalidate();
        if (Global.App_OtobusYenilemeSuresi > 0)
        {
            OtobusYenile(0);
        }
        if (!s.equals("OtobusAra")) goto _L1; else goto _L9
_L9:
        if (otobusOverlay == -1) goto _L11; else goto _L10
_L10:
        if (mv.getOverlays().size() > otobusOverlay) goto _L13; else goto _L12
_L12:
        mv.invalidate();
_L11:
        ((Button)findViewById(0x7f090040)).setVisibility(0);
        ((Button)findViewById(0x7f090041)).setVisibility(8);
        k = 0;
        jsonarray = http.JArray(0, "otobus");
        l = 0;
        i1 = 0;
_L27:
        j1 = jsonarray.length();
        if (i1 < j1) goto _L15; else goto _L14
_L14:
        k1 = 0;
_L23:
        l1 = jsonarray.length();
        if (k1 < l1) goto _L17; else goto _L16
_L16:
        if (k <= 0) goto _L19; else goto _L18
_L18:
        if (Global.App_OtobusYenilemeSuresi <= 0) goto _L1; else goto _L20
_L20:
        OtobusYenile(Global.App_OtobusYenilemeSuresi);
        return;
_L6:
        as2 = as1[i3].split(",");
        hashmap = new HashMap();
        String s5 = as2[1];
        hashmap.put("lat", s5);
        String s6 = as2[0];
        hashmap.put("lng", s6);
        lstmapYol.add(hashmap);
        i3++;
        hashmap3 = hashmap;
          goto _L21
_L8:
        j++;
        jsonobject2 = jsonarray1.getJSONObject(k2);
        hashmap2 = new HashMap();
        hashmap2.put("sno", jsonobject2.getString("sno"));
        hashmap2.put("ad", jsonobject2.getString("ad"));
        hashmap2.put("yer", jsonobject2.getString("yer"));
        hashmap2.put("aciklama", jsonobject2.getString("aciklama"));
        hashmap2.put("lat", jsonobject2.getString("lat"));
        hashmap2.put("lng", jsonobject2.getString("lng"));
        lstmapDurak.add(hashmap2);
        k2++;
        hashmap1 = hashmap2;
          goto _L22
_L13:
        mv.getOverlays().remove(otobusOverlay);
          goto _L10
_L15:
        jsonobject = jsonarray.getJSONObject(i1);
        if (Global.App_Otobus_No.equals(jsonobject.getString("kod")))
        {
            l = i1;
        }
        break MISSING_BLOCK_LABEL_1704;
_L17:
        k++;
        jsonobject1 = jsonarray.getJSONObject(k1);
        geopoint = Map.GP((new StringBuilder()).append(jsonobject1.getString("lat")).toString(), (new StringBuilder()).append(jsonobject1.getString("lng")).toString());
        if (k1 != l)
        {
            break MISSING_BLOCK_LABEL_1051;
        }
        if (OtobusleriTakipEt)
        {
            mc.setCenter(geopoint);
            CreateMarker("", 0x7f02001c, geopoint, null, "", "", "", "", "");
            String s4 = (new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf(""))).append("Ara\347 No: ").append(jsonobject1.getString("kod")).append("\n").toString()))).append("Plaka: ").append(jsonobject1.getString("plaka")).append("\n").toString()))).append("H\u0131z: ").append(jsonobject1.getString("hiz")).append("\n").toString()))).append("T.V.S\374resi: ").append(jsonobject1.getString("sure")).append("\n").toString()))).append(jsonobject1.getString("aciklama").replace(", Konumu:", "\nKonumu:")).toString();
            if (!jsonobject1.getString("arac").equals(""))
            {
                s4 = (new StringBuilder(String.valueOf(s4))).append("\nAra\347: ").append(jsonobject1.getString("arac")).toString();
            }
            ((Button)findViewById(0x7f090041)).setText(s4);
            if (!OtobusBilgisiText)
            {
                break MISSING_BLOCK_LABEL_1587;
            }
            ((Button)findViewById(0x7f090040)).setVisibility(8);
            ((Button)findViewById(0x7f090041)).setVisibility(0);
        }
_L24:
        flag = jsonobject1.getString("yon").equals("0");
        i2 = 0;
        if (flag)
        {
            i2 = 0x7f020014;
        }
        if (jsonobject1.getString("yon").equals("1"))
        {
            i2 = 0x7f020015;
        }
        if (jsonobject1.getString("yon").equals("2"))
        {
            i2 = 0x7f020016;
        }
        if (jsonobject1.getString("yon").equals("3"))
        {
            i2 = 0x7f020017;
        }
        if (jsonobject1.getString("yon").equals("4"))
        {
            i2 = 0x7f020018;
        }
        if (jsonobject1.getString("yon").equals("5"))
        {
            i2 = 0x7f020019;
        }
        if (jsonobject1.getString("yon").equals("6"))
        {
            i2 = 0x7f02001a;
        }
        if (jsonobject1.getString("yon").equals("7"))
        {
            i2 = 0x7f02001b;
        }
        j2 = (new StringBuilder()).append(k).toString().length();
        if (j2 == 1)
        {
            byte0 = -5;
        } else
        if (j2 == 2)
        {
            byte0 = -10;
        } else
        {
            byte0 = -15;
        }
        lo.add(new MapDraw("Text", geopoint, 16, 0xffff0000, Color.argb(20, 0, 0, 255), 2, byte0, -22, (new StringBuilder()).append(k).toString()));
        s3 = "";
        if (!jsonobject1.getString("arac").equals(""))
        {
            s3 = (new StringBuilder("\nAra\347: ")).append(jsonobject1.getString("arac")).toString();
        }
        String as[] = new String[6];
        as[0] = jsonobject1.getString("kod");
        as[1] = jsonobject1.getString("plaka");
        as[2] = jsonobject1.getString("hiz");
        as[3] = jsonobject1.getString("sure");
        as[4] = jsonobject1.getString("sno");
        as[5] = jsonobject1.getString("aciklama");
        CreateMarker("Otob\374s", i2, geopoint, as, "Otob\374s", (new StringBuilder("Ara\347 No: ")).append(jsonobject1.getString("kod")).append("\n").append("Plaka: ").append(jsonobject1.getString("plaka")).append("\n").append("H\u0131z: ").append(jsonobject1.getString("hiz")).append("\n").append("T.V.S\374resi: ").append(jsonobject1.getString("sure")).append("\n").append(jsonobject1.getString("aciklama")).append(s3).toString(), "Otob\374s\374 Takip Et", "", "");
        k1++;
          goto _L23
        ((Button)findViewById(0x7f090040)).setVisibility(0);
        ((Button)findViewById(0x7f090041)).setVisibility(8);
          goto _L24
        exception3;
          goto _L16
_L19:
        Toast.makeText(getBaseContext(), "Hat \334zerinde \u015Eu Anda Otob\374s Yok!", 1).show();
        return;
_L4:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception2;
          goto _L25
        exception4;
        hashmap1;
          goto _L25
        exception1;
          goto _L26
        exception5;
        hashmap = hashmap3;
          goto _L26
        i1++;
          goto _L27
    }

    public void CreateMarker(String s, int i, GeoPoint geopoint, String as[], String s1, String s2, String s3, 
            String s4, String s5)
    {
        MapOverlay mapoverlay = new MapOverlay(s, getResources().getDrawable(i), mv, as, s3, s4, s5);
        mapoverlay.addObserver(new MapOverlay.Callback() {

            final HatMap this$0;

            public void onButtonClick(String s6, OverlayItem overlayitem, String as1[], int j)
            {
                MarkerAction(s6, overlayitem, as1, j);
            }

            
            {
                this$0 = HatMap.this;
                super();
            }
        });
        mapoverlay.addOverlay(new OverlayItem(geopoint, s1, s2));
        lo.add(mapoverlay);
    }

    public void HatYenile()
    {
        String as[] = {
            "FNC", "Hat"
        };
        String as1[] = new String[4];
        as1[0] = "QUERY";
        as1[1] = Global.App_Hat_No;
        as1[2] = "YOL";
        as1[3] = "true";
        http = new Http("Hat", "hat.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final HatMap this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = HatMap.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void Isaretle(String s, GeoPoint geopoint, int i, String s1)
    {
        if (i > 0)
        {
            mc.setZoom(i);
        }
        Map.CloseBalloon(mv);
        if (location)
        {
            GeoPoint geopoint1;
            int j;
            int k;
            HashMap hashmap;
            GeoPoint geopoint2;
            int l;
            int i1;
            HashMap hashmap1;
            GeoPoint geopoint3;
            String as[];
            String as1[];
            int j1;
            byte byte0;
            try
            {
                if (locationOverlay != -1)
                {
                    mv.getOverlays().remove(locationOverlay);
                    mv.invalidate();
                }
            }
            catch (Exception exception) { }
            mc.setCenter(locationPosition);
            CreateMarker("Location", 0x7f020067, locationPosition, null, "Konumum", (new StringBuilder(String.valueOf(locationAdres))).append("\n").append(locationIlce).toString(), "Yak\u0131ndaki Durak ve Hatlar", "", "");
            locationOverlay = -1 + lo.size();
        }
        if (!s.equals("Yol")) goto _L2; else goto _L1
_L1:
        new HashMap();
        geopoint1 = null;
        j = 0;
_L6:
        k = lstmapYol.size();
        if (j < k) goto _L3; else goto _L2
_L2:
        if (!s.equals("Durak")) goto _L5; else goto _L4
_L4:
        new HashMap();
        l = 0;
_L7:
        i1 = lstmapDurak.size();
        if (l < i1)
        {
            break MISSING_BLOCK_LABEL_358;
        }
        IlkGoster = false;
        otobusOverlay = lo.size();
_L5:
        mv.invalidate();
        return;
_L3:
        hashmap = (HashMap)lstmapYol.get(j);
        geopoint2 = Map.GP((new StringBuilder()).append((String)hashmap.get("lat")).toString(), (new StringBuilder()).append((String)hashmap.get("lng")).toString());
        if (geopoint1 != null)
        {
            lo.add(new MapDraw("Line", geopoint1, geopoint2, Color.argb(60, 0, 0, 255), 5));
        }
        geopoint1 = geopoint2;
        j++;
          goto _L6
        hashmap1 = (HashMap)lstmapDurak.get(l);
        geopoint3 = Map.GP((new StringBuilder()).append((String)hashmap1.get("lat")).toString(), (new StringBuilder()).append((String)hashmap1.get("lng")).toString());
        if (IlkGoster && l == 0)
        {
            mc.setCenter(geopoint3);
        }
        if (Global.App_Durak_No.equals(hashmap1.get("ad")))
        {
            if (IlkGoster)
            {
                mc.setCenter(geopoint3);
                BekledigimDurak = geopoint3;
            }
            CreateMarker("", 0x7f020022, geopoint3, null, "", "", "", "", "");
        }
        if (DuraklariGoster)
        {
            as1 = new String[2];
            as1[0] = (String)hashmap1.get("ad");
            as1[1] = (String)hashmap1.get("yer");
            CreateMarker("Durak", 0x7f02001f, geopoint3, as1, (new StringBuilder("Durak ")).append((String)hashmap1.get("ad")).append(" (").append((String)hashmap1.get("sno")).append(")").toString(), (String)hashmap1.get("yer"), "Duraktan Ge\347en Hatlar", "Buraday\u0131m", "Favorilerime Ekle");
            j1 = ((String)hashmap1.get("sno")).length();
            if (j1 == 1)
            {
                byte0 = -4;
            } else
            if (j1 == 2)
            {
                byte0 = -7;
            } else
            {
                byte0 = -10;
            }
            lo.add(new MapDraw("Text", geopoint3, 12, 0xffff0000, Color.argb(20, 0, 0, 255), 1, byte0, -9, (String)hashmap1.get("sno")));
        } else
        if (Global.App_Durak_No.equals(hashmap1.get("ad")))
        {
            as = new String[2];
            as[0] = (String)hashmap1.get("ad");
            as[1] = (String)hashmap1.get("yer");
            CreateMarker("Durak", 0x7f02001d, geopoint3, as, (new StringBuilder("B.Durak ")).append((String)hashmap1.get("ad")).toString(), (String)hashmap1.get("yer"), "Duraktan Ge\347en Hatlar", "", "Favorilerime Ekle");
        } else
        {
            lo.add(new MapDraw("Circle", geopoint3, 10, Color.argb(90, 0, 0, 255), Color.argb(90, 0, 0, 255), 5));
        }
        l++;
          goto _L7
    }

    public void Location()
    {
        gps = new Gps(this);
        gps.addObserver(new Gps.Callback() {

            final HatMap this$0;

            public void onComplete(Location location1)
            {
                Exception exception1;
                GeoPoint geopoint;
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location1 != null)
                {
                    break MISSING_BLOCK_LABEL_169;
                }
                Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                geopoint = Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString());
                locationAdres = "K\u0131z\u0131lay Meydan\u0131";
                locationIlce = "\307ankaya";
_L1:
                location = true;
                locationPosition = geopoint;
                Isaretle("Location", geopoint, 17, "");
                Toast.makeText(getBaseContext(), (new StringBuilder("Konumum\n\n")).append(locationAdres).append("\n").append(locationIlce).toString(), 1).show();
                return;
                try
                {
                    geopoint = Map.GP((new StringBuilder()).append(location1.getLatitude()).toString(), (new StringBuilder()).append(location1.getLongitude()).toString());
                    locationAdres = gps.GpsAdres;
                    locationIlce = gps.GpsIlce;
                }
                // Misplaced declaration of an exception variable
                catch (Exception exception1)
                {
                    return;
                }
                  goto _L1
            }

            
            {
                this$0 = HatMap.this;
                super();
            }
        });
        gps.Start();
    }

    public void MarkerAction(String s, OverlayItem overlayitem, String as[], int i)
    {
        Map.CloseBalloon(mv);
        if (s.equals("Location"))
        {
            Global.App_Adres_Query = "";
            Global.App_Adres_Adres = locationAdres;
            Global.App_Adres_Ilce = locationIlce;
            Global.App_Adres_Lat = (new StringBuilder()).append((double)locationPosition.getLatitudeE6() / 1000000D).toString();
            Global.App_Adres_Lng = (new StringBuilder()).append((double)locationPosition.getLongitudeE6() / 1000000D).toString();
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar), 0);
        }
        if (s.equals("Durak"))
        {
            if (i == 1)
            {
                Global.App_Favorilerim_Durak_No = as[0];
                Global.App_Favorilerim_Durak_Tanim = as[1];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar), 0);
            }
            if (i == 2)
            {
                Global.App_Durak_No = as[0];
                IlkGoster = true;
                mv.getOverlays().clear();
                lo = mv.getOverlays();
                lo.clear();
                locationOverlay = -1;
                otobusOverlay = -1;
                Isaretle("Yol", null, zoom, "");
                Isaretle("Durak", null, zoom, "");
            }
            if (i == 3)
            {
                Global.App_Favorilerim_Durak_Ekle = as[0];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimDurakDuzenle), 0);
            }
        }
        if (s.equals("Otob\374s"))
        {
            OtobusleriTakipEt = true;
            Global.App_Otobus_No = as[0];
            OtobusYenile(0);
        }
    }

    public void OtobusBilgisiText_OnClick(View view)
    {
        OtobusBilgisiText = false;
        ((Button)findViewById(0x7f090040)).setVisibility(0);
        ((Button)findViewById(0x7f090041)).setVisibility(8);
    }

    public void OtobusBilgisi_OnClick(View view)
    {
        if (((Button)findViewById(0x7f090041)).getVisibility() == 0)
        {
            OtobusBilgisiText = false;
            ((Button)findViewById(0x7f090040)).setVisibility(0);
            ((Button)findViewById(0x7f090041)).setVisibility(8);
            return;
        } else
        {
            OtobusBilgisiText = true;
            ((Button)findViewById(0x7f090040)).setVisibility(8);
            ((Button)findViewById(0x7f090041)).setVisibility(0);
            return;
        }
    }

    public void OtobusYenile(int i)
    {
        handlerStop();
        handlerRunnable = new Runnable() {

            final HatMap this$0;

            public void run()
            {
                try
                {
                    handler.removeCallbacks(handlerRunnable);
                }
                catch (Exception exception) { }
                if (handlerStatus)
                {
                    handlerStatus = false;
                    HatMap hatmap = HatMap.this;
                    String as[] = {
                        "FNC", "OtobusAra"
                    };
                    String as1[] = new String[4];
                    as1[0] = "QUERY";
                    as1[1] = Global.App_Hat_No;
                    as1[2] = "DURAK";
                    as1[3] = Global.App_Durak_No;
                    hatmap.http = new Http("OtobusAra", "hat.asp", as, as1);
                    http.addObserver(new Http.Callback() {

                        final _cls7 this$1;

                        public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
                        {
                            Action(s, s1, i, boolean1, s2);
                        }

            
            {
                this$1 = _cls7.this;
                super();
            }
                    });
                    http.execute(new String[0]);
                }
            }


            
            {
                this$0 = HatMap.this;
                super();
            }
        };
        if (i == 0)
        {
            handlerStatus = true;
            handler.postDelayed(handlerRunnable, 0L);
            return;
        } else
        {
            handlerStatus = true;
            handler.postDelayed(handlerRunnable, i);
            return;
        }
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final HatMap this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = HatMap.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void ToolBar_OnClick(View view)
    {
        String s;
        s = view.getTag().toString();
        if (!s.equals("0"))
        {
            handlerStop();
        }
        if (!s.equals("0")) goto _L2; else goto _L1
_L1:
        openOptionsMenu();
_L4:
        return;
_L2:
        if (s.equals("1"))
        {
            finish();
            return;
        }
        if (s.equals("2"))
        {
            Runnable("Location");
            return;
        }
        if (s.equals("3"))
        {
            mv.getController().zoomIn();
            return;
        }
        if (!s.equals("4"))
        {
            continue; /* Loop/switch isn't completed */
        }
        if (mv.getZoomLevel() < 12) goto _L4; else goto _L3
_L3:
        mv.getController().zoomOut();
        return;
        if (!s.equals("5") || BekledigimDurak == null) goto _L4; else goto _L5
_L5:
        if (mv.getZoomLevel() < 15)
        {
            mc.setZoom(17);
        }
        mc.setCenter(BekledigimDurak);
        Toast.makeText(getBaseContext(), "Bekledi\u011Fim Durak", 1).show();
        return;
    }

    public void Yenile_OnClick(View view)
    {
        Map.CloseBalloon(mv);
        try
        {
            OtobusYenile(0);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void handlerStop()
    {
        handlerStatus = false;
        try
        {
            handler.removeCallbacks(handlerRunnable);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    protected boolean isRouteDisplayed()
    {
        return false;
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        handlerStop();
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030012);
        dialog = Tools.Waiting(this);
        seekBar = (SeekBar)findViewById(0x7f090043);
        seekBar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {

            final HatMap this$0;

            public void onProgressChanged(SeekBar seekbar, int i, boolean flag)
            {
                seekBarNumber.setText((new StringBuilder()).append(i + 1).toString());
                try
                {
                    new HashMap();
                    HashMap hashmap = (HashMap)lstmapDurak.get(i);
                    if (mv.getZoomLevel() < 15)
                    {
                        mc.setZoom(17);
                    }
                    mc.setCenter(Map.GP((new StringBuilder()).append((String)hashmap.get("lat")).toString(), (new StringBuilder()).append((String)hashmap.get("lng")).toString()));
                    return;
                }
                catch (Exception exception)
                {
                    return;
                }
            }

            public void onStartTrackingTouch(SeekBar seekbar)
            {
            }

            public void onStopTrackingTouch(SeekBar seekbar)
            {
            }

            
            {
                this$0 = HatMap.this;
                super();
            }
        });
        seekBarNumber = (TextView)findViewById(0x7f090044);
        seekBarNumber.setOnClickListener(new android.view.View.OnClickListener() {

            final HatMap this$0;

            public void onClick(View view)
            {
                try
                {
                    new HashMap();
                    HashMap hashmap = (HashMap)lstmapDurak.get(seekBar.getProgress());
                    if (mv.getZoomLevel() < 15)
                    {
                        mc.setZoom(17);
                    }
                    mc.setCenter(Map.GP((new StringBuilder()).append((String)hashmap.get("lat")).toString(), (new StringBuilder()).append((String)hashmap.get("lng")).toString()));
                    return;
                }
                catch (Exception exception)
                {
                    return;
                }
            }

            
            {
                this$0 = HatMap.this;
                super();
            }
        });
        seekBarNumber.setText((new StringBuilder()).append(1 + seekBar.getProgress()).toString());
        mv = (MapView)findViewById(0x7f090003);
        mc = mv.getController();
        if (Global.Set_HaritaTipi.equals("Harita"))
        {
            mv.setSatellite(false);
        }
        if (Global.Set_HaritaTipi.equals("Uydu"))
        {
            mv.setSatellite(true);
        }
        mv.setBuiltInZoomControls(false);
        mc.setCenter(Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString()));
        mc.setZoom(zoom);
        Map.CloseBalloon(mv);
        mv.getOverlays().clear();
        lo = mv.getOverlays();
        lo.clear();
        locationOverlay = -1;
        otobusOverlay = -1;
        mv.setOnTouchListener(new android.view.View.OnTouchListener() {

            final HatMap this$0;

            public boolean onTouch(View view, MotionEvent motionevent)
            {
                if (motionevent.getAction() == 0)
                {
                    if (motionevent.getEventTime() - lastTouchDoubleTime < 250L)
                    {
                        mc.setZoom(1 + mv.getZoomLevel());
                        mv.invalidate();
                        lastTouchDoubleTime = -1L;
                        return true;
                    }
                    lastTouchDoubleTime = motionevent.getEventTime();
                }
                return false;
            }

            
            {
                this$0 = HatMap.this;
                super();
            }
        });
        if (Global.Set_HatDurakGorunumu.equals("Kapal\u0131"))
        {
            DuraklariGoster = false;
        }
        HatYenile();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        menu.add(0, 3, 3, "Otob\374s\374 Takip Etme");
        if (Global.Set_HatDurakGorunumu.equals("Kapal\u0131"))
        {
            menu.add(0, 4, 4, "Duraklar\u0131 G\366ster");
        } else
        {
            menu.add(0, 4, 4, "Duraklar\u0131 Gizle");
        }
        menu.add(0, 5, 5, "Harita G\366r\374n\374m\374");
        menu.add(0, 6, 6, "Uydu G\366r\374n\374m\374");
        appMenu = menu;
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 6: default 44
    //                   1 50
    //                   2 63
    //                   3 70
    //                   4 136
    //                   5 283
    //                   6 294;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L7
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        continue; /* Loop/switch isn't completed */
_L4:
        if (!OtobusleriTakipEt)
        {
            OtobusleriTakipEt = true;
            appMenu.getItem(2).setTitle("Otob\374s\374 Takpit Etme");
            OtobusYenile(0);
        } else
        {
            OtobusleriTakipEt = false;
            appMenu.getItem(2).setTitle("Otob\374s\374 Takpit Et");
        }
        continue; /* Loop/switch isn't completed */
_L5:
        Map.CloseBalloon(mv);
        mv.getOverlays().clear();
        lo = mv.getOverlays();
        lo.clear();
        locationOverlay = -1;
        otobusOverlay = -1;
        Isaretle("Yol", null, zoom, "");
        if (!DuraklariGoster)
        {
            DuraklariGoster = true;
            appMenu.getItem(3).setTitle("Duraklar\u0131 Gizle");
        } else
        {
            DuraklariGoster = false;
            appMenu.getItem(3).setTitle("Duraklar\u0131 G\366ster");
        }
        Isaretle("Durak", null, zoom, "");
        if (Global.App_OtobusYenilemeSuresi > 0)
        {
            OtobusYenile(0);
        }
        continue; /* Loop/switch isn't completed */
_L6:
        mv.setSatellite(false);
        continue; /* Loop/switch isn't completed */
_L7:
        mv.setSatellite(true);
        if (true) goto _L1; else goto _L8
_L8:
    }

    public void onResume()
    {
        super.onResume();
        pageStatus = true;
    }

    protected void onStop()
    {
        pageStatus = false;
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        handlerStop();
        super.onStop();
    }
}
