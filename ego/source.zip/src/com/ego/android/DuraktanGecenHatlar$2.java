// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            DuraktanGecenHatlar, Global, HatBilgileri

class this._cls0
    implements android.widget.kListener
{

    final DuraktanGecenHatlar this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        Global.App_Hat_No = (String)((HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(i)).get("no");
        Global.App_Durak_No = Durak_No;
        Global.App_Otobus_No = "";
        if (Global.App_Adres_Sec.equals("HatAra"))
        {
            Intent intent = new Intent();
            setResult(10, intent);
            finish();
            return;
        } else
        {
            Intent intent1 = new Intent(getBaseContext(), com/ego/android/HatBilgileri);
            startActivityForResult(intent1, 0);
            return;
        }
    }

    Listener()
    {
        this$0 = DuraktanGecenHatlar.this;
        super();
    }
}
