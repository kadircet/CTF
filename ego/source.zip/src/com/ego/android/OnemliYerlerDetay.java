// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, ListAdapterBtn, Global, KonumMap, 
//            Tools, YakindakiDurakVeHatlar

public class OnemliYerlerDetay extends Activity
{

    ProgressDialog dialog;
    Http http;

    public OnemliYerlerDetay()
    {
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        ListView listview;
        ArrayList arraylist;
        int j;
        HashMap hashmap1;
        Exception exception1;
        int k;
        HashMap hashmap2;
        Exception exception2;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Ara")) goto _L4; else goto _L3
_L3:
        listview = (ListView)findViewById(0x7f090062);
        arraylist = new ArrayList();
        HashMap hashmap = new HashMap();
        j = 0;
        hashmap1 = hashmap;
_L7:
        k = http.jArray.length();
        if (j < k) goto _L6; else goto _L5
_L5:
        hashmap1;
_L8:
        ((TextView)findViewById(0x7f090063)).setText((new StringBuilder()).append(arraylist.size()).toString());
        listview.setAdapter(new ListAdapterBtn(this, arraylist, 0x7f030021, new String[] {
            "ad", "yer", "btn"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090047
        }));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final OnemliYerlerDetay this$0;

            public void onItemClick(AdapterView adapterview, View view, int l, long l1)
            {
                HashMap hashmap3 = (HashMap)((ListView)findViewById(0x7f090062)).getItemAtPosition(l);
                Global.App_Adres_Query = "";
                Global.App_Adres_Adres = (String)hashmap3.get("yer");
                Global.App_Adres_Ilce = (String)hashmap3.get("ilce");
                Global.App_Adres_Lat = (String)hashmap3.get("lat");
                Global.App_Adres_Lng = (String)hashmap3.get("lng");
                Intent intent = new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = OnemliYerlerDetay.this;
                super();
            }
        });
        listview.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final OnemliYerlerDetay this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int l, long l1)
            {
                HashMap hashmap3 = (HashMap)((ListView)findViewById(0x7f090062)).getItemAtPosition(l);
                Global.App_Konum = "\326nemli Yer";
                Global.App_Konum_Adres = (new StringBuilder(String.valueOf((String)hashmap3.get("ad")))).append("\n\n").append((String)hashmap3.get("yer")).toString();
                Global.App_Konum_Ilce = (String)hashmap3.get("ilce");
                Global.App_Konum_Lat = (String)hashmap3.get("lat");
                Global.App_Konum_Lng = (String)hashmap3.get("lng");
                Intent intent = new Intent(getBaseContext(), com/ego/android/KonumMap);
                startActivityForResult(intent, 0);
                return true;
            }

            
            {
                this$0 = OnemliYerlerDetay.this;
                super();
            }
        });
_L4:
        return;
_L6:
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(j).toString());
        hashmap2.put("tur", http.JValue(j, "tur"));
        hashmap2.put("ad", http.JValue(j, "ad"));
        hashmap2.put("yer", http.JValue(j, "yer"));
        hashmap2.put("ilce", http.JValue(j, "ilce"));
        hashmap2.put("lat", http.JValue(j, "lat"));
        hashmap2.put("lng", http.JValue(j, "lng"));
        hashmap2.put("btn", (new StringBuilder()).append(j).toString());
        arraylist.add(hashmap2);
        j++;
        hashmap1 = hashmap2;
          goto _L7
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception1;
        hashmap1;
          goto _L8
        exception2;
          goto _L8
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        try
        {
            String as[] = s.split(";");
            HashMap hashmap = (HashMap)((ListView)findViewById(0x7f090062)).getItemAtPosition(Integer.parseInt(as[0]));
            Global.App_Konum = "\326nemli Yer";
            Global.App_Konum_Adres = (new StringBuilder(String.valueOf((String)hashmap.get("ad")))).append("\n\n").append((String)hashmap.get("yer")).toString();
            Global.App_Konum_Ilce = (String)hashmap.get("ilce");
            Global.App_Konum_Lat = (String)hashmap.get("lat");
            Global.App_Konum_Lng = (String)hashmap.get("lng");
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/KonumMap), 0);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (!s.equals("2") && !s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    public void Yenile()
    {
        String as[] = {
            "FNC", "YerAra"
        };
        String as1[] = new String[8];
        as1[0] = "TUR";
        as1[1] = Global.App_OnemliYer_Tur;
        as1[2] = "YEr";
        as1[3] = Global.App_OnemliYer_Yer;
        as1[4] = "LAT";
        as1[5] = Global.App_OnemliYer_Lat;
        as1[6] = "LNG";
        as1[7] = Global.App_OnemliYer_Lng;
        http = new Http("Ara", "onemliyerler.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final OnemliYerlerDetay this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = OnemliYerlerDetay.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03002d);
        dialog = Tools.Waiting(this);
        ((TextView)findViewById(0x7f09005e)).setText(Global.App_OnemliYer_Tur.replace("* ", ""));
        Yenile();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
