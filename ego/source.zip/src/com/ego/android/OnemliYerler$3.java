// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.location.Location;
import android.text.Editable;
import android.widget.EditText;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            OnemliYerler, Gps, Map, Http

class this._cls0
    implements this._cls0
{

    final OnemliYerler this$0;

    public void onComplete(Location location)
    {
        OnemliYerler onemliyerler;
        String as[];
        String as1[];
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (location == null)
        {
            try
            {
                Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                return;
            }
            catch (Exception exception1)
            {
                return;
            }
        }
        if (gps.GpsAdres.equals(""))
        {
            Toast.makeText(getBaseContext(), "Adres Bulunamad\u0131!", 1).show();
            return;
        }
        OnemliYerler.this.location = true;
        locationPosition = Map.GP((new StringBuilder()).append(location.getLatitude()).toString(), (new StringBuilder()).append(location.getLongitude()).toString());
        locationAdres = gps.GpsAdres;
        locationIlce = gps.GpsIlce;
        Yer = ((EditText)findViewById(0x7f090000)).getText().toString();
        Lat = (new StringBuilder()).append(location.getLatitude()).toString();
        Lng = (new StringBuilder()).append(location.getLongitude()).toString();
        Toast.makeText(getBaseContext(), (new StringBuilder("Konumum\n\n")).append(locationAdres).append("\n").append(locationIlce).append("\n\nYak\u0131nl\u0131k 1000 Metre").toString(), 1).show();
        onemliyerler = OnemliYerler.this;
        as = (new String[] {
            "FNC", "TurAra"
        });
        as1 = new String[6];
        as1[0] = "YER";
        as1[1] = Yer;
        as1[2] = "LAT";
        as1[3] = Lat;
        as1[4] = "LNG";
        as1[5] = Lng;
        onemliyerler.http = new Http("Ara", "onemliyerler.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final OnemliYerler._cls3 this$1;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$1 = OnemliYerler._cls3.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
        return;
    }


    _cls1.this._cls1()
    {
        this$0 = OnemliYerler.this;
        super();
    }
}
