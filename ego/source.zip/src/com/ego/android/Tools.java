// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Build;
import android.view.Window;
import com.google.android.maps.GeoPoint;
import java.net.URI;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

// Referenced classes of package com.ego.android:
//            Global

public final class Tools
{

    public Tools()
    {
    }

    public static String[] GeoCoder(GeoPoint geopoint)
    {
        String s;
        String s1;
        String as[];
        JSONObject jsonobject;
        s = (new StringBuilder()).append((double)geopoint.getLatitudeE6() / 1000000D).toString();
        s1 = (new StringBuilder()).append((double)geopoint.getLongitudeE6() / 1000000D).toString();
        as = (new String[] {
            "", "", "", ""
        });
        new JSONObject();
        jsonobject = HttpConnect_JSONObject((new StringBuilder("http://maps.googleapis.com/maps/api/geocode/json?latlng=")).append(s).append(",").append(s1).append("&sensor=false&language=tr").toString());
        if (jsonobject == null) goto _L2; else goto _L1
_L1:
        JSONArray jsonarray = jsonobject.getJSONArray("results");
        if (jsonarray.length() <= 0) goto _L2; else goto _L3
_L3:
        JSONObject jsonobject1;
        JSONArray jsonarray1;
        jsonobject1 = jsonarray.getJSONObject(0);
        jsonarray1 = jsonobject1.getJSONArray("address_components");
        String s2;
        int i;
        s2 = "";
        i = 0;
_L6:
        if (i < jsonarray1.length()) goto _L5; else goto _L4
_L4:
        String s3;
        int j;
        if (s2.equals(""))
        {
            break; /* Loop/switch isn't completed */
        }
        s3 = jsonobject1.getString("formatted_address").replace(" Ankara, T\374rkiye", "").replace("/Ankara, T\374rkiye", "");
        j = s3.indexOf(", 06");
        if (j == -1)
        {
            break MISSING_BLOCK_LABEL_242;
        }
        if (j + 7 == s3.length())
        {
            s3 = s3.split(", 06")[0];
        }
        as[0] = s3;
        as[1] = s2;
        as[2] = s;
        as[3] = s1;
        return as;
_L5:
        JSONObject jsonobject2;
        Exception exception1;
        String s4;
        String s5;
        try
        {
            jsonobject2 = jsonarray1.getJSONObject(i);
        }
        catch (Exception exception)
        {
            break; /* Loop/switch isn't completed */
        }
        s4 = jsonobject2.getString("types");
        if (s4.indexOf("sublocality") != -1)
        {
            s2 = jsonobject2.getString("long_name");
        }
        if (s4.indexOf("administrative_area_level_1") != -1)
        {
            s2 = jsonobject2.getString("long_name");
        }
        if (s4.indexOf("administrative_area_level_2") == -1)
        {
            break MISSING_BLOCK_LABEL_349;
        }
        s5 = jsonobject2.getString("long_name");
        s2 = s5;
          goto _L4
        exception1;
        i++;
        continue; /* Loop/switch isn't completed */
        if (true) goto _L6; else goto _L2
_L2:
        return as;
    }

    public static JSONArray HttpConnect_JSONArray(String s)
    {
        BasicHttpParams basichttpparams = new BasicHttpParams();
        HttpProtocolParams.setVersion(basichttpparams, HttpVersion.HTTP_1_1);
        HttpProtocolParams.setUseExpectContinue(basichttpparams, true);
        HttpConnectionParams.setStaleCheckingEnabled(basichttpparams, false);
        HttpConnectionParams.setTcpNoDelay(basichttpparams, true);
        HttpConnectionParams.setConnectionTimeout(basichttpparams, 45000);
        HttpConnectionParams.setSoTimeout(basichttpparams, 45000);
        DefaultHttpClient defaulthttpclient = new DefaultHttpClient(basichttpparams);
        int i;
        org.apache.http.HttpEntity httpentity;
        JSONArray jsonarray;
        try
        {
            HttpPost httppost = new HttpPost(new URI(s.replace(" ", "%20")));
            httppost.setHeader("User-Agent", (new StringBuilder("otobushatlari ")).append(Global.App_CurrentVersion).append(" ").append(Build.MODEL).append(" ").append(android.os.Build.VERSION.RELEASE).toString());
            HttpResponse httpresponse = defaulthttpclient.execute(httppost);
            i = httpresponse.getStatusLine().getStatusCode();
            httpentity = httpresponse.getEntity();
        }
        catch (Exception exception)
        {
            return null;
        }
        if (httpentity == null || i != 200)
        {
            break MISSING_BLOCK_LABEL_189;
        }
        jsonarray = new JSONArray(new JSONTokener(EntityUtils.toString(httpentity)));
        return jsonarray;
        return null;
    }

    public static JSONObject HttpConnect_JSONObject(String s)
    {
        BasicHttpParams basichttpparams = new BasicHttpParams();
        HttpProtocolParams.setVersion(basichttpparams, HttpVersion.HTTP_1_1);
        HttpProtocolParams.setUseExpectContinue(basichttpparams, true);
        HttpConnectionParams.setStaleCheckingEnabled(basichttpparams, false);
        HttpConnectionParams.setTcpNoDelay(basichttpparams, true);
        HttpConnectionParams.setConnectionTimeout(basichttpparams, 60000);
        HttpConnectionParams.setSoTimeout(basichttpparams, 60000);
        DefaultHttpClient defaulthttpclient = new DefaultHttpClient(basichttpparams);
        int i;
        org.apache.http.HttpEntity httpentity;
        JSONObject jsonobject;
        try
        {
            HttpPost httppost = new HttpPost(new URI(s.replace(" ", "%20")));
            httppost.setHeader("User-Agent", (new StringBuilder("otobushatlari ")).append(Global.App_CurrentVersion).append(" ").append(Build.MODEL).append(" ").append(android.os.Build.VERSION.RELEASE).toString());
            HttpResponse httpresponse = defaulthttpclient.execute(httppost);
            i = httpresponse.getStatusLine().getStatusCode();
            httpentity = httpresponse.getEntity();
        }
        catch (Exception exception)
        {
            return null;
        }
        if (httpentity == null || i != 200)
        {
            break MISSING_BLOCK_LABEL_189;
        }
        jsonobject = new JSONObject(new JSONTokener(EntityUtils.toString(httpentity)));
        return jsonobject;
        return null;
    }

    public static String ToColor(String s)
    {
        String s1 = "";
        if (s.equals("Saydam"))
        {
            s1 = "";
        } else
        {
            if (s.equals("K\u0131rm\u0131z\u0131"))
            {
                return "#AAE51400";
            }
            if (s.equals("Mavi"))
            {
                return "#AA0050EF";
            }
            if (s.equals("Ye\u015Fil"))
            {
                return "#AA60A917";
            }
            if (s.equals("Pembe"))
            {
                return "#AAF472D0";
            }
            if (s.equals("Turuncu"))
            {
                return "#AAFA6800";
            }
            if (s.equals("Sar\u0131"))
            {
                return "#AAFFFF00";
            }
            if (s.equals("Kahverengi"))
            {
                return "#AA825A2C";
            }
            if (s.equals("A\347\u0131k K\u0131rm\u0131z\u0131"))
            {
                return "#AAA20025";
            }
            if (s.equals("A\347\u0131k Mavi"))
            {
                return "#AA1BA1E2";
            }
            if (s.equals("A\347\u0131k Ye\u015Fil"))
            {
                return "#AAA4C400";
            }
            if (s.equals("A\347\u0131k Pembe"))
            {
                return "#AAF1A0DB";
            }
            if (s.equals("A\347\u0131k Kahverengi"))
            {
                return "#AAC19058";
            }
            if (s.equals("Pasif"))
            {
                return "#AA333333";
            }
        }
        return s1;
    }

    public static ProgressDialog Waiting(Context context)
    {
        ProgressDialog progressdialog = new ProgressDialog(context);
        progressdialog.setIndeterminate(true);
        progressdialog.setCancelable(false);
        progressdialog.getWindow().clearFlags(2);
        progressdialog.show();
        progressdialog.setContentView(0x7f030032);
        try
        {
            progressdialog.dismiss();
        }
        catch (Exception exception)
        {
            return progressdialog;
        }
        return progressdialog;
    }
}
