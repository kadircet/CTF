// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, Global, ListAdapterBtn, Tools, 
//            FavorilerimHatDuzenle

public class FavorilerimHat extends Activity
{

    ProgressDialog dialog;
    Http http;

    public FavorilerimHat()
    {
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        ListView listview;
        ArrayList arraylist;
        HashMap hashmap;
        Exception exception1;
        int j;
        HashMap hashmap1;
        Exception exception2;
        int k;
        String s3;
        String s4;
        HashMap hashmap2;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Hat")) goto _L4; else goto _L3
_L3:
        listview = (ListView)findViewById(0x7f09002a);
        arraylist = new ArrayList();
        hashmap = new HashMap();
        Global.hatArray = http.jArray;
        j = 0;
        hashmap1 = hashmap;
_L7:
        k = http.jArray.length();
        if (j < k) goto _L6; else goto _L5
_L5:
        hashmap1;
_L9:
        listview.setAdapter(new ListAdapterBtn(this, arraylist, 0x7f03001b, new String[] {
            "no", "tanim", "aciklama", "btn"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048, 0x7f090047
        }, Boolean.valueOf(true)));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final FavorilerimHat this$0;

            public void onItemClick(AdapterView adapterview, View view, int l, long l1)
            {
                HashMap hashmap3 = (HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(l);
                if (Global.App_Hat_Sec.equals("Favorilerim"))
                {
                    Global.App_Favorilerim_Hat_No = (String)hashmap3.get("no");
                    Global.App_Favorilerim_Hat_Tanim = (String)hashmap3.get("tanim");
                    Intent intent = new Intent();
                    setResult(10, intent);
                    finish();
                }
            }

            
            {
                this$0 = FavorilerimHat.this;
                super();
            }
        });
        listview.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final FavorilerimHat this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int l, long l1)
            {
                Global.App_Favorilerim_Hat_No = (String)((HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(l)).get("no");
                Intent intent = new Intent(getBaseContext(), com/ego/android/FavorilerimHatDuzenle);
                startActivityForResult(intent, 0);
                return true;
            }

            
            {
                this$0 = FavorilerimHat.this;
                super();
            }
        });
_L4:
        return;
_L6:
        String as[] = http.JValue(j, "aciklama").replace("|", ";").split(";");
        s3 = as[0];
        if (as.length <= 1)
        {
            break MISSING_BLOCK_LABEL_375;
        }
        s4 = as[1];
_L8:
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(j).toString());
        hashmap2.put("no", http.JValue(j, "no"));
        hashmap2.put("tanim", http.JValue(j, "tanim"));
        hashmap2.put("aciklama", s3);
        hashmap2.put("bgcolor", Tools.ToColor(s4));
        hashmap2.put("btn", (new StringBuilder("Hat;")).append(http.JValue(j, "no")).toString());
        arraylist.add(hashmap2);
        j++;
        hashmap1 = hashmap2;
          goto _L7
        s4 = "";
          goto _L8
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
          goto _L7
        exception1;
          goto _L9
        exception2;
        hashmap1;
          goto _L9
    }

    public void Ekle()
    {
        Global.App_Favorilerim_Hat_No = "";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimHatDuzenle), 0);
    }

    public void HatYenile()
    {
        String as[] = {
            "FNC", "FavoriAra"
        };
        String as1[] = new String[4];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        as1[2] = "TIP";
        as1[3] = "Hat";
        http = new Http("Hat", "favori.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final FavorilerimHat this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = FavorilerimHat.this;
                super();
            }
        });
        dialog.show();
        if (Global.hatArray == null)
        {
            http.execute(new String[0]);
            return;
        } else
        {
            http.jArray = Global.hatArray;
            Action("Hat", null, 200, null, null);
            return;
        }
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        try
        {
            String as[] = s.split(";");
            if (as[0].equals("Hat"))
            {
                Global.App_Favorilerim_Hat_No = as[1];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimHatDuzenle), 0);
            }
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Ekle();
                return;
            }
            if (!s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (!Global.App_Favorilerim_Hat_Yenile.equals(""))
        {
            HatYenile();
        }
        Global.App_Favorilerim_Hat_Yenile = "";
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03000d);
        dialog = Tools.Waiting(this);
        Global.App_Favorilerim_Hat_No = "";
        Global.App_Favorilerim_Hat_Yenile = "";
        HatYenile();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
