// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.DialogInterface;
import android.content.Intent;
import com.google.android.maps.GeoPoint;

// Referenced classes of package com.ego.android:
//            AdresMap, Global

class this._cls0
    implements android.content.face.OnClickListener
{

    final AdresMap this$0;

    public void onClick(DialogInterface dialoginterface, int i)
    {
        Global.App_Adres_Map_Sec = "AdresSec";
        Global.App_Adres_Adres = konumAdres;
        Global.App_Adres_Ilce = konumAdres;
        Global.App_Adres_Lat = (new StringBuilder()).append((double)konumPosition.getLatitudeE6() / 1000000D).toString();
        Global.App_Adres_Lng = (new StringBuilder()).append((double)konumPosition.getLongitudeE6() / 1000000D).toString();
        Intent intent = new Intent();
        setResult(10, intent);
        finish();
    }

    face()
    {
        this$0 = AdresMap.this;
        super();
    }
}
