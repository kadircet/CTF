// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.os.Handler;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Panelim, Http

class this._cls1
    implements k
{

    final on this$1;

    public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
    {
        Action(s, s1, i, boolean1, s2);
    }

    is._cls0()
    {
        this$1 = this._cls1.this;
        super();
    }

    // Unreferenced inner class com/ego/android/Panelim$2

/* anonymous class */
    class Panelim._cls2
        implements Runnable
    {

        final Panelim this$0;

        public void run()
        {
            int i;
            int j;
            int k;
            String as[];
            Panelim panelim;
            String as1[];
            String as2[];
            try
            {
                handler.removeCallbacks(handlerRunnable);
            }
            catch (Exception exception) { }
            if (!handlerStatus)
            {
                break MISSING_BLOCK_LABEL_267;
            }
            handlerStatus = false;
            try
            {
                i = lstmapPanelPosition;
            }
            catch (Exception exception1)
            {
                return;
            }
            if (i % 2 == 0)
            {
                j = 1;
            } else
            {
                j = 2;
            }
            k = i / 2;
            if (k < 0)
            {
                k = 0;
            }
            as = ((String)((HashMap)lstmapPanel.get(k)).get((new StringBuilder("no")).append(j).toString())).replace("|", ";").split(";");
            if (as.length >= 2)
            {
                panelim = Panelim.this;
                as1 = (new String[] {
                    "FNC", "OtobusAra"
                });
                as2 = new String[4];
                as2[0] = "QUERY";
                as2[1] = as[0];
                as2[2] = "DURAK";
                as2[3] = as[1];
                panelim.http = new Http("OtobusAra", "hat.asp", as1, as2);
                http.addObserver(new Panelim._cls2._cls1());
                dialog.show();
                http.execute(new String[0]);
                return;
            }
            Toast.makeText(getBaseContext(), "Panelleriniz Olu\u015Fturulmam\u0131\u015F!", 1).show();
            return;
        }


            
            {
                this$0 = Panelim.this;
                super();
            }
    }

}
