// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, ListAdapter, Tools, Global, 
//            DuyurularDetay

public class Duyurular extends Activity
{

    String Konu;
    ProgressDialog dialog;
    Http http;

    public Duyurular()
    {
        Konu = "";
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        ListView listview;
        ArrayList arraylist;
        int j;
        HashMap hashmap1;
        Exception exception1;
        int k;
        HashMap hashmap2;
        Exception exception2;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Ara")) goto _L4; else goto _L3
_L3:
        listview = (ListView)findViewById(0x7f09002b);
        arraylist = new ArrayList();
        HashMap hashmap = new HashMap();
        j = 0;
        hashmap1 = hashmap;
_L7:
        k = http.jArray.length();
        if (j < k) goto _L6; else goto _L5
_L5:
        hashmap1;
_L8:
        listview.setAdapter(new ListAdapter(this, arraylist, 0x7f030019, new String[] {
            "baslik", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046
        }));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final Duyurular this$0;

            public void onItemClick(AdapterView adapterview, View view, int l, long l1)
            {
                Global.App_Duyuru_Id = (String)((HashMap)((ListView)findViewById(0x7f09002b)).getItemAtPosition(l)).get("id");
                Intent intent = new Intent(getBaseContext(), com/ego/android/DuyurularDetay);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = Duyurular.this;
                super();
            }
        });
_L4:
        return;
_L6:
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(http.JValue(j, "id")).toString());
        hashmap2.put("baslik", http.JValue(j, "baslik"));
        hashmap2.put("aciklama", http.JValue(j, "aciklama"));
        arraylist.add(hashmap2);
        j++;
        hashmap1 = hashmap2;
          goto _L7
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception1;
        hashmap1;
          goto _L8
        exception2;
          goto _L8
    }

    public void CloseKeyboard()
    {
        ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(0x7f090000).getWindowToken(), 0);
    }

    public void KlavyeX_OnClick(View view)
    {
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090000).getWindowToken(), 0);
        ((EditText)findViewById(0x7f090000)).setText("");
        ((EditText)findViewById(0x7f090000)).requestFocus();
        inputmethodmanager.toggleSoftInput(2, 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void Sorgula_OnClick(View view)
    {
        CloseKeyboard();
        Konu = ((EditText)findViewById(0x7f090000)).getText().toString();
        String as[] = {
            "FNC", "DuyuruAra"
        };
        String as1[] = new String[2];
        as1[0] = "KONU";
        as1[1] = Konu;
        http = new Http("Ara", "duyurular.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final Duyurular this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = Duyurular.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void ToolBar_OnClick(View view)
    {
        CloseKeyboard();
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (!s.equals("2") && !s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030007);
        CloseKeyboard();
        dialog = Tools.Waiting(this);
        Sorgula_OnClick(null);
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        CloseKeyboard();
        super.onStop();
    }
}
