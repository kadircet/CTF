// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            OnemliYerler, Global, OnemliYerlerDetay

class this._cls0
    implements android.widget.temClickListener
{

    final OnemliYerler this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        Global.App_OnemliYer_Tur = (String)((HashMap)((ListView)findViewById(0x7f090062)).getItemAtPosition(i)).get("tur");
        Global.App_OnemliYer_Yer = Yer;
        Global.App_OnemliYer_Lat = Lat;
        Global.App_OnemliYer_Lng = Lng;
        Intent intent = new Intent(getBaseContext(), com/ego/android/OnemliYerlerDetay);
        startActivityForResult(intent, 0);
    }

    ay()
    {
        this$0 = OnemliYerler.this;
        super();
    }
}
