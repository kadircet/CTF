// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Global, Http, ListAdapter, AdresAra, 
//            HatDuraklar, DuraktanGecenHatlar, FavorilerimHat, FavorilerimDurak, 
//            OtobusNeredeMap, Panelim, Tools, HatBilgileri

public class Alarm extends Activity
{

    ProgressDialog dialog;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    boolean pageStatus;
    SeekBar seekBarYaklasma;
    SeekBar seekBarYenileme;

    public Alarm()
    {
        pageStatus = false;
        handler = new Handler();
        handlerStatus = false;
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        Exception exception1;
        boolean flag;
        ListView listview;
        ArrayList arraylist;
        HashMap hashmap;
        String s3;
        int j;
        int k;
        HashMap hashmap1;
        Exception exception2;
        ListAdapter listadapter;
        int l;
        HashMap hashmap2;
        int i1;
        double d;
        double d1;
        double d2;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (Global.App_Alarm_Acik) goto _L2; else goto _L1
_L1:
        handlerStop();
_L18:
        return;
_L2:
        if (i != 200) goto _L4; else goto _L3
_L3:
        if (!s.equals("HatAra")) goto _L6; else goto _L5
_L5:
        if (http.JValue(0, "no").equals("")) goto _L8; else goto _L7
_L7:
        ((EditText)findViewById(0x7f090007)).setText(http.JValue(0, "no"));
        ((TextView)findViewById(0x7f090008)).setText(http.JValue(0, "tanim"));
_L6:
        if (!s.equals("DurakAra")) goto _L10; else goto _L9
_L9:
        if (http.JValue(0, "no").equals("")) goto _L12; else goto _L11
_L11:
        ((EditText)findViewById(0x7f090009)).setText(http.JValue(0, "no"));
        ((TextView)findViewById(0x7f09000a)).setText(http.JValue(0, "tanim"));
_L10:
        flag = s.equals("AlarmAra");
        if (flag)
        {
            try
            {
                String as[] = http.JValue(0, "aciklama").replace("|", ";").split(";");
                ((EditText)findViewById(0x7f090007)).setText(http.JValue(0, "hat"));
                ((TextView)findViewById(0x7f090008)).setText(http.JValue(0, "hattanim"));
                ((TextView)findViewById(0x7f090009)).setText(http.JValue(0, "durak"));
                ((TextView)findViewById(0x7f09000a)).setText(http.JValue(0, "duraktanim"));
                seekBarYenileme.setProgress(-1 + Integer.parseInt(as[0]));
                seekBarYaklasma.setProgress(-1 + Integer.parseInt(as[1]));
                SeekBarYenileme();
            }
            catch (Exception exception6) { }
        }
        if (!s.equals("AlarmEkle")) goto _L14; else goto _L13
_L13:
        if (!http.JValue(0, "status").equals("true")) goto _L16; else goto _L15
_L15:
        Toast.makeText(getBaseContext(), "Alarm Kaydedildi.", 0).show();
_L14:
        if (!s.equals("OtobusAra") && !s.equals("OtobusDurakAra")) goto _L18; else goto _L17
_L17:
        listview = (ListView)findViewById(0x7f090010);
        arraylist = new ArrayList();
        hashmap = new HashMap();
        s3 = ((EditText)findViewById(0x7f090009)).getText().toString();
        j = 0;
        k = 0;
        hashmap1 = hashmap;
_L32:
        l = http.jArray.length();
        if (k < l) goto _L20; else goto _L19
_L19:
        hashmap1;
_L30:
        if (!s.equals("OtobusAra")) goto _L22; else goto _L21
_L21:
        listadapter = new ListAdapter(this, arraylist, 0x7f03001d, new String[] {
            "kod", "plaka", "hiz", "sure", "aciklama", "arac"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048, 0x7f090049, 0x7f09004a, 0x7f09004b
        }, Boolean.valueOf(true));
_L31:
        listview.setAdapter(listadapter);
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final Alarm this$0;

            public void onItemClick(AdapterView adapterview, View view, int j1, long l1)
            {
                HashMap hashmap3 = (HashMap)((ListView)findViewById(0x7f090010)).getItemAtPosition(j1);
                Global.App_Hat_No = (String)hashmap3.get("no");
                Global.App_Durak_No = ((EditText)findViewById(0x7f090009)).getText().toString();
                Global.App_Otobus_No = (String)hashmap3.get("kod");
                Intent intent = new Intent(getBaseContext(), com/ego/android/HatBilgileri);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = Alarm.this;
                super();
            }
        });
        listview.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final Alarm this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int j1, long l1)
            {
                HashMap hashmap3 = (HashMap)((ListView)findViewById(0x7f090010)).getItemAtPosition(j1);
                Global.App_Hat_No = (String)hashmap3.get("no");
                Global.App_Durak_No = ((EditText)findViewById(0x7f090009)).getText().toString();
                Global.App_Otobus_No = (String)hashmap3.get("kod");
                Intent intent = new Intent(getBaseContext(), com/ego/android/OtobusNeredeMap);
                startActivityForResult(intent, 0);
                return true;
            }

            
            {
                this$0 = Alarm.this;
                super();
            }
        });
        if (j != 0)
        {
            break MISSING_BLOCK_LABEL_613;
        }
        Toast.makeText(getBaseContext(), "\u015Eu Anda Otob\374s Yok!", 1).show();
        OtobusYenile(1000 * (15 * (1 + seekBarYenileme.getProgress())));
        return;
_L8:
        try
        {
            Toast.makeText(getBaseContext(), "Hat Bulunamad\u0131!", 1).show();
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception1)
        {
            handlerStop();
            return;
        }
          goto _L6
_L12:
        Toast.makeText(getBaseContext(), "Durak Bulunamad\u0131!", 1).show();
          goto _L10
_L16:
label0:
        {
            if (http.JValue(0, "error").equals(""))
            {
                break label0;
            }
            Toast.makeText(getBaseContext(), http.JValue(0, "error"), 1).show();
        }
          goto _L14
        Toast.makeText(getBaseContext(), "Alarm Kaydedilemedi!", 1).show();
          goto _L14
_L20:
        if (http.JValue(k, "sure").indexOf("Ge\347ti") != -1) goto _L24; else goto _L23
_L23:
        j++;
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(k).toString());
        hashmap2.put("no", http.JValue(k, "hatkod"));
        hashmap2.put("tanim", http.JValue(k, "hatad"));
        hashmap2.put("aciklama", http.JValue(k, "aciklama"));
        hashmap2.put("arac", http.JValue(k, "arac"));
        hashmap2.put("kod", http.JValue(k, "kod"));
        hashmap2.put("plaka", http.JValue(k, "plaka"));
        hashmap2.put("hiz", http.JValue(k, "hiz"));
        hashmap2.put("sure", http.JValue(k, "sure"));
        hashmap2.put("btn", (new StringBuilder(String.valueOf(http.JValue(k, "hatkod")))).append(";").append(s3).append(";").append(http.JValue(k, "kod")).toString());
        i1 = seekBarYaklasma.getProgress();
        d = 60 * (i1 + 5);
        d2 = Double.parseDouble(http.JValue(k, "saniye"));
        d1 = d2 * 60D;
_L33:
        if (d1 <= 0.0D || d < d1) goto _L26; else goto _L25
_L25:
        Toast.makeText(getBaseContext(), "Otob\374s Yakla\u015Ft\u0131", 1).show();
        if (d1 <= 0.0D) goto _L28; else goto _L27
_L27:
        hashmap2.put("bgcolor", "#66FF0000");
        try
        {
            MediaPlayer mediaplayer = MediaPlayer.create(this, 0x7f040000);
            mediaplayer.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {

                final Alarm this$0;

                public void onCompletion(MediaPlayer mediaplayer1)
                {
                    try
                    {
                        Thread.sleep(1000L);
                    }
                    catch (Exception exception7) { }
                    mediaplayer1.release();
                }

            
            {
                this$0 = Alarm.this;
                super();
            }
            });
            mediaplayer.start();
        }
        catch (Exception exception5) { }
        arraylist.add(hashmap2);
          goto _L29
_L28:
        Exception exception4;
        try
        {
            hashmap2.put("bgcolor", "#66FF0000");
            break MISSING_BLOCK_LABEL_1123;
        }
        catch (Exception exception3) { }
          goto _L30
_L26:
        hashmap2.put("bgcolor", "");
        break MISSING_BLOCK_LABEL_1123;
_L22:
        listadapter = new ListAdapter(this, arraylist, 0x7f030022, new String[] {
            "no", "tanim", "kod", "plaka", "hiz", "sure", "aciklama", "arac"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090049, 0x7f09004a, 0x7f09004b, 0x7f09004f, 0x7f090048, 0x7f090050
        }, Boolean.valueOf(true));
          goto _L31
_L4:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception2;
        hashmap1;
          goto _L30
_L24:
        hashmap2 = hashmap1;
_L29:
        k++;
        hashmap1 = hashmap2;
          goto _L32
        exception4;
        d1 = 0.0D;
          goto _L33
    }

    public void AlarmKaydet()
    {
        String s = ((EditText)findViewById(0x7f090007)).getText().toString();
        String s1 = ((TextView)findViewById(0x7f090008)).getText().toString();
        String s2 = ((EditText)findViewById(0x7f090009)).getText().toString();
        String s3 = ((TextView)findViewById(0x7f09000a)).getText().toString();
        String s4 = (new StringBuilder()).append(1 + seekBarYenileme.getProgress()).toString();
        String s5 = (new StringBuilder()).append(1 + seekBarYaklasma.getProgress()).toString();
        if (s1.length() == 0)
        {
            Toast.makeText(getBaseContext(), "Hat Sorgulanmad\u0131!", 1).show();
            return;
        }
        if (s2.length() != 5)
        {
            Toast.makeText(getBaseContext(), "Durak Numaras\u0131\n5 Basamakl\u0131 Say\u0131 Olmal\u0131!", 1).show();
            return;
        }
        if (s3.length() == 0)
        {
            Toast.makeText(getBaseContext(), "Durak Sorgulanmad\u0131!", 1).show();
            return;
        } else
        {
            String as[] = {
                "FNC", "FavoriEkle"
            };
            String as1[] = new String[14];
            as1[0] = "UID";
            as1[1] = Global.Device_ID;
            as1[2] = "TIP";
            as1[3] = "Alarm";
            as1[4] = "NO";
            as1[5] = "0";
            as1[6] = "HATNO";
            as1[7] = s;
            as1[8] = "DURAKNO";
            as1[9] = s2;
            as1[10] = "TANIM";
            as1[11] = "Alarm Kayd\u0131";
            as1[12] = "ACIKLAMA";
            as1[13] = (new StringBuilder(String.valueOf(s4))).append("|").append(s5).toString();
            http = new Http("AlarmEkle", "favori.asp", as, as1);
            http.addObserver(new Http.Callback() {

                final Alarm this$0;

                public void onComplete(String s6, String s7, int i, Boolean boolean1, String s8)
                {
                    Action(s6, s7, i, boolean1, s8);
                }

            
            {
                this$0 = Alarm.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        }
    }

    public void AlarmSorgula()
    {
        String as[] = {
            "FNC", "FavoriAra"
        };
        String as1[] = new String[8];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        as1[2] = "TIP";
        as1[3] = "Alarm";
        as1[4] = "ID";
        as1[5] = "0";
        as1[6] = "NO";
        as1[7] = "0";
        http = new Http("AlarmAra", "favori.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final Alarm this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = Alarm.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void CloseKeyboard()
    {
        ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(0x7f090007).getWindowToken(), 0);
    }

    public void DaraltGenisle_OnClick(View view)
    {
        LinearLayout linearlayout = (LinearLayout)findViewById(0x7f090006);
        if (linearlayout.getVisibility() == 8)
        {
            linearlayout.setVisibility(0);
            ((Button)findViewById(0x7f090005)).setText("Daralt");
            return;
        } else
        {
            linearlayout.setVisibility(8);
            ((Button)findViewById(0x7f090005)).setText("Geni\u015Flet");
            return;
        }
    }

    public void DurakAra()
    {
        Global.App_Adres_Sec = "DurakAra";
        Global.App_Durak_No = "";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/AdresAra), 0);
    }

    public void FavoriDurakSorgula()
    {
        String s = ((EditText)findViewById(0x7f090009)).getText().toString();
        if (s.length() == 5)
        {
            ((TextView)findViewById(0x7f09000a)).setText("");
            http = new Http("DurakAra", "favori.asp", new String[] {
                "FNC", "DurakAra"
            }, new String[] {
                "NO", s
            });
            http.addObserver(new Http.Callback() {

                final Alarm this$0;

                public void onComplete(String s3, String s4, int i, Boolean boolean1, String s5)
                {
                    Action(s3, s4, i, boolean1, s5);
                }

            
            {
                this$0 = Alarm.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        }
        String s1 = ((EditText)findViewById(0x7f090007)).getText().toString();
        String s2 = ((TextView)findViewById(0x7f090008)).getText().toString();
        if (s1.length() >= 3)
        {
            Global.App_Adres_Sec = "";
            Global.App_Hat_No = s1;
            Global.App_Hat_Tanim = s2;
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/HatDuraklar), 0);
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Durak Numaras\u0131\n5 Basamakl\u0131 Say\u0131 Olmal\u0131!", 1).show();
            return;
        }
    }

    public void FavoriHatSorgula()
    {
        String s = ((EditText)findViewById(0x7f090007)).getText().toString();
        if (s.length() >= 3)
        {
            ((TextView)findViewById(0x7f090008)).setText("");
            http = new Http("HatAra", "favori.asp", new String[] {
                "FNC", "HatAra"
            }, new String[] {
                "NO", s
            });
            http.addObserver(new Http.Callback() {

                final Alarm this$0;

                public void onComplete(String s3, String s4, int i, Boolean boolean1, String s5)
                {
                    Action(s3, s4, i, boolean1, s5);
                }

            
            {
                this$0 = Alarm.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        }
        String s1 = ((EditText)findViewById(0x7f090009)).getText().toString();
        String s2 = ((TextView)findViewById(0x7f09000a)).getText().toString();
        if (s1.length() == 5)
        {
            Global.App_Adres_Sec = "HatAra";
            Global.App_Favorilerim_Durak_No = s1;
            Global.App_Favorilerim_Durak_Tanim = s2;
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar), 0);
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Hat Numaras\u0131\nEn Az 3 Basamakl\u0131 Say\u0131 Olmal\u0131!", 1).show();
            return;
        }
    }

    public void Favorilerim_OnClick(View view)
    {
        CloseKeyboard();
        String s = ((ImageButton)view).getTag().toString();
        if (s.equals("Hat"))
        {
            Global.App_Hat_Sec = "Favorilerim";
            Global.App_Favorilerim_Hat_No = "";
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimHat), 0);
        }
        if (s.equals("Durak"))
        {
            Global.App_Durak_Sec = "Favorilerim";
            Global.App_Favorilerim_Durak_No = "";
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimDurak), 0);
        }
    }

    public void KlavyeX_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        if (s.equals("HatNo"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090007).getWindowToken(), 0);
            ((EditText)findViewById(0x7f090007)).setText("");
            ((TextView)findViewById(0x7f090008)).setText("");
            ((EditText)findViewById(0x7f090007)).requestFocus();
        }
        if (s.equals("DurakNo"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090009).getWindowToken(), 0);
            ((EditText)findViewById(0x7f090009)).setText("");
            ((TextView)findViewById(0x7f09000a)).setText("");
            ((EditText)findViewById(0x7f090009)).requestFocus();
        }
        inputmethodmanager.toggleSoftInput(2, 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        try
        {
            String as[] = s.split(";");
            if (as.length == 3)
            {
                Global.App_Hat_No = as[0];
                Global.App_Durak_No = as[1];
                Global.App_Otobus_No = as[2];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/OtobusNeredeMap), 0);
            }
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void OtobusYenile(int i)
    {
label0:
        {
            handlerStop();
            handlerRunnable = new Runnable() {

                final Alarm this$0;

                public void run()
                {
label0:
                    {
label1:
                        {
                            try
                            {
                                handler.removeCallbacks(handlerRunnable);
                            }
                            catch (Exception exception) { }
                            if (Global.App_Alarm_Acik)
                            {
                                if (!handlerStatus)
                                {
                                    break label0;
                                }
                                String s = ((EditText)findViewById(0x7f090007)).getText().toString();
                                String s1 = ((EditText)findViewById(0x7f090009)).getText().toString();
                                handlerStatus = false;
                                if (!s.equals(""))
                                {
                                    ((LinearLayout)findViewById(0x7f09000f)).setVisibility(8);
                                } else
                                {
                                    ((LinearLayout)findViewById(0x7f09000f)).setVisibility(0);
                                }
                                if (s1.equals(""))
                                {
                                    break label1;
                                }
                                if (!s.equals(""))
                                {
                                    http = new Http("OtobusAra", "hat.asp", new String[] {
                                        "FNC", "OtobusAra"
                                    }, new String[] {
                                        "QUERY", s, "DURAK", s1, "TYPE", "true"
                                    });
                                } else
                                {
                                    http = new Http("OtobusDurakAra", "durak.asp", new String[] {
                                        "FNC", "DurakAra"
                                    }, new String[] {
                                        "QUERY", s1, "HATNO", s, "TYPE", "true"
                                    });
                                }
                                http.addObserver(new Http.Callback() {

                                    final _cls7 this$1;

                                    public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
                                    {
                                        Action(s, s1, i, boolean1, s2);
                                    }

            
            {
                this$1 = _cls7.this;
                super();
            }
                                });
                                dialog.show();
                                http.execute(new String[0]);
                                ((Button)findViewById(0x7f090011)).setBackgroundColor(Color.parseColor("#FF009900"));
                            }
                            return;
                        }
                        Toast.makeText(getBaseContext(), "Durak Numaras\u0131n\u0131 Giriniz!", 1).show();
                        return;
                    }
                    handlerStop();
                }


            
            {
                this$0 = Alarm.this;
                super();
            }
            };
            if (Global.App_Alarm_Acik)
            {
                if (i != 0)
                {
                    break label0;
                }
                ((Button)findViewById(0x7f090011)).setBackgroundColor(Color.parseColor("#FF009900"));
                handlerStatus = true;
                handler.postDelayed(handlerRunnable, 0L);
            }
            return;
        }
        ((Button)findViewById(0x7f090011)).setBackgroundColor(Color.parseColor("#FF009900"));
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, i);
    }

    public void Panelim()
    {
        Global.App_Panel_Sec = "PanelSec";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/Panelim), 0);
    }

    public void SeekBarYenileme()
    {
        ((TextView)findViewById(0x7f09000b)).setText((new StringBuilder(" Yenileme\n ")).append(15 * (1 + seekBarYenileme.getProgress())).append(" Saniye").toString());
        ((TextView)findViewById(0x7f09000d)).setText((new StringBuilder(" Dura\u011Fa Yakla\u015Fma\n ")).append(5 + seekBarYaklasma.getProgress()).append(" Dakika").toString());
    }

    public void Sorgula_OnClick(View view)
    {
        CloseKeyboard();
        String s = ((ImageButton)view).getTag().toString();
        if (s.equals("Hat"))
        {
            FavoriHatSorgula();
        }
        if (s.equals("Durak"))
        {
            FavoriDurakSorgula();
        }
    }

    public void ToolBar_OnClick(View view)
    {
        CloseKeyboard();
        String s = view.getTag().toString();
        if (!s.equals("0"))
        {
            handlerStop();
        }
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                AlarmKaydet();
                return;
            }
            if (s.equals("3"))
            {
                OtobusYenile(0);
                return;
            }
            if (s.equals("4"))
            {
                handlerStop();
                return;
            }
        }
    }

    public void handlerStop()
    {
        handlerStatus = false;
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        ((Button)findViewById(0x7f090011)).setBackgroundColor(0);
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (Global.App_Hat_Sec.equals("Favorilerim"))
        {
            if (j == 10 && !Global.App_Favorilerim_Hat_No.equals(""))
            {
                ((EditText)findViewById(0x7f090007)).setText(Global.App_Favorilerim_Hat_No);
                ((TextView)findViewById(0x7f090008)).setText(Global.App_Favorilerim_Hat_Tanim);
            }
            Global.App_Hat_Sec = "";
            Global.App_Favorilerim_Hat_No = "";
            Global.App_Favorilerim_Hat_Tanim = "";
        }
        if (Global.App_Durak_Sec.equals("Favorilerim"))
        {
            if (j == 10 && !Global.App_Favorilerim_Durak_No.equals(""))
            {
                ((EditText)findViewById(0x7f090009)).setText(Global.App_Favorilerim_Durak_No);
                ((TextView)findViewById(0x7f09000a)).setText(Global.App_Favorilerim_Durak_Tanim);
            }
            Global.App_Durak_Sec = "";
            Global.App_Favorilerim_Durak_No = "";
            Global.App_Favorilerim_Durak_Tanim = "";
        }
        if (Global.App_Adres_Sec.equals("HatAra"))
        {
            if (j == 10 && !Global.App_Hat_No.equals(""))
            {
                ((EditText)findViewById(0x7f090007)).setText(Global.App_Hat_No);
                FavoriHatSorgula();
            }
            Global.App_Adres_Sec = "";
            Global.App_Hat_No = "";
            Global.App_Hat_Tanim = "";
            Global.App_Durak_No = "";
            Global.App_Durak_Tanim = "";
            Global.App_Favorilerim_Durak_No = "";
            Global.App_Favorilerim_Durak_Tanim = "";
        }
        if (Global.App_Adres_Sec.equals("DurakAra"))
        {
            Global.App_Adres_Sec = "";
            if (j == 10 && !Global.App_Durak_No.equals(""))
            {
                ((EditText)findViewById(0x7f090009)).setText(Global.App_Durak_No);
                FavoriDurakSorgula();
                if (((EditText)findViewById(0x7f090007)).getText().toString().equals(""))
                {
                    Global.App_Adres_Sec = "HatAra";
                    Global.App_Favorilerim_Durak_No = Global.App_Durak_No;
                    Global.App_Favorilerim_Durak_Tanim = Global.App_Durak_Tanim;
                    startActivityForResult(new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar), 0);
                }
            }
            Global.App_Durak_No = "";
            Global.App_Durak_Tanim = "";
        }
        if (Global.App_Panel_Sec.equals("PanelSec"))
        {
            Global.App_Panel_Sec = "";
            if (j == 10)
            {
                ((EditText)findViewById(0x7f090007)).setText(Global.App_Hat_No);
                ((TextView)findViewById(0x7f090008)).setText(Global.App_Hat_Tanim);
                ((EditText)findViewById(0x7f090009)).setText(Global.App_Durak_No);
                ((TextView)findViewById(0x7f09000a)).setText(Global.App_Durak_Tanim);
            }
            Global.App_Hat_No = "";
            Global.App_Hat_Tanim = "";
            Global.App_Durak_No = "";
            Global.App_Durak_Tanim = "";
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030002);
        CloseKeyboard();
        Global.App_Alarm_Acik = true;
        dialog = Tools.Waiting(this);
        seekBarYenileme = (SeekBar)findViewById(0x7f09000c);
        seekBarYenileme.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {

            final Alarm this$0;

            public void onProgressChanged(SeekBar seekbar, int i, boolean flag)
            {
                SeekBarYenileme();
            }

            public void onStartTrackingTouch(SeekBar seekbar)
            {
            }

            public void onStopTrackingTouch(SeekBar seekbar)
            {
            }

            
            {
                this$0 = Alarm.this;
                super();
            }
        });
        seekBarYaklasma = (SeekBar)findViewById(0x7f09000e);
        seekBarYaklasma.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {

            final Alarm this$0;

            public void onProgressChanged(SeekBar seekbar, int i, boolean flag)
            {
                SeekBarYenileme();
            }

            public void onStartTrackingTouch(SeekBar seekbar)
            {
            }

            public void onStopTrackingTouch(SeekBar seekbar)
            {
            }

            
            {
                this$0 = Alarm.this;
                super();
            }
        });
        Global.App_Hat_Sec = "";
        Global.App_Durak_Sec = "";
        Global.App_Adres_Sec = "";
        Global.App_Panel_Sec = "";
        AlarmSorgula();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        menu.add(0, 3, 3, "Panelim");
        menu.add(0, 4, 4, "Durak Ara");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 4: default 36
    //                   1 42
    //                   2 59
    //                   3 70
    //                   4 77;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        handlerStop();
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        handlerStop();
        finish();
        continue; /* Loop/switch isn't completed */
_L4:
        Panelim();
        continue; /* Loop/switch isn't completed */
_L5:
        DurakAra();
        if (true) goto _L1; else goto _L6
_L6:
    }

    public void onResume()
    {
        super.onResume();
        pageStatus = true;
    }

    protected void onStop()
    {
        pageStatus = false;
        CloseKeyboard();
        super.onStop();
    }
}
