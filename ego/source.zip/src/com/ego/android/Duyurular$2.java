// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Duyurular, Global, DuyurularDetay

class this._cls0
    implements android.widget.OnItemClickListener
{

    final Duyurular this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        Global.App_Duyuru_Id = (String)((HashMap)((ListView)findViewById(0x7f09002b)).getItemAtPosition(i)).get("id");
        Intent intent = new Intent(getBaseContext(), com/ego/android/DuyurularDetay);
        startActivityForResult(intent, 0);
    }

    ay()
    {
        this$0 = Duyurular.this;
        super();
    }
}
