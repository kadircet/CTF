// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Handler;

// Referenced classes of package com.ego.android:
//            EgoOtobusHatlari, MainMenu

class this._cls0
    implements Runnable
{

    final EgoOtobusHatlari this$0;

    public void run()
    {
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception1) { }
        if (handlerStatus)
        {
            handlerStatus = false;
            Intent intent = new Intent(getBaseContext(), com/ego/android/MainMenu);
            startActivityForResult(intent, 0);
        }
    }

    ()
    {
        this$0 = EgoOtobusHatlari.this;
        super();
    }
}
