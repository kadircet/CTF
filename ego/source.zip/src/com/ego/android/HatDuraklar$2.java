// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            HatDuraklar, Global

class this._cls0
    implements android.widget.ItemClickListener
{

    final HatDuraklar this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        HashMap hashmap = (HashMap)((ListView)findViewById(0x7f090033)).getItemAtPosition(i);
        Global.App_Adres_Sec = "DurakAra";
        Global.App_Durak_No = (String)hashmap.get("ad");
        Global.App_Durak_Tanim = (String)hashmap.get("yer");
        Intent intent = new Intent();
        setResult(10, intent);
        finish();
    }

    temClickListener()
    {
        this$0 = HatDuraklar.this;
        super();
    }
}
