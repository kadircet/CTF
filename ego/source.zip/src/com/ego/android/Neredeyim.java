// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Point;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import com.google.android.maps.Projection;
import java.util.List;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Global, Http, Map, AdresAra, 
//            MapOverlay, MapDraw, Gps, YakindakiDurakVeHatlar, 
//            DuraktanGecenHatlar, OtobusNerede, FavorilerimDurakDuzenle, Tools

public class Neredeyim extends MapActivity
{

    ProgressDialog dialog;
    Gps gps;
    boolean gpsYenile;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    boolean konum;
    String konumAdres;
    String konumIlce;
    GeoPoint konumPosition;
    long lastTouchDoubleTime;
    Point lastTouchPositon;
    long lastTouchTime;
    List lo;
    boolean location;
    String locationAdres;
    String locationIlce;
    GeoPoint locationPosition;
    MapController mc;
    MapView mv;
    int zoom;

    public Neredeyim()
    {
        lastTouchTime = -1L;
        lastTouchDoubleTime = -1L;
        lastTouchPositon = new Point(0, 0);
        location = false;
        locationAdres = "";
        locationIlce = "";
        konum = false;
        konumAdres = "";
        konumIlce = "";
        gpsYenile = false;
        handler = new Handler();
        handlerStatus = false;
        zoom = Integer.parseInt(Global.Set_Yaklasim);
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        int j;
        Exception exception1;
        GeoPoint geopoint;
        String as[];
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200)
        {
            break MISSING_BLOCK_LABEL_231;
        }
        if (!s.equals("YakinDuraklar"))
        {
            break MISSING_BLOCK_LABEL_253;
        }
        j = 0;
        try
        {
            if (j >= http.jArray.length())
            {
                mv.invalidate();
                return;
            }
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception1)
        {
            return;
        }
        geopoint = Map.GP((new StringBuilder()).append(http.JValue(j, "lat")).toString(), (new StringBuilder()).append(http.JValue(j, "lng")).toString());
        as = new String[2];
        as[0] = http.JValue(j, "ad");
        as[1] = http.JValue(j, "yer");
        CreateMarker("Durak", 0x7f02001d, geopoint, as, (new StringBuilder("Durak ")).append(http.JValue(j, "ad")).toString(), (new StringBuilder(String.valueOf(http.JValue(j, "yer")))).append("\n\n").append(http.JValue(j, "aciklama")).toString(), "Duraktan Ge\347en Hatlar", "Otob\374s Nerede ?", "Favorilerime Ekle");
        j++;
        break MISSING_BLOCK_LABEL_26;
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
    }

    public void AdresAra()
    {
        Global.App_Adres_Sec = "AdresAra";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/AdresAra), 0);
    }

    public void Ara_OnClick(View view)
    {
        AdresAra();
    }

    public void CreateMarker(String s, int i, GeoPoint geopoint, String as[], String s1, String s2, String s3, 
            String s4, String s5)
    {
        MapOverlay mapoverlay = new MapOverlay(s, getResources().getDrawable(i), mv, as, s3, s4, s5);
        mapoverlay.addObserver(new MapOverlay.Callback() {

            final Neredeyim this$0;

            public void onButtonClick(String s6, OverlayItem overlayitem, String as1[], int j)
            {
                MarkerAction(s6, overlayitem, as1, j);
            }

            
            {
                this$0 = Neredeyim.this;
                super();
            }
        });
        mapoverlay.addOverlay(new OverlayItem(geopoint, s1, s2));
        lo.add(mapoverlay);
    }

    public void Isaretle(String s, GeoPoint geopoint, int i, String s1)
    {
        if (i > 0)
        {
            mc.setZoom(i);
        }
        Map.CloseBalloon(mv);
        if (geopoint != null)
        {
            mc.setCenter(geopoint);
        }
        lo = mv.getOverlays();
        lo.clear();
        if (konum)
        {
            MapDraw mapdraw = new MapDraw("Circle", konumPosition, Integer.parseInt(Global.Set_Yakinlik), 0xff0000ff, Color.argb(20, 0, 0, 255), 1);
            lo.add(mapdraw);
            CreateMarker("Konum", 0x7f020066, konumPosition, null, "Konum", (new StringBuilder(String.valueOf(konumAdres))).append("\n").append(konumIlce).toString(), "Yak\u0131ndaki Durak ve Hatlar", "", "");
        }
        if (location)
        {
            CreateMarker("Location", 0x7f020067, locationPosition, null, "Konumum", (new StringBuilder(String.valueOf(locationAdres))).append("\n").append(locationIlce).toString(), "Yak\u0131ndaki Durak ve Hatlar", "", "");
        }
        if (konum)
        {
            String as[] = {
                "FNC", "YakinDuraklar"
            };
            String as1[] = new String[8];
            as1[0] = "QUERY";
            as1[1] = "";
            as1[2] = "LAT";
            as1[3] = (new StringBuilder()).append((double)konumPosition.getLatitudeE6() / 1000000D).toString();
            as1[4] = "LNG";
            as1[5] = (new StringBuilder()).append((double)konumPosition.getLongitudeE6() / 1000000D).toString();
            as1[6] = "MESAFE";
            as1[7] = Global.Set_Yakinlik;
            http = new Http("YakinDuraklar", "hat.asp", as, as1);
            http.addObserver(new Http.Callback() {

                final Neredeyim this$0;

                public void onComplete(String s2, String s3, int j, Boolean boolean1, String s4)
                {
                    Action(s2, s3, j, boolean1, s4);
                }

            
            {
                this$0 = Neredeyim.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
        }
        mv.invalidate();
    }

    public void Location()
    {
        gps = new Gps(this);
        gps.GpsYenile = gpsYenile;
        gps.addObserver(new Gps.Callback() {

            final Neredeyim this$0;

            public void onComplete(Location location1)
            {
                Exception exception1;
                GeoPoint geopoint;
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location1 != null)
                {
                    break MISSING_BLOCK_LABEL_169;
                }
                Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                geopoint = Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString());
                locationAdres = "K\u0131z\u0131lay Meydan\u0131";
                locationIlce = "\307ankaya";
_L1:
                location = true;
                locationPosition = geopoint;
                Isaretle("Location", geopoint, 17, "");
                Toast.makeText(getBaseContext(), (new StringBuilder("Konumum\n\n")).append(locationAdres).append("\n").append(locationIlce).toString(), 1).show();
                return;
                try
                {
                    geopoint = Map.GP((new StringBuilder()).append(location1.getLatitude()).toString(), (new StringBuilder()).append(location1.getLongitude()).toString());
                    locationAdres = gps.GpsAdres;
                    locationIlce = gps.GpsIlce;
                }
                // Misplaced declaration of an exception variable
                catch (Exception exception1)
                {
                    return;
                }
                  goto _L1
            }

            
            {
                this$0 = Neredeyim.this;
                super();
            }
        });
        gps.Start();
    }

    public void MarkerAction(String s, OverlayItem overlayitem, String as[], int i)
    {
        if (s.equals("Location"))
        {
            Global.App_Adres_Query = "";
            Global.App_Adres_Adres = locationAdres;
            Global.App_Adres_Ilce = locationIlce;
            Global.App_Adres_Lat = (new StringBuilder()).append((double)locationPosition.getLatitudeE6() / 1000000D).toString();
            Global.App_Adres_Lng = (new StringBuilder()).append((double)locationPosition.getLongitudeE6() / 1000000D).toString();
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar), 0);
        }
        if (s.equals("Konum"))
        {
            Global.App_Adres_Query = "";
            Global.App_Adres_Adres = konumAdres;
            Global.App_Adres_Ilce = konumIlce;
            Global.App_Adres_Lat = (new StringBuilder()).append((double)konumPosition.getLatitudeE6() / 1000000D).toString();
            Global.App_Adres_Lng = (new StringBuilder()).append((double)konumPosition.getLongitudeE6() / 1000000D).toString();
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar), 0);
        }
        if (s.equals("Durak"))
        {
            if (i == 1)
            {
                Global.App_Favorilerim_Durak_No = as[0];
                Global.App_Favorilerim_Durak_Tanim = as[1];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar), 0);
            }
            if (i == 2)
            {
                Global.App_Durak_No = as[0];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/OtobusNerede), 0);
            }
            if (i == 3)
            {
                Global.App_Favorilerim_Durak_Ekle = as[0];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimDurakDuzenle), 0);
            }
        }
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final Neredeyim this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = Neredeyim.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                gpsYenile = true;
                Runnable("Location");
                return;
            }
            if (s.equals("3"))
            {
                Yakinlik();
                return;
            }
            if (s.equals("4"))
            {
                mv.getController().zoomIn();
                return;
            }
            if (s.equals("5") && mv.getZoomLevel() >= 12)
            {
                mv.getController().zoomOut();
                return;
            }
        }
    }

    public void YakindakiDurakVeHatlar()
    {
        if (konum)
        {
            Global.App_Adres_Query = "";
            Global.App_Adres_Adres = konumAdres;
            Global.App_Adres_Ilce = konumIlce;
            Global.App_Adres_Lat = (new StringBuilder()).append((double)konumPosition.getLatitudeE6() / 1000000D).toString();
            Global.App_Adres_Lng = (new StringBuilder()).append((double)konumPosition.getLongitudeE6() / 1000000D).toString();
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar), 0);
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Harita \334zerinden Bir Konum Se\347iniz!", 1).show();
            return;
        }
    }

    public void Yakinlik()
    {
        final Dialog dialogBox = new Dialog(this);
        dialogBox.setTitle("Durak Yak\u0131nl\u0131\u011F\u0131");
        dialogBox.requestWindowFeature(1);
        dialogBox.setContentView(0x7f030005);
        dialogBox.getWindow().setGravity(48);
        dialogBox.setCanceledOnTouchOutside(true);
        ((ImageView)dialogBox.findViewById(0x7f090020)).setOnClickListener(new android.view.View.OnClickListener() {

            final Neredeyim this$0;
            private final Dialog val$dialogBox;

            public void onClick(View view)
            {
                dialogBox.dismiss();
            }

            
            {
                this$0 = Neredeyim.this;
                dialogBox = dialog1;
                super();
            }
        });
        ((TextView)dialogBox.findViewById(0x7f09001f)).setText("Durak Yak\u0131nl\u0131\u011F\u0131");
        ((TextView)dialogBox.findViewById(0x7f090021)).setText("\nSe\347ili Konum \u0130le En Uzak Durak Mesafesi");
        String as[] = {
            "250", "500", "750", "1000"
        };
        int i = 0;
        do
        {
            if (i >= as.length)
            {
                dialogBox.show();
                return;
            }
            Button button = new Button(this);
            if (i == 0)
            {
                button = (Button)dialogBox.findViewById(0x7f090022);
            }
            if (i == 1)
            {
                button = (Button)dialogBox.findViewById(0x7f090023);
            }
            if (i == 2)
            {
                button = (Button)dialogBox.findViewById(0x7f090024);
            }
            if (i == 3)
            {
                button = (Button)dialogBox.findViewById(0x7f090025);
            }
            button.setOnClickListener(new android.view.View.OnClickListener() {

                final Neredeyim this$0;
                private final Dialog val$dialogBox;

                public void onClick(View view)
                {
                    String as1[] = ((Button)view).getTag().toString().toString().split(";");
                    dialogBox.dismiss();
                    Global.Set_Yakinlik = as1[1];
                    Isaretle("Konum", konumPosition, 17 - Integer.parseInt(as1[0]), "");
                }

            
            {
                this$0 = Neredeyim.this;
                dialogBox = dialog1;
                super();
            }
            });
            String s;
            if (Global.Set_Yakinlik.equals(as[i]))
            {
                s = "* ";
            } else
            {
                s = "";
            }
            button.setText((new StringBuilder(String.valueOf(s))).append(as[i]).append(" Metre").toString());
            button.setTag((new StringBuilder(String.valueOf(i))).append(";").append(as[i]).toString());
            button.setVisibility(0);
            i++;
        } while (true);
    }

    protected boolean isRouteDisplayed()
    {
        return false;
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (Global.App_Adres_Sec.equals("AdresAra"))
        {
            if (j == 10 && !Global.App_Adres_Lat.equals("") && !Global.App_Adres_Lng.equals(""))
            {
                GeoPoint geopoint = Map.GP((new StringBuilder()).append(Global.App_Adres_Lat).toString(), (new StringBuilder()).append(Global.App_Adres_Lng).toString());
                konum = true;
                konumPosition = geopoint;
                konumAdres = Global.App_Adres_Adres;
                konumIlce = Global.App_Adres_Ilce;
                Isaretle("Konum", konumPosition, 17, "");
            }
            Global.App_Adres_Sec = "";
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03002b);
        dialog = Tools.Waiting(this);
        mv = (MapView)findViewById(0x7f090003);
        mc = mv.getController();
        if (Global.Set_HaritaTipi.equals("Harita"))
        {
            mv.setSatellite(false);
        }
        if (Global.Set_HaritaTipi.equals("Uydu"))
        {
            mv.setSatellite(true);
        }
        mv.setBuiltInZoomControls(false);
        mc.setCenter(Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString()));
        mc.setZoom(zoom);
        gpsYenile = false;
        Runnable("Location");
        mv.setOnTouchListener(new android.view.View.OnTouchListener() {

            final Neredeyim this$0;

            public boolean onTouch(View view, MotionEvent motionevent)
            {
                if (motionevent.getAction() != 1) goto _L2; else goto _L1
_L1:
                if (lastTouchPositon == null) goto _L4; else goto _L3
_L3:
                GeoPoint geopoint;
                int k;
                int l;
                geopoint = mv.getProjection().fromPixels((int)motionevent.getX(), (int)motionevent.getY());
                int i = (int)motionevent.getX() - lastTouchPositon.x;
                int j = (int)motionevent.getY() - lastTouchPositon.y;
                k = Math.abs(i);
                l = Math.abs(j);
                if (k > 10 || l > 10)
                {
                    break MISSING_BLOCK_LABEL_277;
                }
                if (motionevent.getEventTime() - lastTouchTime < 250L || motionevent.getEventTime() - lastTouchTime > 1000L)
                {
                    break MISSING_BLOCK_LABEL_287;
                }
                konum = true;
                konumPosition = geopoint;
                konumAdres = "";
                konumIlce = "";
                String as[] = Tools.GeoCoder(konumPosition);
                if (!as[0].equals(""))
                {
                    konumAdres = as[0];
                    konumIlce = as[1];
                }
                Isaretle("Konum", konumPosition, 0, "");
                lastTouchTime = -1L;
                lastTouchDoubleTime = -1L;
                lastTouchPositon = null;
                return true;
                try
                {
                    lastTouchTime = -1L;
                }
                catch (Exception exception) { }
                lastTouchTime = -1L;
_L2:
                if (motionevent.getAction() != 0)
                {
                    break MISSING_BLOCK_LABEL_445;
                }
                if (motionevent.getEventTime() - lastTouchDoubleTime < 250L)
                {
                    mc.setZoom(1 + mv.getZoomLevel());
                    mv.invalidate();
                    lastTouchTime = -1L;
                    lastTouchDoubleTime = -1L;
                    lastTouchPositon = null;
                    return true;
                }
                break; /* Loop/switch isn't completed */
_L4:
                lastTouchTime = -1L;
                if (true) goto _L2; else goto _L5
_L5:
                lastTouchPositon = new Point((int)motionevent.getX(), (int)motionevent.getY());
                lastTouchTime = motionevent.getEventTime();
                lastTouchDoubleTime = motionevent.getEventTime();
                return false;
            }

            
            {
                this$0 = Neredeyim.this;
                super();
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        menu.add(0, 3, 3, "Yak\u0131ndaki Durak ve Hatlar");
        menu.add(0, 4, 4, "Adres Ara");
        menu.add(0, 5, 5, "Harita G\366r\374n\374m\374");
        menu.add(0, 6, 6, "Uydu G\366r\374n\374m\374");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 6: default 44
    //                   1 50
    //                   2 63
    //                   3 70
    //                   4 77
    //                   5 84
    //                   6 95;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L7
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        continue; /* Loop/switch isn't completed */
_L4:
        YakindakiDurakVeHatlar();
        continue; /* Loop/switch isn't completed */
_L5:
        AdresAra();
        continue; /* Loop/switch isn't completed */
_L6:
        mv.setSatellite(false);
        continue; /* Loop/switch isn't completed */
_L7:
        mv.setSatellite(true);
        if (true) goto _L1; else goto _L8
_L8:
    }

    protected void onStop()
    {
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        super.onStop();
    }
}
