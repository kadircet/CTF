// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.media.MediaPlayer;

// Referenced classes of package com.ego.android:
//            Alarm

class this._cls0
    implements android.media.yer.OnCompletionListener
{

    final Alarm this$0;

    public void onCompletion(MediaPlayer mediaplayer)
    {
        try
        {
            Thread.sleep(1000L);
        }
        catch (Exception exception) { }
        mediaplayer.release();
    }

    r()
    {
        this$0 = Alarm.this;
        super();
    }
}
