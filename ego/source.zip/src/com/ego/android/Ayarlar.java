// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Global, Http, ListAdapter, Tools

public class Ayarlar extends Activity
{

    String deger[];
    String degerler[] = {
        "Harita;Uydu", "14;15;16;17;18", "5 Saniye;15 Saniye;30 Saniye;45 Saniye;60 Saniye;Kapal\u0131", "Takip Et;Kapal\u0131", "G\366ster;Kapal\u0131", "250 Metre;500 Metre;750 Metre;1000 Metre"
    };
    ProgressDialog dialog;
    Http http;

    public Ayarlar()
    {
        String as[] = new String[9];
        as[0] = Global.Set_AdSoyad;
        as[1] = Global.Set_Telefon;
        as[2] = Global.Set_EPosta;
        as[3] = Global.Set_HaritaTipi;
        as[4] = Global.Set_Yaklasim;
        as[5] = Global.Set_OtobusKonumGuncelleme;
        as[6] = Global.Set_OtobusOtomatikTakip;
        as[7] = Global.Set_HatDurakGorunumu;
        as[8] = (new StringBuilder(String.valueOf(Global.Set_Yakinlik))).append(" Metre").toString();
        deger = as;
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200)
        {
            break MISSING_BLOCK_LABEL_345;
        }
        if (!s.equals("Kaydet")) goto _L2; else goto _L1
_L1:
        if (!http.JValue(0, "status").equals("true")) goto _L4; else goto _L3
_L3:
        Toast.makeText(getBaseContext(), "Kullan\u0131c\u0131 Bilgileriniz ve\nAyarlar\u0131n\u0131z Kaydedildi.", 0).show();
        Global.Set_AdSoyad = ((EditText)findViewById(0x7f090013)).getText().toString();
        Global.Set_Telefon = ((EditText)findViewById(0x7f090014)).getText().toString();
        Global.Set_EPosta = ((EditText)findViewById(0x7f090015)).getText().toString();
        Global.Set_HaritaTipi = deger[3];
        Global.Set_Yaklasim = deger[4];
        Global.Set_OtobusKonumGuncelleme = deger[5];
        Global.Set_OtobusOtomatikTakip = deger[6];
        Global.Set_HatDurakGorunumu = deger[7];
        Global.Set_Yakinlik = deger[8].replace(" Metre", "");
        if (Global.Set_OtobusKonumGuncelleme != "5 Saniye") goto _L6; else goto _L5
_L5:
        Global.App_OtobusYenilemeSuresi = 5000;
_L7:
        setResult(10, new Intent());
        finish();
_L2:
        return;
_L6:
        if (Global.Set_OtobusKonumGuncelleme == "15 Saniye")
        {
            Global.App_OtobusYenilemeSuresi = 15000;
        } else
        if (Global.Set_OtobusKonumGuncelleme == "30 Saniye")
        {
            Global.App_OtobusYenilemeSuresi = 30000;
        } else
        if (Global.Set_OtobusKonumGuncelleme == "45 Saniye")
        {
            Global.App_OtobusYenilemeSuresi = 45000;
        } else
        if (Global.Set_OtobusKonumGuncelleme == "60 Saniye")
        {
            Global.App_OtobusYenilemeSuresi = 60000;
        } else
        if (Global.Set_OtobusKonumGuncelleme == "Kapal\u0131")
        {
            Global.App_OtobusYenilemeSuresi = 0;
        }
        if (true) goto _L7; else goto _L4
_L4:
        if (!http.JValue(0, "error").equals(""))
        {
            Toast.makeText(getBaseContext(), http.JValue(0, "error"), 1).show();
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Kullan\u0131c\u0131 Bilgileriniz ve\nAyarlar\u0131n\u0131z Kaydedilemedi!", 1).show();
            return;
        }
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
    }

    public void AyarSecim(int i, String s, String s1, String as[])
    {
        final Dialog dialogBox = new Dialog(this);
        dialogBox.setTitle("Ayar Se\347");
        dialogBox.requestWindowFeature(1);
        dialogBox.setContentView(0x7f030005);
        dialogBox.getWindow().setGravity(48);
        dialogBox.setCanceledOnTouchOutside(true);
        ((ImageView)dialogBox.findViewById(0x7f090020)).setOnClickListener(new android.view.View.OnClickListener() {

            final Ayarlar this$0;
            private final Dialog val$dialogBox;

            public void onClick(View view)
            {
                dialogBox.dismiss();
            }

            
            {
                this$0 = Ayarlar.this;
                dialogBox = dialog1;
                super();
            }
        });
        ((TextView)dialogBox.findViewById(0x7f09001f)).setText(s);
        ((TextView)dialogBox.findViewById(0x7f090021)).setText(s1);
        int j = 0;
        do
        {
            if (j >= as.length)
            {
                dialogBox.show();
                return;
            }
            Button button = new Button(this);
            if (j == 0)
            {
                button = (Button)dialogBox.findViewById(0x7f090022);
            }
            if (j == 1)
            {
                button = (Button)dialogBox.findViewById(0x7f090023);
            }
            if (j == 2)
            {
                button = (Button)dialogBox.findViewById(0x7f090024);
            }
            if (j == 3)
            {
                button = (Button)dialogBox.findViewById(0x7f090025);
            }
            if (j == 4)
            {
                button = (Button)dialogBox.findViewById(0x7f090026);
            }
            if (j == 5)
            {
                button = (Button)dialogBox.findViewById(0x7f090027);
            }
            button.setOnClickListener(new android.view.View.OnClickListener() {

                final Ayarlar this$0;
                private final Dialog val$dialogBox;

                public void onClick(View view)
                {
                    String s3 = ((Button)view).getTag().toString();
                    dialogBox.dismiss();
                    try
                    {
                        String as1[] = s3.split(";");
                        deger[Integer.parseInt(as1[0])] = as1[1];
                        Yenile();
                        return;
                    }
                    catch (Exception exception)
                    {
                        return;
                    }
                }

            
            {
                this$0 = Ayarlar.this;
                dialogBox = dialog1;
                super();
            }
            });
            String s2;
            if (deger[i].equals(as[j]))
            {
                s2 = "* ";
            } else
            {
                s2 = "";
            }
            button.setText((new StringBuilder(String.valueOf(s2))).append(as[j]).toString());
            button.setTag((new StringBuilder(String.valueOf(i))).append(";").append(as[j]).toString());
            button.setVisibility(0);
            j++;
        } while (true);
    }

    public void CloseKeyboard()
    {
        ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(0x7f090013).getWindowToken(), 0);
    }

    public void Kaydet()
    {
        String as[] = {
            "FNC", "KullaniciKaydet"
        };
        String as1[] = new String[20];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        as1[2] = "ADSOYAD";
        as1[3] = ((EditText)findViewById(0x7f090013)).getText().toString();
        as1[4] = "TELEFON";
        as1[5] = ((EditText)findViewById(0x7f090014)).getText().toString();
        as1[6] = "EPOSTA";
        as1[7] = ((EditText)findViewById(0x7f090015)).getText().toString();
        as1[8] = "HARITATIPI";
        as1[9] = deger[3];
        as1[10] = "YAKLASIM";
        as1[11] = deger[4];
        as1[12] = "OTOBUSKONUMGUNCELLEME";
        as1[13] = deger[5];
        as1[14] = "OTOBUSOTOMATIKTAKIP";
        as1[15] = deger[6];
        as1[16] = "HATDURAKGORUNUMU";
        as1[17] = deger[7];
        as1[18] = "YAKINLIK";
        as1[19] = deger[8].replace(" Metre", "");
        http = new Http("Kaydet", "kullanici.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final Ayarlar this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = Ayarlar.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void KlavyeX_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        if (s.equals("AdSoyad"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090013).getWindowToken(), 0);
            ((EditText)findViewById(0x7f090013)).setText("");
            ((EditText)findViewById(0x7f090013)).requestFocus();
        }
        if (s.equals("Telefon"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090014).getWindowToken(), 0);
            ((EditText)findViewById(0x7f090014)).setText("");
            ((EditText)findViewById(0x7f090014)).requestFocus();
        }
        if (s.equals("EPosta"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090015).getWindowToken(), 0);
            ((EditText)findViewById(0x7f090015)).setText("");
            ((EditText)findViewById(0x7f090015)).requestFocus();
        }
        inputmethodmanager.toggleSoftInput(2, 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void ToolBar_OnClick(View view)
    {
        CloseKeyboard();
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Kaydet();
                return;
            }
            if (!s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    public void Yenile()
    {
        CloseKeyboard();
        ListView listview = (ListView)findViewById(0x7f090016);
        ArrayList arraylist = new ArrayList();
        new HashMap();
        HashMap hashmap = new HashMap();
        hashmap.put("id", "0");
        hashmap.put("tanim", "Harita Tipi");
        hashmap.put("deger", deger[3]);
        hashmap.put("aciklama", "Harita G\366r\374nt\374leme Tipi");
        arraylist.add(hashmap);
        HashMap hashmap1 = new HashMap();
        hashmap1.put("id", "1");
        hashmap1.put("tanim", "Harita Yak\u0131nl\u0131\u011F\u0131");
        hashmap1.put("deger", deger[4]);
        hashmap1.put("aciklama", "Harita G\366r\374nt\374leme Yak\u0131nl\u0131\u011F\u0131");
        arraylist.add(hashmap1);
        HashMap hashmap2 = new HashMap();
        hashmap2.put("id", "2");
        hashmap2.put("tanim", "Otob\374s Konum G\374ncelleme");
        hashmap2.put("deger", deger[5]);
        hashmap2.put("aciklama", "Otob\374slerin Konumlar\u0131n\u0131 G\374ncelleme S\u0131kl\u0131\u011F\u0131");
        arraylist.add(hashmap2);
        HashMap hashmap3 = new HashMap();
        hashmap3.put("id", "3");
        hashmap3.put("tanim", "Otob\374s Otomatik Takip");
        hashmap3.put("deger", deger[6]);
        hashmap3.put("aciklama", "Otob\374sleri Harita \334zerinde Otomatik Takip Durumu");
        arraylist.add(hashmap3);
        HashMap hashmap4 = new HashMap();
        hashmap4.put("id", "4");
        hashmap4.put("tanim", "Hat Durak G\366r\374n\374m\374");
        hashmap4.put("deger", deger[7]);
        hashmap4.put("aciklama", "Hatlar\u0131n Duraklar\u0131n\u0131 Harita \334zerinde G\366sterme Durumu");
        arraylist.add(hashmap4);
        HashMap hashmap5 = new HashMap();
        hashmap5.put("id", "5");
        hashmap5.put("tanim", "Durak Yak\u0131nl\u0131\u011F\u0131");
        hashmap5.put("deger", deger[8]);
        hashmap5.put("aciklama", "Se\347ilen Konuma En Uzak Durak Mesafesi");
        arraylist.add(hashmap5);
        listview.setAdapter(new ListAdapter(this, arraylist, 0x7f030016, new String[] {
            "tanim", "deger", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048
        }));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final Ayarlar this$0;

            public void onItemClick(AdapterView adapterview, View view, int i, long l)
            {
                HashMap hashmap6 = (HashMap)((ListView)findViewById(0x7f090016)).getItemAtPosition(i);
                AyarSecim(3 + Integer.parseInt((String)hashmap6.get("id")), (String)hashmap6.get("tanim"), (new StringBuilder("\n")).append((String)hashmap6.get("aciklama")).toString(), degerler[Integer.parseInt((String)hashmap6.get("id"))].split(";"));
            }

            
            {
                this$0 = Ayarlar.this;
                super();
            }
        });
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030003);
        CloseKeyboard();
        dialog = Tools.Waiting(this);
        ((EditText)findViewById(0x7f090013)).setText(deger[0]);
        ((EditText)findViewById(0x7f090014)).setText(deger[1]);
        ((EditText)findViewById(0x7f090015)).setText(deger[2]);
        Yenile();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        CloseKeyboard();
        super.onStop();
    }
}
