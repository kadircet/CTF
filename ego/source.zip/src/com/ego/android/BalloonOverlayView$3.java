// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.view.View;

// Referenced classes of package com.ego.android:
//            BalloonOverlayView

class this._cls0
    implements android.view.._cls3
{

    final BalloonOverlayView this$0;

    public void onClick(View view)
    {
        buttonClick(1);
    }

    ()
    {
        this$0 = BalloonOverlayView.this;
        super();
    }
}
