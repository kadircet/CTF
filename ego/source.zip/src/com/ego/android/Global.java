// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.location.Location;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

public final class Global
{

    public static String App_Adres_Adres = "";
    public static String App_Adres_Ara = "";
    public static String App_Adres_Ilce = "";
    public static String App_Adres_Lat = "";
    public static String App_Adres_Lng = "";
    public static String App_Adres_Map_Sec = "";
    public static String App_Adres_Query = "";
    public static String App_Adres_Sec = "";
    public static String App_Adres_Status = "";
    public static boolean App_Alarm_Acik = false;
    public static String App_CurrentVersion = "2.0.5";
    public static String App_Durak_Ara = "";
    public static String App_Durak_Lat = "";
    public static String App_Durak_Lng = "";
    public static String App_Durak_No = "";
    public static String App_Durak_Sec = "";
    public static String App_Durak_Tanim = "";
    public static String App_Duyuru_Id = "";
    public static String App_Favorilerim_Durak_Ekle = "";
    public static String App_Favorilerim_Durak_No = "";
    public static String App_Favorilerim_Durak_Tanim = "";
    public static String App_Favorilerim_Durak_Yenile = "";
    public static String App_Favorilerim_Hat_Ekle = "";
    public static String App_Favorilerim_Hat_No = "";
    public static String App_Favorilerim_Hat_Tanim = "";
    public static String App_Favorilerim_Hat_Yenile = "";
    public static String App_Gps_Adres = "";
    public static String App_Gps_Ilce = "";
    public static String App_Gps_Lat = "";
    public static String App_Gps_Lng = "";
    public static Location App_Gps_Location;
    public static boolean App_Gps_Wait = false;
    public static String App_Hat_Ara = "";
    public static String App_Hat_No = "";
    public static String App_Hat_Sec = "";
    public static String App_Hat_Tanim = "";
    public static String App_HttpServis = "212.175.165.42";
    public static String App_HttpServisUrl = "/mobil/android/";
    public static String App_Konum = "";
    public static String App_Konum_Adres = "";
    public static String App_Konum_Durak_No = "";
    public static String App_Konum_Durak_Tanim = "";
    public static String App_Konum_Ilce = "";
    public static String App_Konum_Lat = "";
    public static String App_Konum_Lng = "";
    public static double App_Merkez_Lat = 39.920769999999997D;
    public static double App_Merkez_Lng = 32.854109999999999D;
    public static String App_Message = "";
    public static HashMap App_NasilGiderim = null;
    public static String App_NasilGiderim_Siralama = "";
    public static String App_Nereden_Adres = "";
    public static String App_Nereden_Ilce = "";
    public static String App_Nereden_Lat = "";
    public static String App_Nereden_Lng = "";
    public static String App_Nereye_Adres = "";
    public static String App_Nereye_Ilce = "";
    public static String App_Nereye_Lat = "";
    public static String App_Nereye_Lng = "";
    public static String App_OnemliYer_Lat = "";
    public static String App_OnemliYer_Lng = "";
    public static String App_OnemliYer_Tur = "";
    public static String App_OnemliYer_Yer = "";
    public static int App_OtobusYenilemeSuresi = 30000;
    public static String App_Otobus_No = "";
    public static String App_Panel_Id = "";
    public static String App_Panel_No = "";
    public static String App_Panel_Sec = "";
    public static ArrayList App_SorunBirim = new ArrayList();
    public static ArrayList App_SorunKonu = new ArrayList();
    public static String App_Sorun_Id = "";
    public static String App_Update = "";
    public static String Device_ID = "";
    public static String Device_Manufacturer = "";
    public static String Device_Name = "";
    public static String Set_AdSoyad = "";
    public static String Set_EPosta = "";
    public static String Set_HaritaTipi = "Harita";
    public static String Set_HatDurakGorunumu = "G\366ster";
    public static String Set_OtobusKonumGuncelleme = "30 Saniye";
    public static String Set_OtobusOtomatikTakip = "Takip Et";
    public static String Set_Telefon = "";
    public static String Set_Yakinlik = "250";
    public static String Set_Yaklasim = "17";
    public static JSONArray durakArray = null;
    public static JSONArray hatArray = null;

    public Global()
    {
    }

    public static boolean Clear()
    {
        if (Device_ID.equals(""))
        {
            return false;
        } else
        {
            App_Panel_Id = "";
            App_Panel_No = "";
            App_Panel_Sec = "";
            App_Favorilerim_Durak_No = "";
            App_Favorilerim_Durak_Tanim = "";
            App_Favorilerim_Durak_Yenile = "";
            App_Favorilerim_Durak_Ekle = "";
            App_Favorilerim_Hat_No = "";
            App_Favorilerim_Hat_Tanim = "";
            App_Favorilerim_Hat_Yenile = "";
            App_Favorilerim_Hat_Ekle = "";
            App_Durak_Sec = "";
            App_Durak_No = "";
            App_Durak_Tanim = "";
            App_Durak_Lat = "";
            App_Durak_Lng = "";
            App_Hat_Sec = "";
            App_Hat_No = "";
            App_Hat_Tanim = "";
            App_Adres_Sec = "";
            App_Adres_Map_Sec = "";
            App_Adres_Status = "";
            App_Adres_Adres = "";
            App_Adres_Ilce = "";
            App_Adres_Lat = "";
            App_Adres_Lng = "";
            App_Adres_Query = "";
            App_Konum = "";
            App_Konum_Adres = "";
            App_Konum_Ilce = "";
            App_Konum_Lat = "";
            App_Konum_Lng = "";
            App_Konum_Durak_No = "";
            App_Konum_Durak_Tanim = "";
            App_Otobus_No = "";
            App_Nereden_Adres = "";
            App_Nereden_Ilce = "";
            App_Nereden_Lat = "";
            App_Nereden_Lng = "";
            App_Nereye_Adres = "";
            App_Nereye_Ilce = "";
            App_Nereye_Lat = "";
            App_Nereye_Lng = "";
            App_OnemliYer_Tur = "";
            App_OnemliYer_Yer = "";
            App_OnemliYer_Lat = "";
            App_OnemliYer_Lng = "";
            App_Duyuru_Id = "";
            App_Sorun_Id = "";
            App_NasilGiderim = null;
            App_Alarm_Acik = false;
            return true;
        }
    }

}
