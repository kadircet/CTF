// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.ego.android:
//            Http, ListAdapterPnl, Tools, Global, 
//            PanelimDuzenle, HatBilgileri

public class Panelim extends Activity
{

    ProgressDialog dialog;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    ListAdapterPnl laPanel;
    ArrayList lstmapPanel;
    int lstmapPanelPosition;
    int lstmapPanelSize;
    boolean pageStatus;

    public Panelim()
    {
        pageStatus = true;
        handler = new Handler();
        handlerStatus = false;
        lstmapPanelSize = -1;
        lstmapPanelPosition = -1;
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        int j1;
        HashMap hashmap2;
        HashMap hashmap3;
        Exception exception1;
        int j;
        int k;
        int l;
        JSONArray jsonarray;
        String s3;
        HashMap hashmap;
        JSONObject jsonobject;
        ListView listview;
        HashMap hashmap1;
        int i1;
        Exception exception2;
        Exception exception3;
        String as[];
        String s4;
        String as1[];
        String s5;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        handlerStop();
        if (pageStatus) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if (i != 200) goto _L4; else goto _L3
_L3:
        if (!s.equals("Panel"))
        {
            continue; /* Loop/switch isn't completed */
        }
        listview = (ListView)findViewById(0x7f090065);
        lstmapPanel = new ArrayList();
        hashmap1 = new HashMap();
        lstmapPanelSize = -1;
        lstmapPanelPosition = -1;
        i1 = 0;
        (String[])null;
        j1 = 0;
        hashmap2 = hashmap1;
_L19:
        if (j1 < http.jArray.length()) goto _L6; else goto _L5
_L5:
        if (http.jArray.length() <= 0) goto _L8; else goto _L7
_L7:
        if (i1 != 1)
        {
            break MISSING_BLOCK_LABEL_235;
        }
        hashmap2.put("id2", "");
        hashmap2.put("no2", "");
        hashmap2.put("hat2", "");
        hashmap2.put("hattanim2", "");
        hashmap2.put("durak2", "");
        hashmap2.put("duraktanim2", "");
        hashmap2.put("title2", "");
        hashmap2.put("text2", "");
        hashmap2.put("text22", "");
        hashmap2.put("bgcolor2", "#00000000");
        hashmap2.put("btn2", "");
        if (i1 <= 0) goto _L8; else goto _L9
_L9:
        lstmapPanel.add(hashmap2);
        hashmap2;
_L16:
        laPanel = new ListAdapterPnl(this, lstmapPanel, 0x7f030024, new String[] {
            "title1", "text1", "title2", "text2"
        }, new int[] {
            0x7f090052, 0x7f090054, 0x7f090056, 0x7f090058
        }, Boolean.valueOf(true));
        listview.setAdapter(laPanel);
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final Panelim this$0;

            public void onItemClick(AdapterView adapterview, View view, int k1, long l1)
            {
            }

            
            {
                this$0 = Panelim.this;
                super();
            }
        });
        if (!s.equals("OtobusAra")) goto _L1; else goto _L10
_L10:
        try
        {
            j = lstmapPanelPosition;
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception1)
        {
            return;
        }
        if (j % 2 == 0)
        {
            k = 1;
        } else
        {
            k = 2;
        }
        l = j / 2;
        if (l < 0)
        {
            l = 0;
        }
        jsonarray = http.JArray(0, "otobus");
        if (jsonarray.length() <= 0) goto _L12; else goto _L11
_L11:
        jsonobject = jsonarray.getJSONObject(0);
        s3 = (new StringBuilder("T.V.S\374resi: ")).append(jsonobject.getString("sure")).toString();
_L17:
        hashmap = (HashMap)lstmapPanel.get(l);
        if (!((String)hashmap.get((new StringBuilder("bgcolor")).append(k).toString())).equals(Tools.ToColor("Pasif")))
        {
            hashmap.put((new StringBuilder("text")).append(k).toString(), (new StringBuilder(String.valueOf(((String)hashmap.get((new StringBuilder("text")).append(k).append(k).toString())).toString()))).append("\n\n").append(s3).toString());
            lstmapPanel.set(l, hashmap);
            laPanel.notifyDataSetChanged();
        }
        lstmapPanelPosition = 1 + lstmapPanelPosition;
        if (lstmapPanelPosition > lstmapPanelSize) goto _L1; else goto _L13
_L13:
        OtobusYenile(500);
        return;
_L6:
        lstmapPanelSize = 1 + lstmapPanelSize;
        if (j1 % 2 != 0) goto _L15; else goto _L14
_L14:
        hashmap3 = new HashMap();
_L18:
label0:
        {
            if (j1 % 2 != 0)
            {
                break label0;
            }
            i1 = 1;
            try
            {
                as1 = http.JValue(j1, "aciklama").replace("|", ";").split(";");
                if (as1[1].equals("false"))
                {
                    as1[0] = "Pasif";
                }
                hashmap3.put("id1", http.JValue(j1, "id"));
                hashmap3.put("no1", http.JValue(j1, "no"));
                hashmap3.put("hat1", http.JValue(j1, "hat"));
                hashmap3.put("hattanim1", http.JValue(j1, "hattanim"));
                hashmap3.put("durak1", http.JValue(j1, "durak"));
                hashmap3.put("duraktanim1", http.JValue(j1, "duraktanim"));
                hashmap3.put("title1", http.JValue(j1, "tanim"));
                s5 = (new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf("- Hat"))).append(" ").append(http.JValue(j1, "hat")).append("\n").toString()))).append(http.JValue(j1, "hattanim")).append("\n\n").toString()))).append("- Durak").toString()))).append(" ").append(http.JValue(j1, "durak")).append("\n").toString()))).append(http.JValue(j1, "duraktanim")).toString();
                hashmap3.put("text1", s5);
                hashmap3.put("text11", s5);
                hashmap3.put("bgcolor1", Tools.ToColor(as1[0]));
                hashmap3.put("btn1", (new StringBuilder(String.valueOf(http.JValue(j1, "no")))).append(";").append(j1).append(";").append(http.JValue(j1, "hattanim")).append(";").append(http.JValue(j1, "duraktanim")).toString());
                break MISSING_BLOCK_LABEL_1671;
            }
            // Misplaced declaration of an exception variable
            catch (Exception exception2) { }
        }
          goto _L16
        as = http.JValue(j1, "aciklama").replace("|", ";").split(";");
        if (as[1].equals("false"))
        {
            as[0] = "Pasif";
        }
        hashmap3.put("id2", http.JValue(j1, "id"));
        hashmap3.put("no2", http.JValue(j1, "no"));
        hashmap3.put("hat2", http.JValue(j1, "hat"));
        hashmap3.put("hattanim2", http.JValue(j1, "hattanim"));
        hashmap3.put("durak2", http.JValue(j1, "durak"));
        hashmap3.put("duraktanim2", http.JValue(j1, "duraktanim"));
        hashmap3.put("title2", http.JValue(j1, "tanim"));
        s4 = (new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf("- Hat"))).append(" ").append(http.JValue(j1, "hat")).append("\n").toString()))).append(http.JValue(j1, "hattanim")).append("\n\n").toString()))).append("- Durak").toString()))).append(" ").append(http.JValue(j1, "durak")).append("\n").toString()))).append(http.JValue(j1, "duraktanim")).toString();
        hashmap3.put("text2", s4);
        hashmap3.put("text22", s4);
        hashmap3.put("bgcolor2", Tools.ToColor(as[0]));
        hashmap3.put("btn2", (new StringBuilder(String.valueOf(http.JValue(j1, "no")))).append(";").append(j1).append(";").append(http.JValue(j1, "hattanim")).append(";").append(http.JValue(j1, "duraktanim")).toString());
        lstmapPanel.add(hashmap3);
        i1 = 0;
        break MISSING_BLOCK_LABEL_1671;
_L12:
        s3 = "\u015Eu Anda Otob\374s Yok!";
          goto _L17
_L4:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception3;
        hashmap2;
          goto _L16
_L8:
        hashmap2;
          goto _L16
_L15:
        hashmap3 = hashmap2;
          goto _L18
        j1++;
        hashmap2 = hashmap3;
          goto _L19
    }

    public void Ekle()
    {
        Global.App_Panel_Id = "";
        Global.App_Panel_No = "";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/PanelimDuzenle), 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        as = s.replace("|", ";").split(";");
        if (as.length <= 1)
        {
            break MISSING_BLOCK_LABEL_136;
        }
        if (as[0].equals("0"))
        {
            Ekle();
            return;
        }
        try
        {
            Global.App_Panel_Id = (new StringBuilder(String.valueOf(as[0]))).append("|").append(as[1]).toString();
            Global.App_Panel_No = (new StringBuilder(String.valueOf(as[0]))).append("|").append(as[1]).toString();
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/PanelimDuzenle), 0);
            return;
        }
        catch (Exception exception) { }
    }

    public void ListPanel_OnClick(View view)
    {
        String s = ((LinearLayout)view).getTag().toString();
        String as[];
        as = s.replace("|", ";").split(";");
        if (as.length <= 1)
        {
            break MISSING_BLOCK_LABEL_147;
        }
        if (as[0].equals("0"))
        {
            Ekle();
            return;
        }
        try
        {
            if (Global.App_Panel_Sec.equals("PanelSec"))
            {
                Global.App_Hat_No = as[0];
                Global.App_Hat_Tanim = as[3];
                Global.App_Durak_No = as[1];
                Global.App_Durak_Tanim = as[4];
                setResult(10, new Intent());
                finish();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Global.App_Hat_No = as[0];
        Global.App_Durak_No = as[1];
        Global.App_Otobus_No = "";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/HatBilgileri), 0);
    }

    public void OtobusYenile(int i)
    {
        handlerStop();
        handlerRunnable = new Runnable() {

            final Panelim this$0;

            public void run()
            {
                int j;
                int k;
                int l;
                String as[];
                Panelim panelim;
                String as1[];
                String as2[];
                try
                {
                    handler.removeCallbacks(handlerRunnable);
                }
                catch (Exception exception) { }
                if (!handlerStatus)
                {
                    break MISSING_BLOCK_LABEL_267;
                }
                handlerStatus = false;
                try
                {
                    j = lstmapPanelPosition;
                }
                catch (Exception exception1)
                {
                    return;
                }
                if (j % 2 == 0)
                {
                    k = 1;
                } else
                {
                    k = 2;
                }
                l = j / 2;
                if (l < 0)
                {
                    l = 0;
                }
                as = ((String)((HashMap)lstmapPanel.get(l)).get((new StringBuilder("no")).append(k).toString())).replace("|", ";").split(";");
                if (as.length >= 2)
                {
                    panelim = Panelim.this;
                    as1 = (new String[] {
                        "FNC", "OtobusAra"
                    });
                    as2 = new String[4];
                    as2[0] = "QUERY";
                    as2[1] = as[0];
                    as2[2] = "DURAK";
                    as2[3] = as[1];
                    panelim.http = new Http("OtobusAra", "hat.asp", as1, as2);
                    http.addObserver(new Http.Callback() {

                        final _cls2 this$1;

                        public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
                        {
                            Action(s, s1, i, boolean1, s2);
                        }

            
            {
                this$1 = _cls2.this;
                super();
            }
                    });
                    dialog.show();
                    http.execute(new String[0]);
                    return;
                }
                Toast.makeText(getBaseContext(), "Panelleriniz Olu\u015Fturulmam\u0131\u015F!", 1).show();
                return;
            }


            
            {
                this$0 = Panelim.this;
                super();
            }
        };
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, i);
    }

    public void PanelYenile()
    {
        String as[] = {
            "FNC", "FavoriAra"
        };
        String as1[] = new String[4];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        as1[2] = "TIP";
        as1[3] = "Panel";
        http = new Http("Panel", "favori.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final Panelim this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = Panelim.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void ToolBar_OnClick(View view)
    {
        String s;
        s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
            return;
        }
        if (s.equals("1"))
        {
            finish();
            return;
        }
        if (s.equals("2"))
        {
            Ekle();
            return;
        }
        if (!s.equals("3")) goto _L2; else goto _L1
_L1:
        int i;
        try
        {
            lstmapPanelPosition = 0;
        }
        catch (Exception exception)
        {
            Toast.makeText(getBaseContext(), "Panelleriniz Olu\u015Fturulmam\u0131\u015F!", 1).show();
            return;
        }
        i = 0;
_L3:
        if (i > lstmapPanelSize)
        {
            laPanel.notifyDataSetChanged();
            OtobusYenile(0);
            return;
        }
        int j = i;
        int k;
        int l;
        HashMap hashmap;
        if (j % 2 == 0)
        {
            k = 1;
        } else
        {
            k = 2;
        }
        l = j / 2;
        if (l < 0)
        {
            l = 0;
        }
        hashmap = (HashMap)lstmapPanel.get(l);
        hashmap.put((new StringBuilder("text")).append(k).toString(), ((String)hashmap.get((new StringBuilder("text")).append(k).append(k).toString())).toString());
        lstmapPanel.set(l, hashmap);
        i++;
        if (true) goto _L3; else goto _L2
_L2:
        s.equals("4");
        return;
    }

    public void handlerStop()
    {
        handlerStatus = false;
        try
        {
            handler.removeCallbacks(handlerRunnable);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        handlerStop();
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (!Global.App_Panel_Id.equals(""))
        {
            if (j == 10)
            {
                PanelYenile();
            }
            Global.App_Panel_Id = "";
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030030);
        dialog = Tools.Waiting(this);
        PanelYenile();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    public void onResume()
    {
        super.onResume();
        pageStatus = true;
    }

    protected void onStop()
    {
        pageStatus = false;
        handlerStop();
        super.onStop();
    }
}
