// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.widget.Toast;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class MapMarker extends ItemizedOverlay
{
    public static interface Callback
    {

        public abstract void onClick(String s, OverlayItem overlayitem);
    }


    private String Action;
    private Set callbacks;
    private Context markerContext;
    private ArrayList overlayItem;

    public MapMarker(Context context, String s, Drawable drawable, OverlayItem overlayitem)
    {
        super(boundCenterBottom(drawable));
        Action = "";
        overlayItem = new ArrayList();
        callbacks = new HashSet();
        Action = s;
        markerContext = context;
        overlayItem.add(overlayitem);
        setLastFocusedIndex(-1);
        populate();
    }

    public void addObserver(Callback callback)
    {
        callbacks.add(callback);
    }

    public void clear()
    {
        overlayItem.clear();
        setLastFocusedIndex(-1);
        populate();
    }

    protected OverlayItem createItem(int i)
    {
        return (OverlayItem)overlayItem.get(i);
    }

    public void draw(Canvas canvas, MapView mapview, boolean flag)
    {
        if (!flag)
        {
            super.draw(canvas, mapview, false);
        }
    }

    protected boolean onTap(int i)
    {
        OverlayItem overlayitem = (OverlayItem)overlayItem.get(i);
        if (overlayitem.getTitle().length() > 0)
        {
            if (!Action.equals(""))
            {
                Iterator iterator = callbacks.iterator();
                do
                {
                    if (!iterator.hasNext())
                    {
                        return true;
                    }
                    ((Callback)iterator.next()).onClick(Action, overlayitem);
                } while (true);
            } else
            {
                Toast.makeText(markerContext, (new StringBuilder(String.valueOf(overlayitem.getTitle()))).append(overlayitem.getSnippet()).toString(), 1).show();
                return true;
            }
        } else
        {
            return super.onTap(i);
        }
    }

    public boolean onTap(GeoPoint geopoint, MapView mapview)
    {
        return super.onTap(geopoint, mapview);
    }

    public int size()
    {
        return overlayItem.size();
    }
}
