// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            YakindakiDuraklar, Global, DuraktanGecenHatlar

class this._cls0
    implements android.widget.ngClickListener
{

    final YakindakiDuraklar this$0;

    public boolean onItemLongClick(AdapterView adapterview, View view, int i, long l)
    {
        HashMap hashmap = (HashMap)((ListView)findViewById(0x7f090033)).getItemAtPosition(i);
        Global.App_Favorilerim_Durak_No = (String)hashmap.get("no");
        Global.App_Favorilerim_Durak_Tanim = (String)hashmap.get("tanim");
        Intent intent = new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar);
        startActivityForResult(intent, 0);
        return true;
    }

    gClickListener()
    {
        this$0 = YakindakiDuraklar.this;
        super();
    }
}
