// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, Global, ListAdapter, Tools, 
//            AdresAra, FavorilerimHat, Gps, YakindakiHatlar, 
//            HatBilgileri

public class HatAra extends Activity
{

    ProgressDialog dialog;
    Gps gps;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;

    public HatAra()
    {
        handler = new Handler();
        handlerStatus = false;
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        ListView listview;
        ArrayList arraylist;
        HashMap hashmap;
        int j;
        HashMap hashmap1;
        Exception exception1;
        int k;
        HashMap hashmap2;
        Exception exception2;
        int l;
        Exception exception3;
        int i1;
        HashMap hashmap3;
        Exception exception4;
        int j1;
        String s3;
        String s4;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        listview = (ListView)findViewById(0x7f09002a);
        arraylist = new ArrayList();
        hashmap = new HashMap();
        if (!s.equals("FavoriAra")) goto _L4; else goto _L3
_L3:
        l = 0;
        Global.hatArray = http.jArray;
        i1 = 0;
        hashmap3 = hashmap;
_L11:
        j1 = http.jArray.length();
        if (i1 < j1) goto _L6; else goto _L5
_L5:
        hashmap = hashmap3;
_L14:
        if (l > 0)
        {
            Toast.makeText(getBaseContext(), "Favori Hatlar\u0131n\u0131z", 1).show();
        } else
        {
            http = new Http("HatAra", "hat.asp", new String[] {
                "FNC", "HatAraKodu"
            }, new String[] {
                "QUERY", "OTOB\334S"
            });
            http.addObserver(new Http.Callback() {

                final HatAra this$0;

                public void onComplete(String s5, String s6, int k1, Boolean boolean2, String s7)
                {
                    Action(s5, s6, k1, boolean2, s7);
                }

            
            {
                this$0 = HatAra.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
        }
_L4:
        if (!s.equals("HatAra")) goto _L8; else goto _L7
_L7:
        j = 0;
        hashmap1 = hashmap;
_L13:
        k = http.jArray.length();
        if (j < k) goto _L10; else goto _L9
_L9:
        hashmap1;
_L8:
        listview.setAdapter(new ListAdapter(this, arraylist, 0x7f03001a, new String[] {
            "no", "tanim", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048
        }, Boolean.valueOf(true)));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final HatAra this$0;

            public void onItemClick(AdapterView adapterview, View view, int k1, long l1)
            {
                Global.App_Hat_No = (String)((HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(k1)).get("no");
                Global.App_Durak_No = "";
                Global.App_Otobus_No = "";
                Intent intent = new Intent(getBaseContext(), com/ego/android/HatBilgileri);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = HatAra.this;
                super();
            }
        });
        return;
_L6:
        String as[] = http.JValue(i1, "aciklama").replace("|", ";").split(";");
        s3 = as[0];
        if (as.length <= 1)
        {
            break MISSING_BLOCK_LABEL_381;
        }
        s4 = as[1];
_L12:
        l++;
        hashmap = new HashMap();
        hashmap.put("id", (new StringBuilder()).append(i1).toString());
        hashmap.put("no", http.JValue(i1, "no"));
        hashmap.put("tanim", http.JValue(i1, "tanim"));
        hashmap.put("aciklama", s3);
        hashmap.put("bgcolor", Tools.ToColor(s4));
        arraylist.add(hashmap);
        i1++;
        hashmap3 = hashmap;
          goto _L11
        s4 = "";
          goto _L12
_L10:
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(j).toString());
        hashmap2.put("no", http.JValue(j, "kod"));
        hashmap2.put("tanim", http.JValue(j, "ad"));
        hashmap2.put("aciklama", http.JValue(j, "aciklama"));
        arraylist.add(hashmap2);
        j++;
        hashmap1 = hashmap2;
          goto _L13
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception1;
        hashmap1;
          goto _L8
        exception2;
          goto _L8
        exception3;
          goto _L14
        exception4;
        hashmap = hashmap3;
          goto _L14
    }

    public void AdresAra()
    {
        Global.App_Adres_Sec = "AdresAra";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/AdresAra), 0);
    }

    public void CloseKeyboard()
    {
        ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(0x7f090000).getWindowToken(), 0);
    }

    public void Favorilerim_OnClick(View view)
    {
        CloseKeyboard();
        Global.App_Hat_Sec = "Favorilerim";
        Global.App_Favorilerim_Hat_No = "";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimHat), 0);
    }

    public void ItemBar_OnClick(View view)
    {
        CloseKeyboard();
        String s = view.getTag().toString();
        http = new Http("HatAra", "hat.asp", new String[] {
            "FNC", "HatAraKodu"
        }, new String[] {
            "QUERY", s
        });
        http.addObserver(new Http.Callback() {

            final HatAra this$0;

            public void onComplete(String s1, String s2, int i, Boolean boolean1, String s3)
            {
                Action(s1, s2, i, boolean1, s3);
            }

            
            {
                this$0 = HatAra.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void Klavye_OnClick(View view)
    {
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        if (((TextView)findViewById(0x7f090039)).getText().equals("ABC  "))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090000).getWindowToken(), 0);
            ((TextView)findViewById(0x7f090039)).setText("123  ");
            ((EditText)findViewById(0x7f090000)).setInputType(4096);
            ((EditText)findViewById(0x7f090000)).requestFocus();
        } else
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090000).getWindowToken(), 0);
            ((TextView)findViewById(0x7f090039)).setText("ABC  ");
            ((EditText)findViewById(0x7f090000)).setInputType(3);
            ((EditText)findViewById(0x7f090000)).requestFocus();
        }
        inputmethodmanager.toggleSoftInput(2, 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void Location()
    {
        gps = new Gps(this);
        gps.addObserver(new Gps.Callback() {

            final HatAra this$0;

            public void onComplete(Location location)
            {
                Intent intent;
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location == null)
                {
                    try
                    {
                        Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                        return;
                    }
                    catch (Exception exception1)
                    {
                        return;
                    }
                }
                if (gps.GpsAdres.equals(""))
                {
                    Toast.makeText(getBaseContext(), "Adres Bulunamad\u0131!", 1).show();
                    return;
                }
                Global.App_Adres_Adres = gps.GpsAdres;
                Global.App_Adres_Ilce = gps.GpsIlce;
                Global.App_Adres_Lat = gps.GpsLat;
                Global.App_Adres_Lng = gps.GpsLng;
                Global.App_Adres_Query = "";
                intent = new Intent(getBaseContext(), com/ego/android/YakindakiHatlar);
                startActivityForResult(intent, 0);
                return;
            }

            
            {
                this$0 = HatAra.this;
                super();
            }
        });
        gps.Start();
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final HatAra this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = HatAra.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void Sorgula_OnClick(View view)
    {
        CloseKeyboard();
        String s = ((EditText)findViewById(0x7f090000)).getText().toString();
        if (s.length() >= 3)
        {
            Global.App_Hat_Ara = ((EditText)findViewById(0x7f090000)).getText().toString();
            Boolean boolean1 = Boolean.valueOf(((CheckBox)findViewById(0x7f090001)).isChecked());
            String as[] = {
                "FNC", "HatAra"
            };
            String as1[] = new String[4];
            as1[0] = "QUERY";
            as1[1] = s;
            as1[2] = "TYPE";
            as1[3] = boolean1.toString();
            http = new Http("HatAra", "hat.asp", as, as1);
            http.addObserver(new Http.Callback() {

                final HatAra this$0;

                public void onComplete(String s1, String s2, int i, Boolean boolean2, String s3)
                {
                    Action(s1, s2, i, boolean2, s3);
                }

            
            {
                this$0 = HatAra.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Hat No / Ad\u0131\nEn Az 3 Rakam veya Harf Olmal\u0131!", 1).show();
            return;
        }
    }

    public void ToolBar_OnClick(View view)
    {
        CloseKeyboard();
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
            return;
        }
        if (s.equals("1"))
        {
            finish();
            return;
        }
        if (s.equals("2"))
        {
            Runnable("Location");
            return;
        }
        if (s.equals("3"))
        {
            AdresAra();
            return;
        } else
        {
            s.equals("4");
            return;
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (Global.App_Hat_Sec.equals("Favorilerim"))
        {
            if (j == 10 && !Global.App_Favorilerim_Hat_No.equals(""))
            {
                ((EditText)findViewById(0x7f090000)).setText(Global.App_Favorilerim_Hat_No);
                Sorgula_OnClick(null);
            }
            Global.App_Hat_Sec = "";
            Global.App_Favorilerim_Hat_No = "";
        }
        if (Global.App_Adres_Sec.equals("AdresAra"))
        {
            if (j == 10 && !Global.App_Adres_Lat.equals("") && !Global.App_Adres_Lng.equals(""))
            {
                String as[] = {
                    "FNC", "YakinHatlar"
                };
                String as1[] = new String[6];
                as1[0] = "LAT";
                as1[1] = (new StringBuilder()).append(Global.App_Adres_Lat).toString();
                as1[2] = "LNG";
                as1[3] = (new StringBuilder()).append(Global.App_Adres_Lng).toString();
                as1[4] = "MESAFE";
                as1[5] = Global.Set_Yakinlik;
                http = new Http("HatAra", "hat.asp", as, as1);
                http.addObserver(new Http.Callback() {

                    final HatAra this$0;

                    public void onComplete(String s, String s1, int k, Boolean boolean1, String s2)
                    {
                        Action(s, s1, k, boolean1, s2);
                    }

            
            {
                this$0 = HatAra.this;
                super();
            }
                });
                dialog.show();
                http.execute(new String[0]);
            }
            Global.App_Adres_Sec = "";
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03000f);
        CloseKeyboard();
        dialog = Tools.Waiting(this);
        ((EditText)findViewById(0x7f090000)).setText(Global.App_Hat_Ara);
        if (Global.App_Hat_Ara.equals(""))
        {
            String as[] = {
                "FNC", "FavoriAra"
            };
            String as1[] = new String[4];
            as1[0] = "UID";
            as1[1] = Global.Device_ID;
            as1[2] = "TIP";
            as1[3] = "Hat";
            http = new Http("FavoriAra", "favori.asp", as, as1);
            http.addObserver(new Http.Callback() {

                final HatAra this$0;

                public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
                {
                    Action(s, s1, i, boolean1, s2);
                }

            
            {
                this$0 = HatAra.this;
                super();
            }
            });
            dialog.show();
            if (Global.hatArray == null)
            {
                http.execute(new String[0]);
                return;
            } else
            {
                http.jArray = Global.hatArray;
                Action("FavoriAra", null, 200, null, null);
                return;
            }
        } else
        {
            Sorgula_OnClick(null);
            return;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        CloseKeyboard();
        super.onStop();
    }
}
