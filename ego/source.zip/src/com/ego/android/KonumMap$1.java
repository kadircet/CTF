// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.graphics.Point;
import android.view.MotionEvent;
import android.view.View;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Projection;

// Referenced classes of package com.ego.android:
//            KonumMap, Tools

class this._cls0
    implements android.view.hListener
{

    final KonumMap this$0;

    public boolean onTouch(View view, MotionEvent motionevent)
    {
        if (motionevent.getAction() != 1) goto _L2; else goto _L1
_L1:
        if (lastTouchPositon == null) goto _L4; else goto _L3
_L3:
        com.google.android.maps.GeoPoint geopoint;
        int k;
        int l;
        geopoint = mv.getProjection().fromPixels((int)motionevent.getX(), (int)motionevent.getY());
        int i = (int)motionevent.getX() - lastTouchPositon.x;
        int j = (int)motionevent.getY() - lastTouchPositon.y;
        k = Math.abs(i);
        l = Math.abs(j);
        if (k > 10 || l > 10)
        {
            break MISSING_BLOCK_LABEL_277;
        }
        if (motionevent.getEventTime() - lastTouchTime < 250L || motionevent.getEventTime() - lastTouchTime > 1000L)
        {
            break MISSING_BLOCK_LABEL_287;
        }
        konumSlc = true;
        konumPositionSlc = geopoint;
        konumAdresSlc = "";
        konumIlceSlc = "";
        String as[] = Tools.GeoCoder(konumPositionSlc);
        if (!as[0].equals(""))
        {
            konumAdresSlc = as[0];
            konumIlceSlc = as[1];
        }
        Isaretle("Konum", konumPositionSlc, 0, "");
        lastTouchTime = -1L;
        lastTouchDoubleTime = -1L;
        lastTouchPositon = null;
        return true;
        try
        {
            lastTouchTime = -1L;
        }
        catch (Exception exception) { }
        lastTouchTime = -1L;
_L2:
        if (motionevent.getAction() != 0)
        {
            break MISSING_BLOCK_LABEL_445;
        }
        if (motionevent.getEventTime() - lastTouchDoubleTime < 250L)
        {
            mc.setZoom(1 + mv.getZoomLevel());
            mv.invalidate();
            lastTouchTime = -1L;
            lastTouchDoubleTime = -1L;
            lastTouchPositon = null;
            return true;
        }
        break; /* Loop/switch isn't completed */
_L4:
        lastTouchTime = -1L;
        if (true) goto _L2; else goto _L5
_L5:
        lastTouchPositon = new Point((int)motionevent.getX(), (int)motionevent.getY());
        lastTouchTime = motionevent.getEventTime();
        lastTouchDoubleTime = motionevent.getEventTime();
        return false;
    }

    Controller()
    {
        this$0 = KonumMap.this;
        super();
    }
}
