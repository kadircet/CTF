// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            Http, Global, Tools

public class FavorilerimHatDuzenle extends Activity
{

    String Favorilerim_Hat_No;
    ProgressDialog dialog;
    Http http;
    String renkArray[] = {
        "Saydam", "K\u0131rm\u0131z\u0131", "Mavi", "Ye\u015Fil", "Pembe", "Sar\u0131", "Turuncu", "Kahverengi", "A\347\u0131k K\u0131rm\u0131z\u0131", "A\347\u0131k Mavi", 
        "A\347\u0131k Ye\u015Fil", "A\347\u0131k Pembe", "A\347\u0131k Kahverengi"
    };

    public FavorilerimHatDuzenle()
    {
        Favorilerim_Hat_No = "";
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        String s3;
        String as[];
        int j;
        int k;
        int l;
        int i1;
        boolean flag;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("HatAra")) goto _L4; else goto _L3
_L3:
        if (http.JValue(0, "no").equals("")) goto _L6; else goto _L5
_L5:
        ((EditText)findViewById(0x7f090035)).setText(http.JValue(0, "no"));
        ((EditText)findViewById(0x7f090036)).setText(http.JValue(0, "tanim"));
_L4:
        if (!s.equals("Favori")) goto _L8; else goto _L7
_L7:
        if (http.JValue(0, "no").equals("")) goto _L10; else goto _L9
_L9:
        ((EditText)findViewById(0x7f090035)).setText(http.JValue(0, "no"));
        ((EditText)findViewById(0x7f090036)).setText(http.JValue(0, "tanim"));
        s3 = "";
        as = http.JValue(0, "aciklama").replace("|", ";").split(";");
        s3 = as[0];
        j = as.length;
        k = 0;
        if (j <= 1) goto _L12; else goto _L11
_L11:
        l = 0;
_L25:
        i1 = renkArray.length;
        k = 0;
        if (l < i1) goto _L13; else goto _L12
_L12:
        try
        {
            ((Spinner)findViewById(0x7f090038)).setSelection(k);
        }
        catch (Exception exception2) { }
        ((EditText)findViewById(0x7f090037)).setText(s3);
_L8:
        if (!s.equals("FavoriEkle")) goto _L15; else goto _L14
_L14:
        if (!http.JValue(0, "status").equals("true")) goto _L17; else goto _L16
_L16:
        Global.hatArray = null;
        Toast.makeText(getBaseContext(), "Hat Favorilerinize Eklendi.", 0).show();
        Global.App_Favorilerim_Hat_No = ((EditText)findViewById(0x7f090035)).getText().toString();
        Global.App_Favorilerim_Hat_Yenile = "true";
        finish();
_L15:
        if (!s.equals("FavoriDuzelt")) goto _L19; else goto _L18
_L18:
        if (!http.JValue(0, "status").equals("true")) goto _L21; else goto _L20
_L20:
        Global.hatArray = null;
        Toast.makeText(getBaseContext(), "Favori Hatt\u0131n\u0131z D\374zeltildi.", 0).show();
        Global.App_Favorilerim_Hat_No = ((EditText)findViewById(0x7f090035)).getText().toString();
        Global.App_Favorilerim_Hat_Yenile = "true";
        finish();
_L19:
        if (!s.equals("FavoriSil")) goto _L23; else goto _L22
_L22:
        if (http.JValue(0, "status").equals("true"))
        {
            Global.hatArray = null;
            Toast.makeText(getBaseContext(), "Favori Hatt\u0131n\u0131z Silindi.", 0).show();
            Global.App_Favorilerim_Hat_No = Favorilerim_Hat_No;
            Global.App_Favorilerim_Hat_Yenile = "true";
            finish();
            return;
        }
          goto _L24
_L6:
        try
        {
            Toast.makeText(getBaseContext(), "Hat Bulunamad\u0131!", 1).show();
        }
        catch (Exception exception1)
        {
            Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
            return;
        }
        continue; /* Loop/switch isn't completed */
_L13:
        flag = renkArray[l].equals(as[1]);
label0:
        {
            if (!flag)
            {
                break label0;
            }
            k = l;
        }
          goto _L12
        l++;
          goto _L25
_L10:
        Toast.makeText(getBaseContext(), "Hat Bulunamad\u0131!", 1).show();
          goto _L8
_L17:
label1:
        {
            if (http.JValue(0, "error").equals(""))
            {
                break label1;
            }
            Toast.makeText(getBaseContext(), http.JValue(0, "error"), 1).show();
        }
          goto _L15
        Toast.makeText(getBaseContext(), "Hat Favorilerinize Eklenemedi!", 1).show();
          goto _L15
_L21:
label2:
        {
            if (http.JValue(0, "error").equals(""))
            {
                break label2;
            }
            Toast.makeText(getBaseContext(), http.JValue(0, "error"), 1).show();
        }
          goto _L19
        Toast.makeText(getBaseContext(), "Favori Hatt\u0131n\u0131z D\374zeltilemedi!", 1).show();
          goto _L19
_L24:
        Toast.makeText(getBaseContext(), "Favori Hatt\u0131n\u0131z Silinemedi!", 1).show();
        return;
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
_L23:
        return;
        if (true) goto _L4; else goto _L26
_L26:
    }

    public void CloseKeyboard()
    {
        ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(0x7f090035).getWindowToken(), 0);
    }

    public void FavoriKaydet()
    {
        String s = ((EditText)findViewById(0x7f090035)).getText().toString();
        String s1 = ((EditText)findViewById(0x7f090036)).getText().toString();
        String s2 = ((EditText)findViewById(0x7f090037)).getText().toString();
        String s3 = ((Spinner)findViewById(0x7f090038)).getSelectedItem().toString();
        if (s.length() < 3)
        {
            Toast.makeText(getBaseContext(), "Hat Numaras\u0131\nEn Az 3 Basamakl\u0131 Say\u0131 Olmal\u0131!", 1).show();
            return;
        }
        if (s1.length() == 0)
        {
            Toast.makeText(getBaseContext(), "Hat Sorgulanmad\u0131!", 1).show();
            return;
        }
        if (Favorilerim_Hat_No.equals(""))
        {
            String as[] = {
                "FNC", "FavoriEkle"
            };
            String as1[] = new String[10];
            as1[0] = "UID";
            as1[1] = Global.Device_ID;
            as1[2] = "TIP";
            as1[3] = "Hat";
            as1[4] = "NO";
            as1[5] = s;
            as1[6] = "TANIM";
            as1[7] = s1;
            as1[8] = "ACIKLAMA";
            as1[9] = (new StringBuilder(String.valueOf(s2))).append("|").append(s3).toString();
            http = new Http("FavoriEkle", "favori.asp", as, as1);
            http.addObserver(new Http.Callback() {

                final FavorilerimHatDuzenle this$0;

                public void onComplete(String s4, String s5, int i, Boolean boolean1, String s6)
                {
                    Action(s4, s5, i, boolean1, s6);
                }

            
            {
                this$0 = FavorilerimHatDuzenle.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        } else
        {
            String as2[] = {
                "FNC", "FavoriDuzelt"
            };
            String as3[] = new String[12];
            as3[0] = "UID";
            as3[1] = Global.Device_ID;
            as3[2] = "TIP";
            as3[3] = "Hat";
            as3[4] = "ID";
            as3[5] = Favorilerim_Hat_No;
            as3[6] = "NO";
            as3[7] = s;
            as3[8] = "TANIM";
            as3[9] = s1;
            as3[10] = "ACIKLAMA";
            as3[11] = (new StringBuilder(String.valueOf(s2))).append("|").append(s3).toString();
            http = new Http("FavoriDuzelt", "favori.asp", as2, as3);
            http.addObserver(new Http.Callback() {

                final FavorilerimHatDuzenle this$0;

                public void onComplete(String s4, String s5, int i, Boolean boolean1, String s6)
                {
                    Action(s4, s5, i, boolean1, s6);
                }

            
            {
                this$0 = FavorilerimHatDuzenle.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        }
    }

    public void FavoriSil()
    {
        if (!Favorilerim_Hat_No.equals(""))
        {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("Favori Hat Sil");
            builder.setMessage((new StringBuilder(String.valueOf(Favorilerim_Hat_No))).append(" Nolu Favori Hatt\u0131n\u0131z\u0131\nSilmek \u0130stiyormusunuz?").toString());
            builder.setPositiveButton("Hay\u0131r", null);
            builder.setNeutralButton("Sil", new android.content.DialogInterface.OnClickListener() {

                final FavorilerimHatDuzenle this$0;

                public void onClick(DialogInterface dialoginterface, int i)
                {
                    FavorilerimHatDuzenle favorilerimhatduzenle = FavorilerimHatDuzenle.this;
                    String as[] = {
                        "FNC", "FavoriSil"
                    };
                    String as1[] = new String[6];
                    as1[0] = "UID";
                    as1[1] = Global.Device_ID;
                    as1[2] = "TIP";
                    as1[3] = "Hat";
                    as1[4] = "NO";
                    as1[5] = Favorilerim_Hat_No;
                    favorilerimhatduzenle.http = new Http("FavoriSil", "favori.asp", as, as1);
                    http.addObserver(new Http.Callback() {

                        final _cls5 this$1;

                        public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
                        {
                            Action(s, s1, i, boolean1, s2);
                        }

            
            {
                this$1 = _cls5.this;
                super();
            }
                    });
                    http.execute(new String[0]);
                }


            
            {
                this$0 = FavorilerimHatDuzenle.this;
                super();
            }
            });
            builder.show();
        }
    }

    public void FavoriSorgula()
    {
        String as[] = {
            "FNC", "Favori"
        };
        String as1[] = new String[6];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        as1[2] = "TIP";
        as1[3] = "Hat";
        as1[4] = "NO";
        as1[5] = Favorilerim_Hat_No;
        http = new Http("Favori", "favori.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final FavorilerimHatDuzenle this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = FavorilerimHatDuzenle.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void KlavyeX_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        if (s.equals("No"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090035).getWindowToken(), 0);
            ((EditText)findViewById(0x7f090035)).setText("");
            ((EditText)findViewById(0x7f090036)).setText("");
            ((EditText)findViewById(0x7f090035)).requestFocus();
        }
        if (s.equals("Aciklama"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090037).getWindowToken(), 0);
            ((EditText)findViewById(0x7f090037)).setText("");
            ((EditText)findViewById(0x7f090037)).requestFocus();
        }
        inputmethodmanager.toggleSoftInput(2, 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        try
        {
            String as[] = s.split(";");
            Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void Sorgula_OnClick(View view)
    {
        CloseKeyboard();
        String s = ((EditText)findViewById(0x7f090035)).getText().toString();
        if (s.length() >= 3)
        {
            ((EditText)findViewById(0x7f090036)).setText("");
            http = new Http("HatAra", "favori.asp", new String[] {
                "FNC", "HatAra"
            }, new String[] {
                "NO", s
            });
            http.addObserver(new Http.Callback() {

                final FavorilerimHatDuzenle this$0;

                public void onComplete(String s1, String s2, int i, Boolean boolean1, String s3)
                {
                    Action(s1, s2, i, boolean1, s3);
                }

            
            {
                this$0 = FavorilerimHatDuzenle.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Hat Numaras\u0131\nEn Az 3 Basamakl\u0131 Say\u0131 Olmal\u0131!", 1).show();
            return;
        }
    }

    public void ToolBar_OnClick(View view)
    {
        CloseKeyboard();
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
            return;
        }
        if (s.equals("1"))
        {
            finish();
            return;
        }
        if (s.equals("2"))
        {
            FavoriKaydet();
            return;
        }
        if (s.equals("3"))
        {
            FavoriSil();
            return;
        } else
        {
            s.equals("4");
            return;
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03000e);
        CloseKeyboard();
        dialog = Tools.Waiting(this);
        Spinner spinner = (Spinner)findViewById(0x7f090038);
        ArrayAdapter arrayadapter = new ArrayAdapter(this, 0x1090008, renkArray);
        arrayadapter.setDropDownViewResource(0x1090009);
        spinner.setAdapter(arrayadapter);
        if (Global.App_Favorilerim_Hat_Ekle.equals(""))
        {
            Favorilerim_Hat_No = Global.App_Favorilerim_Hat_No;
            if (!Favorilerim_Hat_No.equals(""))
            {
                FavoriSorgula();
            }
        }
        Global.App_Favorilerim_Hat_No = "";
        if (!Global.App_Favorilerim_Hat_Ekle.equals(""))
        {
            ((EditText)findViewById(0x7f090035)).setText(Global.App_Favorilerim_Hat_Ekle);
            Sorgula_OnClick(null);
        }
        Global.App_Favorilerim_Hat_Ekle = "";
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
        CloseKeyboard();
    }
}
