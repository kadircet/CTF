// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;


// Referenced classes of package com.ego.android:
//            OtobusNeredeMap

class this._cls0
    implements this._cls0
{

    final OtobusNeredeMap this$0;

    public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
    {
        Action(s, s1, i, boolean1, s2);
    }

    ()
    {
        this$0 = OtobusNeredeMap.this;
        super();
    }
}
