// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, ListAdapter, Global, KonumMap, 
//            Tools, DuraktanGecenHatlar, HatBilgileri, FavorilerimDurakDuzenle, 
//            OtobusNerede

public class YakindakiDurakVeHatlar extends Activity
{

    ProgressDialog dialog;
    Http httpDurak;
    Http httpHat;
    public TabHost tabhost;

    public YakindakiDurakVeHatlar()
    {
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        ListView listview;
        ArrayList arraylist;
        int j;
        HashMap hashmap1;
        Exception exception1;
        int k;
        HashMap hashmap2;
        Exception exception2;
        ListView listview1;
        ArrayList arraylist1;
        int l;
        HashMap hashmap4;
        Exception exception3;
        int i1;
        HashMap hashmap5;
        Exception exception4;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Durak")) goto _L4; else goto _L3
_L3:
        listview1 = (ListView)findViewById(0x7f090033);
        arraylist1 = new ArrayList();
        HashMap hashmap3 = new HashMap();
        l = 0;
        hashmap4 = hashmap3;
_L11:
        i1 = httpDurak.jArray.length();
        if (l < i1) goto _L6; else goto _L5
_L5:
        hashmap4;
_L14:
        listview1.setAdapter(new ListAdapter(this, arraylist1, 0x7f030017, new String[] {
            "no", "tanim", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048
        }));
        listview1.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final YakindakiDurakVeHatlar this$0;

            public void onItemClick(AdapterView adapterview, View view, int j1, long l1)
            {
                HashMap hashmap6 = (HashMap)((ListView)findViewById(0x7f090033)).getItemAtPosition(j1);
                Global.App_Favorilerim_Durak_No = (String)hashmap6.get("no");
                Global.App_Favorilerim_Durak_Tanim = (String)hashmap6.get("tanim");
                Intent intent = new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = YakindakiDurakVeHatlar.this;
                super();
            }
        });
        listview1.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final YakindakiDurakVeHatlar this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int j1, long l1)
            {
                HashMap hashmap6 = (HashMap)((ListView)findViewById(0x7f090033)).getItemAtPosition(j1);
                YakindakiDurakVeHatlar yakindakidurakvehatlar = YakindakiDurakVeHatlar.this;
                String s3 = (new StringBuilder("\nDurak ")).append((String)hashmap6.get("no")).append("\n").append((String)hashmap6.get("tanim")).append("\n").toString();
                String as[] = {
                    "Favorilerime Ekle", "Otob\374s Nerede ?"
                };
                String as1[] = new String[2];
                as1[0] = (String)hashmap6.get("no");
                as1[1] = "";
                yakindakidurakvehatlar.IslemMenu("Durak", "\u0130\u015Flem Men\374s\374", s3, as, as1);
                return true;
            }

            
            {
                this$0 = YakindakiDurakVeHatlar.this;
                super();
            }
        });
_L4:
        if (!s.equals("Hat")) goto _L8; else goto _L7
_L7:
        listview = (ListView)findViewById(0x7f09002a);
        arraylist = new ArrayList();
        HashMap hashmap = new HashMap();
        j = 0;
        hashmap1 = hashmap;
_L12:
        k = httpHat.jArray.length();
        if (j < k) goto _L10; else goto _L9
_L9:
        hashmap1;
_L13:
        listview.setAdapter(new ListAdapter(this, arraylist, 0x7f03001a, new String[] {
            "no", "tanim", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048
        }));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final YakindakiDurakVeHatlar this$0;

            public void onItemClick(AdapterView adapterview, View view, int j1, long l1)
            {
                Global.App_Hat_No = (String)((HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(j1)).get("no");
                Global.App_Durak_No = "";
                Global.App_Otobus_No = "";
                Intent intent = new Intent(getBaseContext(), com/ego/android/HatBilgileri);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = YakindakiDurakVeHatlar.this;
                super();
            }
        });
_L8:
        return;
_L6:
        hashmap5 = new HashMap();
        hashmap5.put("id", (new StringBuilder()).append(l).toString());
        hashmap5.put("no", httpDurak.JValue(l, "ad"));
        hashmap5.put("tanim", httpDurak.JValue(l, "yer"));
        hashmap5.put("aciklama", httpDurak.JValue(l, "aciklama"));
        arraylist1.add(hashmap5);
        l++;
        hashmap4 = hashmap5;
          goto _L11
_L10:
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(j).toString());
        hashmap2.put("no", httpHat.JValue(j, "kod"));
        hashmap2.put("tanim", httpHat.JValue(j, "ad"));
        hashmap2.put("aciklama", httpHat.JValue(j, "aciklama"));
        arraylist.add(hashmap2);
        j++;
        hashmap1 = hashmap2;
          goto _L12
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception1;
        hashmap1;
          goto _L13
        exception2;
          goto _L13
        exception3;
        hashmap4;
          goto _L14
        exception4;
          goto _L14
    }

    public void DurakYenile()
    {
        String as[] = {
            "FNC", "YakinDuraklar"
        };
        String as1[] = new String[8];
        as1[0] = "QUERY";
        as1[1] = "";
        as1[2] = "LAT";
        as1[3] = Global.App_Adres_Lat;
        as1[4] = "LNG";
        as1[5] = Global.App_Adres_Lng;
        as1[6] = "MESAFE";
        as1[7] = Global.Set_Yakinlik;
        httpDurak = new Http("Durak", "hat.asp", as, as1);
        httpDurak.addObserver(new Http.Callback() {

            final YakindakiDurakVeHatlar this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = YakindakiDurakVeHatlar.this;
                super();
            }
        });
        dialog.show();
        httpDurak.execute(new String[0]);
    }

    public void Harita()
    {
        Global.App_Konum = "Adres";
        Global.App_Konum_Adres = Global.App_Adres_Adres;
        Global.App_Konum_Ilce = Global.App_Adres_Ilce;
        Global.App_Konum_Lat = Global.App_Adres_Lat;
        Global.App_Konum_Lng = Global.App_Adres_Lng;
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/KonumMap), 0);
    }

    public void HatYenile()
    {
        String as[] = {
            "FNC", "YakinHatlar"
        };
        String as1[] = new String[8];
        as1[0] = "QUERY";
        as1[1] = "";
        as1[2] = "LAT";
        as1[3] = Global.App_Adres_Lat;
        as1[4] = "LNG";
        as1[5] = Global.App_Adres_Lng;
        as1[6] = "MESAFE";
        as1[7] = Global.Set_Yakinlik;
        httpHat = new Http("Hat", "hat.asp", as, as1);
        httpHat.addObserver(new Http.Callback() {

            final YakindakiDurakVeHatlar this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = YakindakiDurakVeHatlar.this;
                super();
            }
        });
        dialog.show();
        httpHat.execute(new String[0]);
    }

    public void IslemMenu(String s, String s1, String s2, String as[], String as1[])
    {
        final Dialog dialogBox = new Dialog(this);
        dialogBox.setTitle("\u0130\u015Flem Men\374s\374");
        dialogBox.requestWindowFeature(1);
        dialogBox.setContentView(0x7f030005);
        dialogBox.getWindow().setGravity(48);
        dialogBox.setCanceledOnTouchOutside(true);
        ((ImageView)dialogBox.findViewById(0x7f090020)).setOnClickListener(new android.view.View.OnClickListener() {

            final YakindakiDurakVeHatlar this$0;
            private final Dialog val$dialogBox;

            public void onClick(View view)
            {
                dialogBox.dismiss();
            }

            
            {
                this$0 = YakindakiDurakVeHatlar.this;
                dialogBox = dialog1;
                super();
            }
        });
        ((TextView)dialogBox.findViewById(0x7f09001f)).setText(s1);
        ((TextView)dialogBox.findViewById(0x7f090021)).setText(s2);
        int i = 0;
        do
        {
            if (i >= as.length)
            {
                dialogBox.show();
                return;
            }
            Button button = new Button(this);
            if (i == 0)
            {
                button = (Button)dialogBox.findViewById(0x7f090022);
            }
            if (i == 1)
            {
                button = (Button)dialogBox.findViewById(0x7f090023);
            }
            if (i == 2)
            {
                button = (Button)dialogBox.findViewById(0x7f090024);
            }
            if (i == 3)
            {
                button = (Button)dialogBox.findViewById(0x7f090025);
            }
            if (i == 4)
            {
                button = (Button)dialogBox.findViewById(0x7f090026);
            }
            if (i == 5)
            {
                button = (Button)dialogBox.findViewById(0x7f090027);
            }
            button.setOnClickListener(new android.view.View.OnClickListener() {

                final YakindakiDurakVeHatlar this$0;
                private final Dialog val$dialogBox;

                public void onClick(View view)
                {
                    String s3 = ((Button)view).getTag().toString();
                    dialogBox.dismiss();
                    try
                    {
                        String as2[] = s3.split(";");
                        if (as2[0].equals("Durak"))
                        {
                            if (as2[1].equals("0"))
                            {
                                Global.App_Favorilerim_Durak_Ekle = as2[2];
                                Intent intent1 = new Intent(getBaseContext(), com/ego/android/FavorilerimDurakDuzenle);
                                startActivityForResult(intent1, 0);
                            }
                            if (as2[1].equals("1"))
                            {
                                Global.App_Durak_No = as2[2];
                                Intent intent = new Intent(getBaseContext(), com/ego/android/OtobusNerede);
                                startActivityForResult(intent, 0);
                            }
                        }
                        return;
                    }
                    catch (Exception exception)
                    {
                        return;
                    }
                }

            
            {
                this$0 = YakindakiDurakVeHatlar.this;
                dialogBox = dialog1;
                super();
            }
            });
            button.setText(as[i]);
            button.setTag((new StringBuilder(String.valueOf(s))).append(";").append(i).append(";").append(as1[0]).append(";").append(as1[1]).toString());
            button.setVisibility(0);
            i++;
        } while (true);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Harita();
                return;
            }
            if (!s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030039);
        dialog = Tools.Waiting(this);
        tabhost = (TabHost)findViewById(0x7f090031);
        tabhost.setup();
        android.widget.TabHost.TabSpec tabspec = tabhost.newTabSpec("Tab1");
        tabspec.setIndicator("Duraklar", getResources().getDrawable(0x7f02002f));
        tabspec.setContent(0x7f090032);
        tabhost.addTab(tabspec);
        android.widget.TabHost.TabSpec tabspec1 = tabhost.newTabSpec("Tab2");
        tabspec1.setIndicator("Hatlar", getResources().getDrawable(0x7f020037));
        tabspec1.setContent(0x7f090034);
        tabhost.addTab(tabspec1);
        tabhost.setCurrentTab(0);
        tabhost.getTabWidget().getChildAt(0).setOnClickListener(new android.view.View.OnClickListener() {

            final YakindakiDurakVeHatlar this$0;

            public void onClick(View view)
            {
                tabhost.setCurrentTab(0);
            }

            
            {
                this$0 = YakindakiDurakVeHatlar.this;
                super();
            }
        });
        tabhost.getTabWidget().getChildAt(1).setOnClickListener(new android.view.View.OnClickListener() {

            final YakindakiDurakVeHatlar this$0;

            public void onClick(View view)
            {
                tabhost.setCurrentTab(1);
            }

            
            {
                this$0 = YakindakiDurakVeHatlar.this;
                super();
            }
        });
        ((TextView)findViewById(0x7f09006f)).setText(Global.App_Adres_Adres);
        ((TextView)findViewById(0x7f090070)).setText(Global.App_Adres_Ilce);
        DurakYenile();
        HatYenile();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
