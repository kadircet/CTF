// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import com.google.android.maps.GeoPoint;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, ListAdapter, Gps, Tools, 
//            Map, Global, OnemliYerlerDetay

public class OnemliYerler extends Activity
{

    String Lat;
    String Lng;
    String Yer;
    ProgressDialog dialog;
    Gps gps;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    boolean location;
    String locationAdres;
    String locationIlce;
    GeoPoint locationPosition;

    public OnemliYerler()
    {
        location = false;
        locationAdres = "";
        locationIlce = "";
        handler = new Handler();
        handlerStatus = false;
        Yer = "";
        Lat = "";
        Lng = "";
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        ListView listview;
        ArrayList arraylist;
        int j;
        HashMap hashmap1;
        Exception exception1;
        int k;
        HashMap hashmap2;
        Exception exception2;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Ara")) goto _L4; else goto _L3
_L3:
        listview = (ListView)findViewById(0x7f090062);
        arraylist = new ArrayList();
        HashMap hashmap = new HashMap();
        j = 0;
        hashmap1 = hashmap;
_L7:
        k = http.jArray.length();
        if (j < k) goto _L6; else goto _L5
_L5:
        hashmap1;
_L8:
        listview.setAdapter(new ListAdapter(this, arraylist, 0x7f030020, new String[] {
            "tur", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046
        }));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final OnemliYerler this$0;

            public void onItemClick(AdapterView adapterview, View view, int l, long l1)
            {
                Global.App_OnemliYer_Tur = (String)((HashMap)((ListView)findViewById(0x7f090062)).getItemAtPosition(l)).get("tur");
                Global.App_OnemliYer_Yer = Yer;
                Global.App_OnemliYer_Lat = Lat;
                Global.App_OnemliYer_Lng = Lng;
                Intent intent = new Intent(getBaseContext(), com/ego/android/OnemliYerlerDetay);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = OnemliYerler.this;
                super();
            }
        });
_L4:
        return;
_L6:
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(j).toString());
        hashmap2.put("tur", http.JValue(j, "tur"));
        hashmap2.put("aciklama", http.JValue(j, "aciklama"));
        arraylist.add(hashmap2);
        j++;
        hashmap1 = hashmap2;
          goto _L7
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception1;
        hashmap1;
          goto _L8
        exception2;
          goto _L8
    }

    public void CloseKeyboard()
    {
        ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(0x7f090000).getWindowToken(), 0);
    }

    public void KlavyeX_OnClick(View view)
    {
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090000).getWindowToken(), 0);
        ((EditText)findViewById(0x7f090000)).setText("");
        ((EditText)findViewById(0x7f090000)).requestFocus();
        inputmethodmanager.toggleSoftInput(2, 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void Location()
    {
        gps = new Gps(this);
        gps.addObserver(new Gps.Callback() {

            final OnemliYerler this$0;

            public void onComplete(Location location1)
            {
                OnemliYerler onemliyerler;
                String as[];
                String as1[];
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location1 == null)
                {
                    try
                    {
                        Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                        return;
                    }
                    catch (Exception exception1)
                    {
                        return;
                    }
                }
                if (gps.GpsAdres.equals(""))
                {
                    Toast.makeText(getBaseContext(), "Adres Bulunamad\u0131!", 1).show();
                    return;
                }
                location = true;
                locationPosition = Map.GP((new StringBuilder()).append(location1.getLatitude()).toString(), (new StringBuilder()).append(location1.getLongitude()).toString());
                locationAdres = gps.GpsAdres;
                locationIlce = gps.GpsIlce;
                Yer = ((EditText)findViewById(0x7f090000)).getText().toString();
                Lat = (new StringBuilder()).append(location1.getLatitude()).toString();
                Lng = (new StringBuilder()).append(location1.getLongitude()).toString();
                Toast.makeText(getBaseContext(), (new StringBuilder("Konumum\n\n")).append(locationAdres).append("\n").append(locationIlce).append("\n\nYak\u0131nl\u0131k 1000 Metre").toString(), 1).show();
                onemliyerler = OnemliYerler.this;
                as = (new String[] {
                    "FNC", "TurAra"
                });
                as1 = new String[6];
                as1[0] = "YER";
                as1[1] = Yer;
                as1[2] = "LAT";
                as1[3] = Lat;
                as1[4] = "LNG";
                as1[5] = Lng;
                onemliyerler.http = new Http("Ara", "onemliyerler.asp", as, as1);
                http.addObserver(new Http.Callback() {

                    final _cls3 this$1;

                    public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
                    {
                        Action(s, s1, i, boolean1, s2);
                    }

            
            {
                this$1 = _cls3.this;
                super();
            }
                });
                dialog.show();
                http.execute(new String[0]);
                return;
            }


            
            {
                this$0 = OnemliYerler.this;
                super();
            }
        });
        gps.Start();
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final OnemliYerler this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = OnemliYerler.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void Sorgula_OnClick(View view)
    {
        CloseKeyboard();
        Yer = ((EditText)findViewById(0x7f090000)).getText().toString();
        Lat = "";
        Lng = "";
        String as[] = {
            "FNC", "TurAra"
        };
        String as1[] = new String[2];
        as1[0] = "YER";
        as1[1] = Yer;
        http = new Http("Ara", "onemliyerler.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final OnemliYerler this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = OnemliYerler.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void ToolBar_OnClick(View view)
    {
        CloseKeyboard();
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Runnable("Location");
                return;
            }
            if (!s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03002c);
        CloseKeyboard();
        dialog = Tools.Waiting(this);
        Sorgula_OnClick(null);
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        CloseKeyboard();
        super.onStop();
    }
}
