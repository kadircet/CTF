// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Http, Geo, Global, FavorilerimDurak, 
//            ListAdapterBtn, AdresMap, KonumMap, Gps, 
//            Tools, YakindakiDuraklar, YakindakiDurakVeHatlar

public class AdresAra extends Activity
{

    boolean FavoriSec;
    ProgressDialog dialog;
    Geo geo;
    Gps gps;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;

    public AdresAra()
    {
        handler = new Handler();
        handlerStatus = false;
        FavoriSec = false;
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
label0:
        {
label1:
            {
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (i != 200)
                {
                    break label0;
                }
                if (s.equals("DurakAra"))
                {
                    if (http.JValue(0, "no").equals(""))
                    {
                        break label1;
                    }
                    geo = new Geo("DurakAra");
                    geo.addObserver(new Geo.Callback() {

                        final AdresAra this$0;

                        public void onComplete(String s3, ArrayList arraylist)
                        {
                            GeoAction(s3, arraylist);
                        }

            
            {
                this$0 = AdresAra.this;
                super();
            }
                    });
                    dialog.show();
                    Global.App_Durak_Lat = (new StringBuilder()).append(http.JValue(0, "lat")).toString();
                    Global.App_Durak_Lng = (new StringBuilder()).append(http.JValue(0, "lng")).toString();
                    geo.LatLng((new StringBuilder()).append(http.JValue(0, "lat")).toString(), (new StringBuilder()).append(http.JValue(0, "lng")).toString());
                }
                return;
            }
            Toast.makeText(getBaseContext(), "Durak Bulunamad\u0131!", 1).show();
            return;
        }
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
    }

    public void CloseKeyboard()
    {
        ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(0x7f090000).getWindowToken(), 0);
    }

    public void Favorilerim()
    {
        CloseKeyboard();
        FavoriSec = true;
        Global.App_Durak_Sec = "Favorilerim";
        Global.App_Favorilerim_Durak_No = "";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimDurak), 0);
    }

    public void GeoAction(String s, ArrayList arraylist)
    {
        ListView listview;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (arraylist == null)
        {
            Toast.makeText(getBaseContext(), "Adres Bulunamad\u0131!", 1).show();
            return;
        }
        if (!((EditText)findViewById(0x7f090000)).getText().toString().equals(""))
        {
            Global.App_Adres_Ara = ((EditText)findViewById(0x7f090000)).getText().toString();
        }
        if (s.equals("DurakAra"))
        {
            try
            {
                HashMap hashmap = (HashMap)arraylist.get(0);
                Global.App_Adres_Adres = (String)hashmap.get("adres");
                Global.App_Adres_Ilce = (String)hashmap.get("ilce");
                Global.App_Adres_Lat = Global.App_Durak_Lat;
                Global.App_Adres_Lng = Global.App_Durak_Lng;
                if (!Global.App_Adres_Status.equals("Menu"))
                {
                    setResult(10, new Intent());
                    finish();
                }
            }
            catch (Exception exception1) { }
        }
        listview = (ListView)findViewById(0x7f090002);
        listview.setAdapter(new ListAdapterBtn(this, arraylist, 0x7f030015, new String[] {
            "adres", "ilce", "id"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090047
        }));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final AdresAra this$0;

            public void onItemClick(AdapterView adapterview, View view, int i, long l)
            {
                HashMap hashmap1 = (HashMap)((ListView)findViewById(0x7f090002)).getItemAtPosition(i);
                Global.App_Adres_Adres = (String)hashmap1.get("adres");
                Global.App_Adres_Ilce = (String)hashmap1.get("ilce");
                Global.App_Adres_Lat = (String)hashmap1.get("lat");
                Global.App_Adres_Lng = (String)hashmap1.get("lng");
                Boolean boolean1 = Boolean.valueOf(((CheckBox)findViewById(0x7f090001)).isChecked());
                if (Global.App_Adres_Sec.equals("AdresAra") && !Global.App_Adres_Status.equals("Menu"))
                {
                    Intent intent2 = new Intent();
                    setResult(10, intent2);
                    finish();
                    return;
                }
                if (boolean1.booleanValue())
                {
                    Global.App_Adres_Query = Global.App_Adres_Ara;
                    Intent intent1 = new Intent(getBaseContext(), com/ego/android/YakindakiDuraklar);
                    startActivityForResult(intent1, 0);
                    return;
                } else
                {
                    Global.App_Adres_Query = "";
                    Intent intent = new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar);
                    startActivityForResult(intent, 0);
                    return;
                }
            }

            
            {
                this$0 = AdresAra.this;
                super();
            }
        });
        listview.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {

            final AdresAra this$0;

            public boolean onItemLongClick(AdapterView adapterview, View view, int i, long l)
            {
                HashMap hashmap1 = (HashMap)((ListView)findViewById(0x7f090002)).getItemAtPosition(i);
                Global.App_Konum = "Adres";
                Global.App_Konum_Adres = (String)hashmap1.get("adres");
                Global.App_Konum_Ilce = (String)hashmap1.get("ilce");
                Global.App_Konum_Lat = (String)hashmap1.get("lat");
                Global.App_Konum_Lng = (String)hashmap1.get("lng");
                Intent intent = new Intent(getBaseContext(), com/ego/android/KonumMap);
                startActivityForResult(intent, 0);
                return true;
            }

            
            {
                this$0 = AdresAra.this;
                super();
            }
        });
    }

    public void Harita()
    {
        Global.App_Konum = "Adres";
        Global.App_Konum_Adres = "";
        Global.App_Konum_Ilce = "";
        Global.App_Konum_Lat = (new StringBuilder()).append(Global.App_Merkez_Lat).toString();
        Global.App_Konum_Lng = (new StringBuilder()).append(Global.App_Merkez_Lng).toString();
        ListView listview = (ListView)findViewById(0x7f090002);
        if (listview.getCount() > 0)
        {
            HashMap hashmap = (HashMap)listview.getItemAtPosition(0);
            Global.App_Konum = "Adres";
            Global.App_Konum_Adres = (String)hashmap.get("adres");
            Global.App_Konum_Ilce = (String)hashmap.get("ilce");
            Global.App_Konum_Lat = (String)hashmap.get("lat");
            Global.App_Konum_Lng = (String)hashmap.get("lng");
        }
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/AdresMap), 0);
    }

    public void KlavyeX_OnClick(View view)
    {
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090000).getWindowToken(), 0);
        ((EditText)findViewById(0x7f090000)).setText("");
        ((EditText)findViewById(0x7f090000)).requestFocus();
        inputmethodmanager.toggleSoftInput(2, 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        try
        {
            String as[] = s.split(";");
            HashMap hashmap = (HashMap)((ListView)findViewById(0x7f090002)).getItemAtPosition(Integer.parseInt(as[0]));
            Global.App_Konum = "Adres";
            Global.App_Konum_Adres = (String)hashmap.get("adres");
            Global.App_Konum_Ilce = (String)hashmap.get("ilce");
            Global.App_Konum_Lat = (String)hashmap.get("lat");
            Global.App_Konum_Lng = (String)hashmap.get("lng");
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/KonumMap), 0);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void Location()
    {
        ((EditText)findViewById(0x7f090000)).setText("");
        gps = new Gps(this);
        gps.addObserver(new Gps.Callback() {

            final AdresAra this$0;

            public void onComplete(Location location)
            {
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location == null)
                {
                    try
                    {
                        Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                        return;
                    }
                    catch (Exception exception1)
                    {
                        return;
                    }
                }
                geo = new Geo("Location");
                geo.addObserver(new Geo.Callback() {

                    final _cls5 this$1;

                    public void onComplete(String s, ArrayList arraylist)
                    {
                        GeoAction(s, arraylist);
                    }

            
            {
                this$1 = _cls5.this;
                super();
            }
                });
                dialog.show();
                geo.LatLng((new StringBuilder()).append(location.getLatitude()).toString(), (new StringBuilder()).append(location.getLongitude()).toString());
                return;
            }


            
            {
                this$0 = AdresAra.this;
                super();
            }
        });
        gps.Start();
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final AdresAra this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = AdresAra.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void Sorgula_OnClick(View view)
    {
        CloseKeyboard();
        String s = ((EditText)findViewById(0x7f090000)).getText().toString();
        if (s.length() >= 3)
        {
            geo = new Geo();
            geo.addObserver(new Geo.Callback() {

                final AdresAra this$0;

                public void onComplete(String s1, ArrayList arraylist)
                {
                    GeoAction(s1, arraylist);
                }

            
            {
                this$0 = AdresAra.this;
                super();
            }
            });
            dialog.show();
            geo.Address(s);
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Adres / Yer\nEn Az 3 Harf Olmal\u0131!", 1).show();
            return;
        }
    }

    public void ToolBar_OnClick(View view)
    {
        CloseKeyboard();
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Favorilerim();
                return;
            }
            if (s.equals("3"))
            {
                Runnable("Location");
                return;
            }
            if (s.equals("4"))
            {
                Harita();
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (j == 10)
        {
            if (Global.App_Adres_Map_Sec.equals("AdresSec"))
            {
                Global.App_Adres_Map_Sec = "";
                geo = new Geo();
                geo.addObserver(new Geo.Callback() {

                    final AdresAra this$0;

                    public void onComplete(String s, ArrayList arraylist)
                    {
                        GeoAction(s, arraylist);
                    }

            
            {
                this$0 = AdresAra.this;
                super();
            }
                });
                dialog.show();
                geo.LatLng(Global.App_Adres_Lat, Global.App_Adres_Lng);
                ((EditText)findViewById(0x7f090000)).setText("");
            }
            if (!Global.App_Adres_Status.equals("Menu") && Global.App_Adres_Sec.equals("DurakAra") && !Global.App_Durak_No.equals(""))
            {
                setResult(10, new Intent());
                finish();
            }
        }
        if (FavoriSec && Global.App_Durak_Sec.equals("Favorilerim"))
        {
            if (j == 10 && !Global.App_Favorilerim_Durak_No.equals(""))
            {
                String as[] = {
                    "FNC", "DurakAra"
                };
                String as1[] = new String[2];
                as1[0] = "NO";
                as1[1] = Global.App_Favorilerim_Durak_No;
                http = new Http("DurakAra", "favori.asp", as, as1);
                http.addObserver(new Http.Callback() {

                    final AdresAra this$0;

                    public void onComplete(String s, String s1, int k, Boolean boolean1, String s2)
                    {
                        Action(s, s1, k, boolean1, s2);
                    }

            
            {
                this$0 = AdresAra.this;
                super();
            }
                });
                http.execute(new String[0]);
            }
            Global.App_Durak_Sec = "";
            Global.App_Favorilerim_Durak_No = "";
        }
        FavoriSec = false;
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030000);
        CloseKeyboard();
        dialog = Tools.Waiting(this);
        ((EditText)findViewById(0x7f090000)).setText(Global.App_Adres_Ara);
        Global.App_Adres_Adres = "";
        Global.App_Adres_Ilce = "";
        Global.App_Adres_Lat = "";
        Global.App_Adres_Lng = "";
        if (Global.App_Adres_Sec.equals("DurakAra"))
        {
            ((CheckBox)findViewById(0x7f090001)).setChecked(true);
            ((CheckBox)findViewById(0x7f090001)).setEnabled(false);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        CloseKeyboard();
        super.onStop();
    }
}
