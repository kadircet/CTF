// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            Http, Global, AdresAra, HatDuraklar, 
//            DuraktanGecenHatlar, FavorilerimHat, FavorilerimDurak, Tools

public class PanelimDuzenle extends Activity
{

    String Panel_Id;
    String Panel_New_No;
    String Panel_No;
    ProgressDialog dialog;
    Http http;
    String renkArray[] = {
        "K\u0131rm\u0131z\u0131", "Mavi", "Ye\u015Fil", "Pembe", "Sar\u0131", "Turuncu", "Kahverengi", "A\347\u0131k K\u0131rm\u0131z\u0131", "A\347\u0131k Mavi", "A\347\u0131k Ye\u015Fil", 
        "A\347\u0131k Pembe", "A\347\u0131k Kahverengi"
    };

    public PanelimDuzenle()
    {
        Panel_Id = "";
        Panel_No = "";
        Panel_New_No = "";
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        String as[];
        int j;
        int k;
        int l;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("HatAra")) goto _L4; else goto _L3
_L3:
        if (http.JValue(0, "no").equals("")) goto _L6; else goto _L5
_L5:
        ((EditText)findViewById(0x7f090007)).setText(http.JValue(0, "no"));
        ((TextView)findViewById(0x7f090008)).setText(http.JValue(0, "tanim"));
_L4:
        if (!s.equals("DurakAra")) goto _L8; else goto _L7
_L7:
        if (http.JValue(0, "no").equals("")) goto _L10; else goto _L9
_L9:
        ((EditText)findViewById(0x7f090009)).setText(http.JValue(0, "no"));
        ((TextView)findViewById(0x7f09000a)).setText(http.JValue(0, "tanim"));
_L8:
        if (!s.equals("Panel")) goto _L12; else goto _L11
_L11:
        if (http.JValue(0, "no").equals("")) goto _L14; else goto _L13
_L13:
        Panel_No = http.JValue(0, "no");
        ((EditText)findViewById(0x7f09002e)).setText(http.JValue(0, "tanim"));
        ((EditText)findViewById(0x7f090007)).setText(http.JValue(0, "hat"));
        ((TextView)findViewById(0x7f090008)).setText(http.JValue(0, "hattanim"));
        ((EditText)findViewById(0x7f090009)).setText(http.JValue(0, "durak"));
        ((TextView)findViewById(0x7f09000a)).setText(http.JValue(0, "duraktanim"));
        as = http.JValue(0, "aciklama").replace("|", ";").split(";");
        j = 0;
_L30:
        k = renkArray.length;
        l = 0;
        if (j < k) goto _L16; else goto _L15
_L15:
        ((Spinner)findViewById(0x7f090038)).setSelection(l);
        if (!as[1].equals("true")) goto _L18; else goto _L17
_L17:
        ((CheckBox)findViewById(0x7f090066)).setChecked(true);
_L12:
        if (!s.equals("PanelEkle")) goto _L20; else goto _L19
_L19:
        if (!http.JValue(0, "status").equals("true")) goto _L22; else goto _L21
_L21:
        Toast.makeText(getBaseContext(), "Panel Eklendi.", 0).show();
        Global.App_Panel_Id = Panel_New_No;
        Global.App_Panel_No = Panel_New_No;
        setResult(10, new Intent());
        finish();
_L20:
        if (!s.equals("PanelDuzelt")) goto _L24; else goto _L23
_L23:
        if (!http.JValue(0, "status").equals("true")) goto _L26; else goto _L25
_L25:
        Toast.makeText(getBaseContext(), "Panel D\374zeltildi.", 0).show();
        Global.App_Panel_Id = Panel_New_No;
        Global.App_Panel_No = Panel_New_No;
        setResult(10, new Intent());
        finish();
_L24:
        if (!s.equals("PanelSil")) goto _L28; else goto _L27
_L27:
        if (http.JValue(0, "status").equals("true"))
        {
            Toast.makeText(getBaseContext(), "Panel Silindi.", 0).show();
            Global.App_Panel_Id = Panel_Id;
            Global.App_Panel_No = Panel_No;
            setResult(10, new Intent());
            finish();
            return;
        }
          goto _L29
_L6:
        try
        {
            Toast.makeText(getBaseContext(), "Hat Bulunamad\u0131!", 1).show();
        }
        catch (Exception exception1)
        {
            Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
            return;
        }
          goto _L4
_L10:
        Toast.makeText(getBaseContext(), "Durak Bulunamad\u0131!", 1).show();
          goto _L8
_L16:
        if (!renkArray[j].equals(as[0]))
        {
            break MISSING_BLOCK_LABEL_867;
        }
        l = j;
          goto _L15
_L18:
        try
        {
            ((CheckBox)findViewById(0x7f090066)).setChecked(false);
        }
        catch (Exception exception2) { }
          goto _L12
_L14:
        Toast.makeText(getBaseContext(), "Panel Bulunamad\u0131!", 1).show();
        finish();
          goto _L12
_L22:
label0:
        {
            if (http.JValue(0, "error").equals(""))
            {
                break label0;
            }
            Toast.makeText(getBaseContext(), http.JValue(0, "error"), 1).show();
        }
          goto _L20
        Toast.makeText(getBaseContext(), "Panel Eklenemedi!", 1).show();
          goto _L20
_L26:
label1:
        {
            if (http.JValue(0, "error").equals(""))
            {
                break label1;
            }
            Toast.makeText(getBaseContext(), http.JValue(0, "error"), 1).show();
        }
          goto _L24
        Toast.makeText(getBaseContext(), "Panel D\374zeltilemedi!", 1).show();
          goto _L24
_L29:
        Toast.makeText(getBaseContext(), "Panel Silinemedi!", 1).show();
        return;
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
_L28:
        return;
        j++;
          goto _L30
    }

    public void CloseKeyboard()
    {
        ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(0x7f09002e).getWindowToken(), 0);
    }

    public void DurakAra()
    {
        Global.App_Adres_Sec = "DurakAra";
        Global.App_Durak_No = "";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/AdresAra), 0);
    }

    public void FavoriDurakSorgula()
    {
        String s = ((EditText)findViewById(0x7f090009)).getText().toString();
        if (s.length() == 5)
        {
            ((TextView)findViewById(0x7f09000a)).setText("");
            http = new Http("DurakAra", "favori.asp", new String[] {
                "FNC", "DurakAra"
            }, new String[] {
                "NO", s
            });
            http.addObserver(new Http.Callback() {

                final PanelimDuzenle this$0;

                public void onComplete(String s3, String s4, int i, Boolean boolean1, String s5)
                {
                    Action(s3, s4, i, boolean1, s5);
                }

            
            {
                this$0 = PanelimDuzenle.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        }
        String s1 = ((EditText)findViewById(0x7f090007)).getText().toString();
        String s2 = ((TextView)findViewById(0x7f090008)).getText().toString();
        if (s1.length() >= 3)
        {
            Global.App_Adres_Sec = "";
            Global.App_Hat_No = s1;
            Global.App_Hat_Tanim = s2;
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/HatDuraklar), 0);
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Durak Numaras\u0131\n5 Basamakl\u0131 Say\u0131 Olmal\u0131!", 1).show();
            return;
        }
    }

    public void FavoriHatSorgula()
    {
        String s = ((EditText)findViewById(0x7f090007)).getText().toString();
        if (s.length() >= 3)
        {
            ((TextView)findViewById(0x7f090008)).setText("");
            http = new Http("HatAra", "favori.asp", new String[] {
                "FNC", "HatAra"
            }, new String[] {
                "NO", s
            });
            http.addObserver(new Http.Callback() {

                final PanelimDuzenle this$0;

                public void onComplete(String s3, String s4, int i, Boolean boolean1, String s5)
                {
                    Action(s3, s4, i, boolean1, s5);
                }

            
            {
                this$0 = PanelimDuzenle.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        }
        String s1 = ((EditText)findViewById(0x7f090009)).getText().toString();
        String s2 = ((TextView)findViewById(0x7f09000a)).getText().toString();
        if (s1.length() == 5)
        {
            Global.App_Adres_Sec = "HatAra";
            Global.App_Favorilerim_Durak_No = s1;
            Global.App_Favorilerim_Durak_Tanim = s2;
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar), 0);
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Hat Numaras\u0131\nEn Az 3 Basamakl\u0131 Say\u0131 Olmal\u0131!", 1).show();
            return;
        }
    }

    public void Favorilerim_OnClick(View view)
    {
        CloseKeyboard();
        String s = ((ImageButton)view).getTag().toString();
        if (s.equals("Hat"))
        {
            Global.App_Hat_Sec = "Favorilerim";
            Global.App_Favorilerim_Hat_No = "";
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimHat), 0);
        }
        if (s.equals("Durak"))
        {
            Global.App_Durak_Sec = "Favorilerim";
            Global.App_Favorilerim_Durak_No = "";
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimDurak), 0);
        }
    }

    public void KlavyeX_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        InputMethodManager inputmethodmanager = (InputMethodManager)getSystemService("input_method");
        if (s.equals("Baslik"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f09002e).getWindowToken(), 0);
            ((EditText)findViewById(0x7f09002e)).setText("");
            ((EditText)findViewById(0x7f09002e)).requestFocus();
        }
        if (s.equals("HatNo"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090007).getWindowToken(), 0);
            ((EditText)findViewById(0x7f090007)).setText("");
            ((TextView)findViewById(0x7f090008)).setText("");
            ((EditText)findViewById(0x7f090007)).requestFocus();
        }
        if (s.equals("DurakNo"))
        {
            inputmethodmanager.hideSoftInputFromWindow(findViewById(0x7f090009).getWindowToken(), 0);
            ((EditText)findViewById(0x7f090009)).setText("");
            ((TextView)findViewById(0x7f09000a)).setText("");
            ((EditText)findViewById(0x7f090009)).requestFocus();
        }
        inputmethodmanager.toggleSoftInput(2, 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void PanelKaydet()
    {
        String s = ((EditText)findViewById(0x7f09002e)).getText().toString();
        String s1 = ((Spinner)findViewById(0x7f090038)).getSelectedItem().toString();
        String s2 = ((EditText)findViewById(0x7f090007)).getText().toString();
        String s3 = ((TextView)findViewById(0x7f090008)).getText().toString();
        String s4 = ((EditText)findViewById(0x7f090009)).getText().toString();
        String s5 = ((TextView)findViewById(0x7f09000a)).getText().toString();
        String s6;
        if (((CheckBox)findViewById(0x7f090066)).isChecked())
        {
            s6 = "true";
        } else
        {
            s6 = "false";
        }
        if (s.length() < 1)
        {
            Toast.makeText(getBaseContext(), "Panel Ba\u015Fl\u0131\u011F\u0131n\u0131 Giriniz!", 1).show();
            return;
        }
        if (s1.length() < 1)
        {
            Toast.makeText(getBaseContext(), "Panel Rengini Se\347iniz!", 1).show();
            return;
        }
        if (s3.length() == 0)
        {
            Toast.makeText(getBaseContext(), "Hat Sorgulanmad\u0131!", 1).show();
            return;
        }
        if (s4.length() != 5)
        {
            Toast.makeText(getBaseContext(), "Durak Numaras\u0131\n5 Basamakl\u0131 Say\u0131 Olmal\u0131!", 1).show();
            return;
        }
        if (s5.length() == 0)
        {
            Toast.makeText(getBaseContext(), "Durak Sorgulanmad\u0131!", 1).show();
            return;
        }
        if (Panel_No.equals(""))
        {
            Panel_New_No = (new StringBuilder(String.valueOf(s2))).append("|").append(s4).toString();
            String as2[] = {
                "FNC", "FavoriEkle"
            };
            String as3[] = new String[14];
            as3[0] = "UID";
            as3[1] = Global.Device_ID;
            as3[2] = "TIP";
            as3[3] = "Panel";
            as3[4] = "NO";
            as3[5] = (new StringBuilder(String.valueOf(s2))).append("|").append(s4).toString();
            as3[6] = "HATNO";
            as3[7] = s2;
            as3[8] = "DURAKNO";
            as3[9] = s4;
            as3[10] = "TANIM";
            as3[11] = s;
            as3[12] = "ACIKLAMA";
            as3[13] = (new StringBuilder(String.valueOf(s1))).append("|").append(s6).toString();
            http = new Http("PanelEkle", "favori.asp", as2, as3);
            http.addObserver(new Http.Callback() {

                final PanelimDuzenle this$0;

                public void onComplete(String s7, String s8, int i, Boolean boolean1, String s9)
                {
                    Action(s7, s8, i, boolean1, s9);
                }

            
            {
                this$0 = PanelimDuzenle.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        } else
        {
            Panel_New_No = (new StringBuilder(String.valueOf(s2))).append("|").append(s4).toString();
            String as[] = {
                "FNC", "FavoriDuzelt"
            };
            String as1[] = new String[16];
            as1[0] = "UID";
            as1[1] = Global.Device_ID;
            as1[2] = "TIP";
            as1[3] = "Panel";
            as1[4] = "ID";
            as1[5] = Panel_No;
            as1[6] = "NO";
            as1[7] = (new StringBuilder(String.valueOf(s2))).append("|").append(s4).toString();
            as1[8] = "HATNO";
            as1[9] = s2;
            as1[10] = "DURAKNO";
            as1[11] = s4;
            as1[12] = "TANIM";
            as1[13] = s;
            as1[14] = "ACIKLAMA";
            as1[15] = (new StringBuilder(String.valueOf(s1))).append("|").append(s6).toString();
            http = new Http("PanelDuzelt", "favori.asp", as, as1);
            http.addObserver(new Http.Callback() {

                final PanelimDuzenle this$0;

                public void onComplete(String s7, String s8, int i, Boolean boolean1, String s9)
                {
                    Action(s7, s8, i, boolean1, s9);
                }

            
            {
                this$0 = PanelimDuzenle.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
            return;
        }
    }

    public void PanelSil()
    {
        if (!Panel_No.equals(""))
        {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("Paneli Sil");
            builder.setMessage("Paneli Silmek \u0130stiyormusunuz?");
            builder.setPositiveButton("Hay\u0131r", null);
            builder.setNeutralButton("Sil", new android.content.DialogInterface.OnClickListener() {

                final PanelimDuzenle this$0;

                public void onClick(DialogInterface dialoginterface, int i)
                {
                    PanelimDuzenle panelimduzenle = PanelimDuzenle.this;
                    String as[] = {
                        "FNC", "FavoriSil"
                    };
                    String as1[] = new String[6];
                    as1[0] = "UID";
                    as1[1] = Global.Device_ID;
                    as1[2] = "TIP";
                    as1[3] = "Panel";
                    as1[4] = "NO";
                    as1[5] = Panel_No;
                    panelimduzenle.http = new Http("PanelSil", "favori.asp", as, as1);
                    http.addObserver(new Http.Callback() {

                        final _cls6 this$1;

                        public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
                        {
                            Action(s, s1, i, boolean1, s2);
                        }

            
            {
                this$1 = _cls6.this;
                super();
            }
                    });
                    http.execute(new String[0]);
                }


            
            {
                this$0 = PanelimDuzenle.this;
                super();
            }
            });
            builder.show();
        }
    }

    public void PanelSorgula()
    {
        String as[] = {
            "FNC", "Favori"
        };
        String as1[] = new String[8];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        as1[2] = "TIP";
        as1[3] = "Panel";
        as1[4] = "ID";
        as1[5] = "";
        as1[6] = "NO";
        as1[7] = Panel_No;
        http = new Http("Panel", "favori.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final PanelimDuzenle this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = PanelimDuzenle.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void Sorgula_OnClick(View view)
    {
        CloseKeyboard();
        String s = ((ImageButton)view).getTag().toString();
        if (s.equals("Hat"))
        {
            FavoriHatSorgula();
        }
        if (s.equals("Durak"))
        {
            FavoriDurakSorgula();
        }
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                PanelKaydet();
                return;
            }
            if (s.equals("3"))
            {
                PanelSil();
                return;
            }
            if (s.equals("4"))
            {
                DurakAra();
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (Global.App_Hat_Sec.equals("Favorilerim"))
        {
            if (j == 10 && !Global.App_Favorilerim_Hat_No.equals(""))
            {
                ((EditText)findViewById(0x7f090007)).setText(Global.App_Favorilerim_Hat_No);
                ((TextView)findViewById(0x7f090008)).setText(Global.App_Favorilerim_Hat_Tanim);
            }
            Global.App_Hat_Sec = "";
            Global.App_Favorilerim_Hat_No = "";
            Global.App_Favorilerim_Hat_Tanim = "";
        }
        if (Global.App_Durak_Sec.equals("Favorilerim"))
        {
            if (j == 10 && !Global.App_Favorilerim_Durak_No.equals(""))
            {
                ((EditText)findViewById(0x7f090009)).setText(Global.App_Favorilerim_Durak_No);
                ((TextView)findViewById(0x7f09000a)).setText(Global.App_Favorilerim_Durak_Tanim);
            }
            Global.App_Durak_Sec = "";
            Global.App_Favorilerim_Durak_No = "";
            Global.App_Favorilerim_Durak_Tanim = "";
        }
        if (Global.App_Adres_Sec.equals("HatAra"))
        {
            if (j == 10 && !Global.App_Hat_No.equals(""))
            {
                ((EditText)findViewById(0x7f090007)).setText(Global.App_Hat_No);
                FavoriHatSorgula();
            }
            Global.App_Adres_Sec = "";
            Global.App_Hat_No = "";
            Global.App_Hat_Tanim = "";
            Global.App_Durak_No = "";
            Global.App_Durak_Tanim = "";
            Global.App_Favorilerim_Durak_No = "";
            Global.App_Favorilerim_Durak_Tanim = "";
        }
        if (Global.App_Adres_Sec.equals("DurakAra"))
        {
            Global.App_Adres_Sec = "";
            if (j == 10 && !Global.App_Durak_No.equals(""))
            {
                ((EditText)findViewById(0x7f090009)).setText(Global.App_Durak_No);
                FavoriDurakSorgula();
                if (((EditText)findViewById(0x7f090007)).getText().toString().equals(""))
                {
                    Global.App_Adres_Sec = "HatAra";
                    Global.App_Favorilerim_Durak_No = Global.App_Durak_No;
                    Global.App_Favorilerim_Durak_Tanim = Global.App_Durak_Tanim;
                    startActivityForResult(new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar), 0);
                }
            }
            Global.App_Durak_No = "";
            Global.App_Durak_Tanim = "";
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030031);
        CloseKeyboard();
        dialog = Tools.Waiting(this);
        Spinner spinner = (Spinner)findViewById(0x7f090038);
        ArrayAdapter arrayadapter = new ArrayAdapter(this, 0x1090008, renkArray);
        arrayadapter.setDropDownViewResource(0x1090009);
        spinner.setAdapter(arrayadapter);
        Global.App_Hat_Sec = "";
        Global.App_Durak_Sec = "";
        Global.App_Adres_Sec = "";
        Panel_Id = Global.App_Panel_Id;
        Panel_No = Global.App_Panel_No;
        if (!Panel_No.equals(""))
        {
            PanelSorgula();
        }
        Global.App_Panel_No = "";
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        CloseKeyboard();
        super.onStop();
    }
}
