// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.view.View;
import android.widget.SeekBar;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import java.util.ArrayList;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            HatMap, Map

class this._cls0
    implements android.view.ickListener
{

    final HatMap this$0;

    public void onClick(View view)
    {
        try
        {
            new HashMap();
            HashMap hashmap = (HashMap)lstmapDurak.get(seekBar.getProgress());
            if (mv.getZoomLevel() < 15)
            {
                mc.setZoom(17);
            }
            mc.setCenter(Map.GP((new StringBuilder()).append((String)hashmap.get("lat")).toString(), (new StringBuilder()).append((String)hashmap.get("lng")).toString()));
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    apController()
    {
        this$0 = HatMap.this;
        super();
    }
}
