// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TabHost;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            NasilGiderimListe

class this._cls0
    implements android.widget.ickListener
{

    final NasilGiderimListe this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        HashMap hashmap = (HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(i);
        ((ListView)findViewById(0x7f09005f)).setSelection(Integer.parseInt((String)hashmap.get("id")));
        tabhost.setCurrentTab(1);
    }

    ckListener()
    {
        this$0 = NasilGiderimListe.this;
        super();
    }
}
