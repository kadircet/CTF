// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, ListAdapter, Global, KonumMap, 
//            Tools, HatBilgileri

public class YakindakiHatlar extends Activity
{

    ProgressDialog dialog;
    Http http;

    public YakindakiHatlar()
    {
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        ListView listview;
        ArrayList arraylist;
        int j;
        HashMap hashmap1;
        Exception exception1;
        int k;
        HashMap hashmap2;
        Exception exception2;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Hat")) goto _L4; else goto _L3
_L3:
        listview = (ListView)findViewById(0x7f09002a);
        arraylist = new ArrayList();
        HashMap hashmap = new HashMap();
        j = 0;
        hashmap1 = hashmap;
_L7:
        k = http.jArray.length();
        if (j < k) goto _L6; else goto _L5
_L5:
        hashmap1;
_L8:
        listview.setAdapter(new ListAdapter(this, arraylist, 0x7f03001a, new String[] {
            "no", "tanim", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048
        }));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final YakindakiHatlar this$0;

            public void onItemClick(AdapterView adapterview, View view, int l, long l1)
            {
                Global.App_Hat_No = (String)((HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(l)).get("no");
                Global.App_Durak_No = "";
                Global.App_Otobus_No = "";
                Intent intent = new Intent(getBaseContext(), com/ego/android/HatBilgileri);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = YakindakiHatlar.this;
                super();
            }
        });
_L4:
        return;
_L6:
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(j).toString());
        hashmap2.put("no", http.JValue(j, "kod"));
        hashmap2.put("tanim", http.JValue(j, "ad"));
        hashmap2.put("aciklama", http.JValue(j, "aciklama"));
        arraylist.add(hashmap2);
        j++;
        hashmap1 = hashmap2;
          goto _L7
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception1;
        hashmap1;
          goto _L8
        exception2;
          goto _L8
    }

    public void Harita()
    {
        Global.App_Konum = "Adres";
        Global.App_Konum_Adres = Global.App_Adres_Adres;
        Global.App_Konum_Ilce = Global.App_Adres_Ilce;
        Global.App_Konum_Lat = Global.App_Adres_Lat;
        Global.App_Konum_Lng = Global.App_Adres_Lng;
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/KonumMap), 0);
    }

    public void HatYenile()
    {
        String as[] = {
            "FNC", "YakinHatlar"
        };
        String as1[] = new String[8];
        as1[0] = "QUERY";
        as1[1] = "";
        as1[2] = "LAT";
        as1[3] = Global.App_Adres_Lat;
        as1[4] = "LNG";
        as1[5] = Global.App_Adres_Lng;
        as1[6] = "MESAFE";
        as1[7] = Global.Set_Yakinlik;
        http = new Http("Hat", "hat.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final YakindakiHatlar this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = YakindakiHatlar.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Harita();
                return;
            }
            if (!s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03003a);
        dialog = Tools.Waiting(this);
        ((TextView)findViewById(0x7f09006f)).setText(Global.App_Adres_Adres);
        ((TextView)findViewById(0x7f090070)).setText(Global.App_Adres_Ilce);
        HatYenile();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
