// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.text.Editable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Alarm, Global, HatBilgileri

class this._cls0
    implements android.widget.iew.OnItemClickListener
{

    final Alarm this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        HashMap hashmap = (HashMap)((ListView)findViewById(0x7f090010)).getItemAtPosition(i);
        Global.App_Hat_No = (String)hashmap.get("no");
        Global.App_Durak_No = ((EditText)findViewById(0x7f090009)).getText().toString();
        Global.App_Otobus_No = (String)hashmap.get("kod");
        Intent intent = new Intent(getBaseContext(), com/ego/android/HatBilgileri);
        startActivityForResult(intent, 0);
    }

    ew()
    {
        this$0 = Alarm.this;
        super();
    }
}
