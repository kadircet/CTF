// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;


// Referenced classes of package com.ego.android:
//            R

public static final class 
{

    public static final int AppBaseTheme = 0x7f070003;
    public static final int AppTheme = 0x7f070004;
    public static final int CustomTheme = 0x7f070000;
    public static final int SpinnerItem = 0x7f070001;
    public static final int SpinnerItem_DropDownItem = 0x7f070002;

    public ()
    {
    }
}
