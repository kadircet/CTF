// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

public class MapDraw extends Overlay
{

    private int bgColor;
    private int color;
    private GeoPoint gp;
    private GeoPoint gp2;
    private int pw;
    private int py;
    private int size;
    private int stroke;
    private String text;
    private String type;

    public MapDraw(String s, GeoPoint geopoint, int i, int j, int k, int l)
    {
        type = s;
        gp = geopoint;
        size = i;
        color = j;
        bgColor = k;
        stroke = l;
    }

    public MapDraw(String s, GeoPoint geopoint, int i, int j, int k, int l, int i1, 
            int j1, String s1)
    {
        type = s;
        gp = geopoint;
        size = i;
        color = j;
        bgColor = k;
        stroke = l;
        pw = i1;
        py = j1;
        text = s1;
    }

    public MapDraw(String s, GeoPoint geopoint, GeoPoint geopoint1, int i, int j)
    {
        type = s;
        gp = geopoint;
        gp2 = geopoint1;
        color = i;
        stroke = j;
    }

    public boolean draw(Canvas canvas, MapView mapview, boolean flag, long l)
    {
        super.draw(canvas, mapview, flag);
        Projection projection = mapview.getProjection();
        Paint paint = new Paint();
        Point point = new Point();
        projection.toPixels(gp, point);
        if (type.equals("Circle"))
        {
            float f = projection.metersToEquatorPixels((float)(1.3999999999999999D * (double)size));
            Paint paint1 = new Paint();
            paint1.setColor(bgColor);
            paint1.setAntiAlias(true);
            paint1.setStyle(android.graphics.Paint.Style.FILL);
            canvas.drawCircle(point.x, point.y, f, paint1);
            paint = new Paint();
            paint.setColor(color);
            paint.setAntiAlias(true);
            paint.setStyle(android.graphics.Paint.Style.STROKE);
            paint.setStrokeWidth(stroke);
            canvas.drawCircle(point.x, point.y, f, paint);
        }
        if (type.equals("Text"))
        {
            paint.setColor(color);
            paint.setStyle(android.graphics.Paint.Style.STROKE);
            paint.setTextSize(size);
            canvas.drawText(text, point.x + pw, point.y + py, paint);
        }
        if (type.equals("Line"))
        {
            Point point1 = new Point();
            projection.toPixels(gp2, point1);
            paint.setColor(color);
            paint.setAntiAlias(true);
            paint.setStrokeWidth(stroke);
            canvas.drawLine(point.x, point.y, point1.x, point1.y, paint);
        }
        return true;
    }
}
