// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.location.Location;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            NasilGiderim, Gps

class this._cls0
    implements this._cls0
{

    final NasilGiderim this$0;

    public void onComplete(Location location)
    {
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (location == null)
        {
            try
            {
                Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                return;
            }
            catch (Exception exception1)
            {
                return;
            }
        }
        if (!gps.GpsAdres.equals(""))
        {
            break MISSING_BLOCK_LABEL_97;
        }
        Toast.makeText(getBaseContext(), "Adres Bulunamad\u0131!", 1).show();
        NeredenNereye(LocationAra, "", "", "", "");
_L2:
        LocationAra = "";
        return;
        NeredenNereye(LocationAra, gps.GpsAdres, gps.GpsIlce, (new StringBuilder()).append(gps.GpsLat).toString(), (new StringBuilder()).append(gps.GpsLng).toString());
        if (true) goto _L2; else goto _L1
_L1:
    }

    ()
    {
        this$0 = NasilGiderim.this;
        super();
    }
}
