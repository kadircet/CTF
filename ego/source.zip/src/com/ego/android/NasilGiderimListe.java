// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Http, ListAdapter, Global, Tools, 
//            NasilGiderimDetay

public class NasilGiderimListe extends Activity
{

    ProgressDialog dialog;
    Http http;
    public TabHost tabhost;

    public NasilGiderimListe()
    {
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        ListView listview;
        ArrayList arraylist;
        String s3;
        int j;
        int k;
        HashMap hashmap1;
        Exception exception1;
        ListView listview1;
        ArrayList arraylist1;
        HashMap hashmap2;
        String s4;
        int l;
        Exception exception2;
        int i1;
        String s5;
        String s6;
        int j1;
        HashMap hashmap3;
        Exception exception3;
        HashMap hashmap4;
        String as[];
        String s7;
        String s8;
        String s9;
        int k1;
        String s10;
        String s11;
        int l1;
        HashMap hashmap5;
        int i2;
        String s12;
        Exception exception4;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("HatAra")) goto _L4; else goto _L3
_L3:
        listview = (ListView)findViewById(0x7f09002a);
        arraylist = new ArrayList();
        HashMap hashmap = new HashMap();
        s3 = "";
        j = 0;
        k = 0;
        hashmap1 = hashmap;
_L14:
        k1 = http.jArray.length();
        if (k < k1) goto _L6; else goto _L5
_L5:
        hashmap1;
_L22:
        listview.setAdapter(new ListAdapter(this, arraylist, 0x7f03001a, new String[] {
            "no", "tanim", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048
        }));
        listview.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final NasilGiderimListe this$0;

            public void onItemClick(AdapterView adapterview, View view, int j2, long l2)
            {
                HashMap hashmap6 = (HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(j2);
                ((ListView)findViewById(0x7f09005f)).setSelection(Integer.parseInt((String)hashmap6.get("id")));
                tabhost.setCurrentTab(1);
            }

            
            {
                this$0 = NasilGiderimListe.this;
                super();
            }
        });
        listview1 = (ListView)findViewById(0x7f09005f);
        arraylist1 = new ArrayList();
        hashmap2 = new HashMap();
        s4 = "";
        l = 0;
_L25:
        i1 = http.jArray.length();
        if (l < i1) goto _L8; else goto _L7
_L7:
        listview1.setAdapter(new ListAdapter(this, arraylist1, 0x7f03001a, new String[] {
            "no", "tanim", "aciklama"
        }, new int[] {
            0x7f090045, 0x7f090046, 0x7f090048
        }));
        listview1.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {

            final NasilGiderimListe this$0;

            public void onItemClick(AdapterView adapterview, View view, int j2, long l2)
            {
                Global.App_NasilGiderim = (HashMap)((ListView)findViewById(0x7f09005f)).getItemAtPosition(j2);
                Intent intent = new Intent(getBaseContext(), com/ego/android/NasilGiderimDetay);
                startActivityForResult(intent, 0);
            }

            
            {
                this$0 = NasilGiderimListe.this;
                super();
            }
        });
_L4:
        return;
_L6:
        s10 = http.JValue(k, "kod");
        s11 = "";
        l1 = j;
        if (s3.indexOf((new StringBuilder(String.valueOf(s10))).append(";").toString()) != -1) goto _L10; else goto _L9
_L9:
        s3 = (new StringBuilder(String.valueOf(s3))).append(s10).append(";").toString();
        i2 = k;
_L15:
        if (i2 < http.jArray.length()) goto _L12; else goto _L11
_L11:
        if (s11.equals("")) goto _L10; else goto _L13
_L13:
        hashmap5 = new HashMap();
        hashmap5.put("id", (new StringBuilder()).append(l1).toString());
        hashmap5.put("no", http.JValue(k, "kod"));
        hashmap5.put("tanim", http.JValue(k, "ad"));
        hashmap5.put("aciklama", s11);
        arraylist.add(hashmap5);
_L24:
        k++;
        hashmap1 = hashmap5;
          goto _L14
_L12:
        if (!s10.equals(http.JValue(i2, "kod")))
        {
            break MISSING_BLOCK_LABEL_612;
        }
        if (!s11.equals(""))
        {
            s11 = (new StringBuilder(String.valueOf(s11))).append(", ").toString();
        }
        s11 = (new StringBuilder(String.valueOf(s11))).append(http.JValue(i2, "vkod")).toString();
        if (!s10.equals(http.JValue(i2, "vkod")))
        {
            break MISSING_BLOCK_LABEL_609;
        }
        s12 = (new StringBuilder(String.valueOf(s11))).append(" D.Hat").toString();
        s11 = s12;
        j++;
        i2++;
          goto _L15
_L8:
        s5 = http.JValue(l, "kod");
        if (s4.indexOf((new StringBuilder(String.valueOf(s5))).append(";").toString()) != -1)
        {
            break MISSING_BLOCK_LABEL_1402;
        }
        s6 = (new StringBuilder(String.valueOf(s4))).append(s5).append(";").toString();
        s4 = s6;
        j1 = l;
        hashmap3 = hashmap2;
_L20:
        if (j1 >= http.jArray.length())
        {
            hashmap2 = hashmap3;
            break MISSING_BLOCK_LABEL_1402;
        }
        if (!s5.equals(http.JValue(j1, "kod"))) goto _L17; else goto _L16
_L16:
        as = http.JValue(j1, "durak").split(";");
        if (!s5.equals(http.JValue(j1, "vkod"))) goto _L19; else goto _L18
_L18:
        s8 = (new StringBuilder(String.valueOf(""))).append(as[0]).append(". Dura\u011F\u0131ndan Binip, ").append(as[1]).append(". Dura\u011F\u0131nda \u0130nin\n\n").toString();
_L21:
        s9 = (new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf(s8))).append(http.JValue(j1, "tur")).append(" Hat, ").toString()))).append("S\374resi: ").append(http.JValue(j1, "sure")).append(", ").toString()))).append("Uzunlu\u011Fu: ").append(http.JValue(j1, "mesafe")).toString();
        hashmap4 = new HashMap();
        hashmap4.put("id", (new StringBuilder()).append(l).toString());
        hashmap4.put("no", http.JValue(j1, "kod"));
        hashmap4.put("tanim", http.JValue(j1, "ad"));
        hashmap4.put("aciklama", s9);
        hashmap4.put("kod", http.JValue(j1, "kod"));
        hashmap4.put("ad", http.JValue(j1, "ad"));
        hashmap4.put("durakbin", as[0]);
        hashmap4.put("durakin", as[1]);
        hashmap4.put("vkod", http.JValue(j1, "vkod"));
        hashmap4.put("vad", http.JValue(j1, "vad"));
        hashmap4.put("vdurakbin", as[2]);
        hashmap4.put("vdurakin", as[3]);
        hashmap4.put("tur", http.JValue(j1, "tur"));
        hashmap4.put("sure", http.JValue(j1, "sure"));
        hashmap4.put("mesafe", http.JValue(j1, "mesafe"));
        arraylist1.add(hashmap4);
_L23:
        j1++;
        hashmap3 = hashmap4;
          goto _L20
_L19:
        s7 = (new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf(""))).append(as[0]).append(". Dura\u011F\u0131ndan Binip, ").append(as[1]).append(". Dura\u011F\u0131nda \u0130nin Hatt\u0131 De\u011Fi\u015Ftirin\n\n").toString()))).append("> ").append(http.JValue(j1, "vkod")).append(" ").append(http.JValue(j1, "vad")).append("\n").toString()))).append(as[2]).append(". Dura\u011F\u0131ndan Binip, ").append(as[3]).append(". Dura\u011F\u0131nda \u0130nin\n\n").toString();
        s8 = s7;
          goto _L21
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception2;
          goto _L7
        exception3;
        hashmap3;
          goto _L7
        exception1;
        hashmap1;
          goto _L22
        exception4;
          goto _L22
_L17:
        hashmap4 = hashmap3;
          goto _L23
_L10:
        hashmap5 = hashmap1;
          goto _L24
        l++;
          goto _L25
    }

    public void HatAra()
    {
        String as[] = {
            "FNC", "HatAra"
        };
        String as1[] = new String[12];
        as1[0] = "LAT1";
        as1[1] = Global.App_Nereden_Lat;
        as1[2] = "LNG1";
        as1[3] = Global.App_Nereden_Lng;
        as1[4] = "LAT2";
        as1[5] = Global.App_Nereye_Lat;
        as1[6] = "LNG2";
        as1[7] = Global.App_Nereye_Lng;
        as1[8] = "SIRALAMA";
        as1[9] = Global.App_NasilGiderim_Siralama;
        as1[10] = "MESAFE";
        as1[11] = "750";
        http = new Http("HatAra", "nasilgiderim.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final NasilGiderimListe this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = NasilGiderimListe.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (!s.equals("2") && !s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030029);
        dialog = Tools.Waiting(this);
        tabhost = (TabHost)findViewById(0x7f090031);
        tabhost.setup();
        android.widget.TabHost.TabSpec tabspec = tabhost.newTabSpec("Tab1");
        tabspec.setIndicator("Hatlar", getResources().getDrawable(0x7f020037));
        tabspec.setContent(0x7f090032);
        tabhost.addTab(tabspec);
        android.widget.TabHost.TabSpec tabspec1 = tabhost.newTabSpec("Tab2");
        tabspec1.setIndicator("Detaylar", getResources().getDrawable(0x7f02002f));
        tabspec1.setContent(0x7f090034);
        tabhost.addTab(tabspec1);
        tabhost.setCurrentTab(0);
        tabhost.getTabWidget().getChildAt(0).setOnClickListener(new android.view.View.OnClickListener() {

            final NasilGiderimListe this$0;

            public void onClick(View view)
            {
                tabhost.setCurrentTab(0);
            }

            
            {
                this$0 = NasilGiderimListe.this;
                super();
            }
        });
        tabhost.getTabWidget().getChildAt(1).setOnClickListener(new android.view.View.OnClickListener() {

            final NasilGiderimListe this$0;

            public void onClick(View view)
            {
                tabhost.setCurrentTab(1);
            }

            
            {
                this$0 = NasilGiderimListe.this;
                super();
            }
        });
        ((TextView)findViewById(0x7f090059)).setText(Global.App_Nereden_Adres);
        ((TextView)findViewById(0x7f09005c)).setText(Global.App_Nereden_Ilce);
        ((TextView)findViewById(0x7f09005a)).setText(Global.App_Nereye_Adres);
        ((TextView)findViewById(0x7f09005d)).setText(Global.App_Nereye_Ilce);
        HatAra();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
