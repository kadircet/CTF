// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;


// Referenced classes of package com.ego.android:
//            Gps

class >
    implements Runnable
{

    final Gps this$0;

    public void run()
    {
label0:
        {
            if (handlerTimerStatus)
            {
                Gps gps = Gps.this;
                gps.handlerTimerCounter = -1 + gps.handlerTimerCounter;
                if (handlerTimerCounter <= 0)
                {
                    break label0;
                }
                Gps.this.Runnable();
            }
            return;
        }
        Return();
    }

    ()
    {
        this$0 = Gps.this;
        super();
    }
}
