// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Favorilerim, Global, FavorilerimDurakDuzenle

class this._cls0
    implements android.widget.ItemLongClickListener
{

    final Favorilerim this$0;

    public boolean onItemLongClick(AdapterView adapterview, View view, int i, long l)
    {
        Global.App_Favorilerim_Durak_No = (String)((HashMap)((ListView)findViewById(0x7f090033)).getItemAtPosition(i)).get("no");
        Intent intent = new Intent(getBaseContext(), com/ego/android/FavorilerimDurakDuzenle);
        startActivityForResult(intent, 0);
        return true;
    }

    akDuzenle()
    {
        this$0 = Favorilerim.this;
        super();
    }
}
