// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.DialogInterface;

// Referenced classes of package com.ego.android:
//            FavorilerimDurakDuzenle, Global, Http

class this._cls1
    implements this._cls1
{

    final on this$1;

    public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
    {
        Action(s, s1, i, boolean1, s2);
    }

    is._cls0()
    {
        this$1 = this._cls1.this;
        super();
    }

    // Unreferenced inner class com/ego/android/FavorilerimDurakDuzenle$5

/* anonymous class */
    class FavorilerimDurakDuzenle._cls5
        implements android.content.DialogInterface.OnClickListener
    {

        final FavorilerimDurakDuzenle this$0;

        public void onClick(DialogInterface dialoginterface, int i)
        {
            FavorilerimDurakDuzenle favorilerimdurakduzenle = FavorilerimDurakDuzenle.this;
            String as[] = {
                "FNC", "FavoriSil"
            };
            String as1[] = new String[6];
            as1[0] = "UID";
            as1[1] = Global.Device_ID;
            as1[2] = "TIP";
            as1[3] = "Durak";
            as1[4] = "NO";
            as1[5] = Favorilerim_Durak_No;
            favorilerimdurakduzenle.http = new Http("FavoriSil", "favori.asp", as, as1);
            http.addObserver(new FavorilerimDurakDuzenle._cls5._cls1());
            http.execute(new String[0]);
        }


            
            {
                this$0 = FavorilerimDurakDuzenle.this;
                super();
            }
    }

}
