// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            OnemliYerlerDetay, Global, KonumMap

class this._cls0
    implements android.widget.ngClickListener
{

    final OnemliYerlerDetay this$0;

    public boolean onItemLongClick(AdapterView adapterview, View view, int i, long l)
    {
        HashMap hashmap = (HashMap)((ListView)findViewById(0x7f090062)).getItemAtPosition(i);
        Global.App_Konum = "\326nemli Yer";
        Global.App_Konum_Adres = (new StringBuilder(String.valueOf((String)hashmap.get("ad")))).append("\n\n").append((String)hashmap.get("yer")).toString();
        Global.App_Konum_Ilce = (String)hashmap.get("ilce");
        Global.App_Konum_Lat = (String)hashmap.get("lat");
        Global.App_Konum_Lng = (String)hashmap.get("lng");
        Intent intent = new Intent(getBaseContext(), com/ego/android/KonumMap);
        startActivityForResult(intent, 0);
        return true;
    }

    gClickListener()
    {
        this$0 = OnemliYerlerDetay.this;
        super();
    }
}
