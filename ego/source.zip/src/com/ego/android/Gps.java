// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

// Referenced classes of package com.ego.android:
//            Global, Geo

public class Gps extends Service
    implements LocationListener
{
    public static interface Callback
    {

        public abstract void onComplete(Location location);
    }


    public String GpsAdres;
    public String GpsIlce;
    public String GpsLat;
    public String GpsLng;
    public Location GpsLocation;
    public boolean GpsYenile;
    boolean Status;
    private Set callbacks;
    Context context;
    Handler handlerTimer;
    int handlerTimerCounter;
    Runnable handlerTimerRunnable;
    boolean handlerTimerStatus;
    LocationListener locationListenerGps;
    LocationListener locationListenerNetwork;
    LocationManager locationManager;

    public Gps(Context context1)
    {
        handlerTimer = new Handler();
        GpsLat = "";
        GpsLng = "";
        GpsAdres = "";
        GpsIlce = "";
        GpsYenile = false;
        callbacks = new HashSet();
        context = context1;
        Status = false;
        handlerTimerStatus = false;
        handlerTimerCounter = 0;
        GpsLocation = null;
        GpsLat = "";
        GpsLng = "";
        GpsAdres = "";
        GpsIlce = "";
    }

    public void GeoAction(String s, ArrayList arraylist)
    {
        Iterator iterator;
        if (arraylist != null)
        {
            try
            {
                HashMap hashmap = (HashMap)arraylist.get(0);
                GpsAdres = (String)hashmap.get("adres");
                GpsIlce = (String)hashmap.get("ilce");
                GpsLat = (new StringBuilder()).append(GpsLocation.getLatitude()).toString();
                GpsLng = (new StringBuilder()).append(GpsLocation.getLongitude()).toString();
                Global.App_Gps_Location = GpsLocation;
                Global.App_Gps_Adres = GpsAdres;
                Global.App_Gps_Ilce = GpsIlce;
                Global.App_Gps_Lat = GpsLat;
                Global.App_Gps_Lng = GpsLng;
            }
            catch (Exception exception)
            {
                GpsAdres = "";
                GpsIlce = "";
                GpsLat = "";
                GpsLng = "";
            }
        }
        iterator = callbacks.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                return;
            }
            ((Callback)iterator.next()).onComplete(GpsLocation);
        } while (true);
    }

    public void Return()
    {
        Stop();
        if (GpsLocation == null)
        {
            break MISSING_BLOCK_LABEL_234;
        }
        if (!Global.App_Gps_Lat.equals((new StringBuilder()).append(GpsLocation.getLatitude()).toString()) || !Global.App_Gps_Lng.equals((new StringBuilder()).append(GpsLocation.getLongitude()).toString()) || Global.App_Adres_Adres.equals("") || Global.App_Adres_Ilce.equals("") || GpsYenile) goto _L2; else goto _L1
_L1:
        Iterator iterator1;
        GpsAdres = Global.App_Gps_Adres;
        GpsIlce = Global.App_Gps_Ilce;
        GpsLat = Global.App_Gps_Lat;
        GpsLng = Global.App_Gps_Lng;
        iterator1 = callbacks.iterator();
_L5:
        if (iterator1.hasNext()) goto _L4; else goto _L3
_L3:
        return;
_L4:
        ((Callback)iterator1.next()).onComplete(GpsLocation);
          goto _L5
_L2:
        Geo geo = new Geo("Location");
        geo.addObserver(new Geo.Callback() {

            final Gps this$0;

            public void onComplete(String s, ArrayList arraylist)
            {
                GeoAction(s, arraylist);
            }

            
            {
                this$0 = Gps.this;
                super();
            }
        });
        geo.LatLng((new StringBuilder()).append(GpsLocation.getLatitude()).toString(), (new StringBuilder()).append(GpsLocation.getLongitude()).toString());
        return;
        Iterator iterator = callbacks.iterator();
        while (iterator.hasNext()) 
        {
            ((Callback)iterator.next()).onComplete(GpsLocation);
        }
          goto _L3
    }

    public void Runnable()
    {
        try
        {
            handlerTimer.removeCallbacks(handlerTimerRunnable);
        }
        catch (Exception exception) { }
        handlerTimerRunnable = new Runnable() {

            final Gps this$0;

            public void run()
            {
label0:
                {
                    if (handlerTimerStatus)
                    {
                        Gps gps = Gps.this;
                        gps.handlerTimerCounter = -1 + gps.handlerTimerCounter;
                        if (handlerTimerCounter <= 0)
                        {
                            break label0;
                        }
                        Gps.this.Runnable();
                    }
                    return;
                }
                Return();
            }

            
            {
                this$0 = Gps.this;
                super();
            }
        };
        handlerTimer.postDelayed(handlerTimerRunnable, 1000L);
    }

    public boolean Start()
    {
        Toast.makeText(context, "L\374tfen Bekleyiniz", 1).show();
        if (Global.App_Gps_Location != null && !GpsYenile)
        {
            GpsLocation = Global.App_Gps_Location;
            Return();
            return true;
        }
        locationManager = (LocationManager)context.getSystemService("location");
        boolean flag = locationManager.isProviderEnabled("gps");
        boolean flag1 = locationManager.isProviderEnabled("network");
        if (!flag && !flag1)
        {
            Return();
            return false;
        }
        Location location = null;
        if (flag)
        {
            locationManager.requestLocationUpdates("gps", 5000L, 5F, this);
            location = locationManager.getLastKnownLocation("gps");
            if (location != null)
            {
                onLocationChanged(location);
            }
        }
        if (location != null && flag1)
        {
            locationManager.requestLocationUpdates("network", 15000L, 15F, this);
            Location location1 = locationManager.getLastKnownLocation("network");
            if (location1 != null)
            {
                onLocationChanged(location1);
            }
        }
        handlerTimerStatus = true;
        handlerTimerCounter = 30;
        Runnable();
        Status = true;
        return true;
    }

    public void Stop()
    {
        handlerTimerStatus = false;
        try
        {
            handlerTimer.removeCallbacks(handlerTimerRunnable);
        }
        catch (Exception exception) { }
        try
        {
            locationManager.removeUpdates(this);
        }
        catch (Exception exception1) { }
        try
        {
            locationManager.removeUpdates(locationListenerGps);
        }
        catch (Exception exception2) { }
        try
        {
            locationManager.removeUpdates(locationListenerNetwork);
            return;
        }
        catch (Exception exception3)
        {
            return;
        }
    }

    public void addObserver(Callback callback)
    {
        callbacks.add(callback);
    }

    public IBinder onBind(Intent intent)
    {
        return null;
    }

    public void onLocationChanged(Location location)
    {
        if (location != null) goto _L2; else goto _L1
_L1:
        Iterator iterator = locationManager.getAllProviders().iterator();
_L4:
        boolean flag = iterator.hasNext();
        if (flag) goto _L3; else goto _L2
_L2:
        if (location != null)
        {
            GpsLocation = location;
        }
        return;
_L3:
        Location location1;
        String s = (String)iterator.next();
        location1 = locationManager.getLastKnownLocation(s);
        location = location1;
          goto _L4
        Exception exception;
        exception;
          goto _L2
    }

    public void onProviderDisabled(String s)
    {
    }

    public void onProviderEnabled(String s)
    {
    }

    public void onStatusChanged(String s, int i, Bundle bundle)
    {
    }
}
