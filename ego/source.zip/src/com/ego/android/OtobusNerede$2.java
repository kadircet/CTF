// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Location;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            OtobusNerede, Gps, Global, YakindakiDuraklar

class this._cls0
    implements this._cls0
{

    final OtobusNerede this$0;

    public void onComplete(Location location)
    {
        Intent intent;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (location == null)
        {
            try
            {
                Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                return;
            }
            catch (Exception exception1)
            {
                return;
            }
        }
        if (gps.GpsAdres.equals(""))
        {
            Toast.makeText(getBaseContext(), "Adres Bulunamad\u0131!", 1).show();
            return;
        }
        Global.App_Adres_Adres = gps.GpsAdres;
        Global.App_Adres_Ilce = gps.GpsIlce;
        Global.App_Adres_Lat = gps.GpsLat;
        Global.App_Adres_Lng = gps.GpsLng;
        Global.App_Adres_Query = "";
        Global.App_Adres_Sec = "DurakAra";
        Global.App_Durak_No = "";
        intent = new Intent(getBaseContext(), com/ego/android/YakindakiDuraklar);
        startActivityForResult(intent, 0);
        return;
    }

    ar()
    {
        this$0 = OtobusNerede.this;
        super();
    }
}
