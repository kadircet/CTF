// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Dialog;
import android.view.View;

// Referenced classes of package com.ego.android:
//            YakindakiDurakVeHatlar

class val.dialogBox
    implements android.view.._cls8
{

    final YakindakiDurakVeHatlar this$0;
    private final Dialog val$dialogBox;

    public void onClick(View view)
    {
        val$dialogBox.dismiss();
    }

    ()
    {
        this$0 = final_yakindakidurakvehatlar;
        val$dialogBox = Dialog.this;
        super();
    }
}
