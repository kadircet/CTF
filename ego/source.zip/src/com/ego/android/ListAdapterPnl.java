// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Tools

public class ListAdapterPnl extends SimpleAdapter
{

    Boolean bgColor;
    ArrayList listMap;

    public ListAdapterPnl(Context context, ArrayList arraylist, int i, String as[], int ai[])
    {
        super(context, arraylist, i, as, ai);
        listMap = arraylist;
        bgColor = Boolean.valueOf(false);
    }

    public ListAdapterPnl(Context context, ArrayList arraylist, int i, String as[], int ai[], Boolean boolean1)
    {
        super(context, arraylist, i, as, ai);
        listMap = arraylist;
        bgColor = boolean1;
    }

    public View getView(int i, View view, ViewGroup viewgroup)
    {
        View view1;
        view1 = super.getView(i, view, viewgroup);
        view1.setBackgroundColor(0x30262626);
        if (!bgColor.booleanValue()) goto _L2; else goto _L1
_L1:
        HashMap hashmap = (HashMap)listMap.get(i);
        LinearLayout linearlayout;
        Button button;
        LinearLayout linearlayout1;
        Button button1;
        try
        {
            if (!((String)hashmap.get("bgcolor")).equals(""))
            {
                view1.setBackgroundColor(Color.parseColor((String)hashmap.get("bgcolor")));
            }
        }
        catch (Exception exception) { }
        if (((String)hashmap.get("bgcolor1")).equals("")) goto _L4; else goto _L3
_L3:
        linearlayout1 = (LinearLayout)view1.findViewById(0x7f090051);
        linearlayout1.setTag(hashmap.get("btn1"));
        linearlayout1.setBackgroundColor(Color.parseColor((String)hashmap.get("bgcolor1")));
        button1 = (Button)view1.findViewById(0x7f090053);
        if (((String)hashmap.get("btn1")).equals("")) goto _L6; else goto _L5
_L5:
        button1.setVisibility(0);
_L16:
        button1.setTag(hashmap.get("btn1"));
        if (!((String)hashmap.get("bgcolor1")).equals(Tools.ToColor("Pasif"))) goto _L8; else goto _L7
_L7:
        ((TextView)view1.findViewById(0x7f090052)).setTextColor(0xff888888);
        ((TextView)view1.findViewById(0x7f090054)).setTextColor(0xff888888);
_L4:
        if (((String)hashmap.get("bgcolor2")).equals("")) goto _L2; else goto _L9
_L9:
        linearlayout = (LinearLayout)view1.findViewById(0x7f090055);
        linearlayout.setTag(hashmap.get("btn2"));
        linearlayout.setBackgroundColor(Color.parseColor((String)hashmap.get("bgcolor2")));
        button = (Button)view1.findViewById(0x7f090057);
        if (((String)hashmap.get("btn2")).equals("")) goto _L11; else goto _L10
_L10:
        button.setVisibility(0);
_L14:
        button.setTag(hashmap.get("btn2"));
        if (!((String)hashmap.get("bgcolor2")).equals(Tools.ToColor("Pasif"))) goto _L13; else goto _L12
_L12:
        ((TextView)view1.findViewById(0x7f090056)).setTextColor(0xff888888);
        ((TextView)view1.findViewById(0x7f090058)).setTextColor(0xff888888);
        return view1;
_L6:
        try
        {
            button1.setVisibility(8);
        }
        catch (Exception exception1)
        {
            return view1;
        }
        continue; /* Loop/switch isn't completed */
_L8:
        ((TextView)view1.findViewById(0x7f090052)).setTextColor(-1);
        ((TextView)view1.findViewById(0x7f090054)).setTextColor(-1);
          goto _L4
_L11:
        button.setVisibility(8);
          goto _L14
_L13:
        ((TextView)view1.findViewById(0x7f090056)).setTextColor(-1);
        ((TextView)view1.findViewById(0x7f090058)).setTextColor(-1);
        return view1;
_L2:
        return view1;
        if (true) goto _L16; else goto _L15
_L15:
    }
}
