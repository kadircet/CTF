// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.ego.android:
//            Global, Http, Map, MapOverlay, 
//            MapDraw, Gps, YakindakiDurakVeHatlar, DuraktanGecenHatlar, 
//            FavorilerimDurakDuzenle, Tools

public class OtobusNeredeMap extends MapActivity
{

    GeoPoint BekledigimDurak;
    boolean IlkGoster;
    boolean OtobusBilgisiText;
    String OtobusNo;
    boolean OtobusleriTakipEt;
    boolean Yenile;
    Menu appMenu;
    ProgressDialog dialog;
    Gps gps;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    long lastTouchDoubleTime;
    List lo;
    boolean location;
    String locationAdres;
    String locationIlce;
    int locationOverlay;
    GeoPoint locationPosition;
    ArrayList lstmapDurak;
    ArrayList lstmapYol;
    MapController mc;
    MapView mv;
    int otobusOverlay;
    boolean pageStatus;
    int zoom;

    public OtobusNeredeMap()
    {
        pageStatus = true;
        lastTouchDoubleTime = -1L;
        location = false;
        locationAdres = "";
        locationIlce = "";
        locationOverlay = -1;
        otobusOverlay = -1;
        handler = new Handler();
        handlerStatus = false;
        lstmapYol = new ArrayList();
        lstmapDurak = new ArrayList();
        IlkGoster = true;
        Yenile = false;
        OtobusleriTakipEt = true;
        BekledigimDurak = null;
        OtobusNo = "";
        zoom = Integer.parseInt(Global.Set_Yaklasim);
        OtobusBilgisiText = false;
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        HashMap hashmap;
        int j;
        JSONArray jsonarray;
        int k;
        int l;
        int i1;
        int j1;
        JSONObject jsonobject1;
        JSONArray jsonarray1;
        int l1;
        HashMap hashmap1;
        JSONObject jsonobject2;
        HashMap hashmap2;
        String as1[];
        int i2;
        HashMap hashmap3;
        String as2[];
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (pageStatus) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if (i != 200) goto _L4; else goto _L3
_L3:
        try
        {
            if (!s.equals("Hat"))
            {
                continue; /* Loop/switch isn't completed */
            }
            hashmap = new HashMap();
            lstmapYol.clear();
            lstmapDurak.clear();
            ((TextView)findViewById(0x7f09003f)).setText((new StringBuilder(String.valueOf(http.JValue(0, "kod")))).append(" - ").append(http.JValue(0, "ad")).toString());
        }
        catch (Exception exception1)
        {
            return;
        }
        as1 = http.JValue(0, "yol").split(" ");
        i2 = 0;
        hashmap3 = hashmap;
_L21:
        if (i2 < as1.length) goto _L6; else goto _L5
_L5:
        Isaretle("Yol", null, zoom, "");
        hashmap = hashmap3;
_L25:
        jsonarray1 = http.JArray(0, "durak");
        l1 = 0;
        hashmap1 = hashmap;
_L22:
        if (l1 < jsonarray1.length()) goto _L8; else goto _L7
_L7:
        Isaretle("Durak", null, zoom, "");
        hashmap1;
_L24:
        mv.invalidate();
        if (Global.App_OtobusYenilemeSuresi > 0)
        {
            OtobusYenile(0);
        }
        if (!s.equals("OtobusAra")) goto _L1; else goto _L9
_L9:
        if (otobusOverlay == -1) goto _L11; else goto _L10
_L10:
        if (mv.getOverlays().size() > otobusOverlay) goto _L13; else goto _L12
_L12:
        mv.invalidate();
_L11:
        ((Button)findViewById(0x7f090040)).setVisibility(0);
        ((Button)findViewById(0x7f090041)).setVisibility(8);
        j = 0;
        jsonarray = http.JArray(0, "otobus");
        k = 0;
        l = 0;
_L26:
        if (l < jsonarray.length()) goto _L15; else goto _L14
_L14:
        i1 = 0;
_L27:
        j1 = jsonarray.length();
        if (i1 < j1) goto _L17; else goto _L16
_L16:
        Yenile = false;
        if (j <= 0) goto _L19; else goto _L18
_L18:
        if (Global.App_OtobusYenilemeSuresi > 0)
        {
            OtobusYenile(Global.App_OtobusYenilemeSuresi);
            return;
        }
          goto _L20
_L6:
        as2 = as1[i2].split(",");
        hashmap = new HashMap();
        hashmap.put("lat", as2[1]);
        hashmap.put("lng", as2[0]);
        lstmapYol.add(hashmap);
        i2++;
        hashmap3 = hashmap;
          goto _L21
_L8:
        jsonobject2 = jsonarray1.getJSONObject(l1);
        hashmap2 = new HashMap();
        hashmap2.put("sno", jsonobject2.getString("sno"));
        hashmap2.put("ad", jsonobject2.getString("ad"));
        hashmap2.put("yer", jsonobject2.getString("yer"));
        hashmap2.put("aciklama", jsonobject2.getString("aciklama"));
        hashmap2.put("lat", jsonobject2.getString("lat"));
        hashmap2.put("lng", jsonobject2.getString("lng"));
        lstmapDurak.add(hashmap2);
        l1++;
        hashmap1 = hashmap2;
          goto _L22
_L13:
        mv.getOverlays().remove(otobusOverlay);
          goto _L10
_L15:
        jsonobject1 = jsonarray.getJSONObject(l);
        break MISSING_BLOCK_LABEL_592;
_L17:
        jsonobject = jsonarray.getJSONObject(i1);
        geopoint = Map.GP((new StringBuilder()).append(jsonobject.getString("lat")).toString(), (new StringBuilder()).append(jsonobject.getString("lng")).toString());
        if (i1 != k)
        {
            break MISSING_BLOCK_LABEL_1561;
        }
        j++;
        String s3 = (new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf(""))).append("Ara\347 No: ").append(jsonobject.getString("kod")).append("\n").toString()))).append("Plaka: ").append(jsonobject.getString("plaka")).append("\n").toString()))).append("H\u0131z: ").append(jsonobject.getString("hiz")).append("\n").toString()))).append("T.V.S\374resi: ").append(jsonobject.getString("sure")).append("\n").toString()))).append(jsonobject.getString("aciklama").replace(", Konumu:", "\nKonumu:")).toString();
        if (!jsonobject.getString("arac").equals(""))
        {
            s3 = (new StringBuilder(String.valueOf(s3))).append("\nAra\347: ").append(jsonobject.getString("arac")).toString();
        }
        ((Button)findViewById(0x7f090041)).setText(s3);
        if (!OtobusBilgisiText)
        {
            break MISSING_BLOCK_LABEL_1450;
        }
        ((Button)findViewById(0x7f090040)).setVisibility(8);
        ((Button)findViewById(0x7f090041)).setVisibility(0);
_L23:
        CreateMarker("", 0x7f02001c, geopoint, null, "", "", "", "", "");
        flag = jsonobject.getString("yon").equals("0");
        k1 = 0;
        if (flag)
        {
            k1 = 0x7f020014;
        }
        if (jsonobject.getString("yon").equals("1"))
        {
            k1 = 0x7f020015;
        }
        if (jsonobject.getString("yon").equals("2"))
        {
            k1 = 0x7f020016;
        }
        if (jsonobject.getString("yon").equals("3"))
        {
            k1 = 0x7f020017;
        }
        if (jsonobject.getString("yon").equals("4"))
        {
            k1 = 0x7f020018;
        }
        if (jsonobject.getString("yon").equals("5"))
        {
            k1 = 0x7f020019;
        }
        if (jsonobject.getString("yon").equals("6"))
        {
            k1 = 0x7f02001a;
        }
        if (jsonobject.getString("yon").equals("7"))
        {
            k1 = 0x7f02001b;
        }
        String s4 = "";
        try
        {
            if (!jsonobject.getString("arac").equals(""))
            {
                s4 = (new StringBuilder("\nAra\347: ")).append(jsonobject.getString("arac")).toString();
            }
            String as[] = new String[6];
            as[0] = jsonobject.getString("kod");
            as[1] = jsonobject.getString("plaka");
            as[2] = jsonobject.getString("hiz");
            as[3] = jsonobject.getString("sure");
            as[4] = jsonobject.getString("sno");
            as[5] = jsonobject.getString("aciklama");
            CreateMarker("Otob\374s", k1, geopoint, as, "Otob\374s", (new StringBuilder("Ara\347 No: ")).append(jsonobject.getString("kod")).append("\n").append("Plaka: ").append(jsonobject.getString("plaka")).append("\n").append("H\u0131z: ").append(jsonobject.getString("hiz")).append("\n").append("T.V.S\374resi: ").append(jsonobject.getString("sure")).append("\n").append(jsonobject.getString("aciklama")).append(s4).toString(), "Otob\374s\374 Takip Et", "Otob\374s\374 Takip Etme", "");
            if (OtobusleriTakipEt || Yenile)
            {
                mc.setCenter(geopoint);
            }
            break MISSING_BLOCK_LABEL_1561;
        }
        catch (Exception exception4) { }
          goto _L16
        ((Button)findViewById(0x7f090040)).setVisibility(0);
        ((Button)findViewById(0x7f090041)).setVisibility(8);
          goto _L23
_L20:
        OtobusYenile(15000);
        return;
          goto _L16
_L19:
        Toast.makeText(getBaseContext(), "Hat \334zerinde \u015Eu Anda Otob\374s Yok!", 1).show();
        return;
_L4:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception3;
          goto _L24
        exception5;
        hashmap1;
          goto _L24
        exception2;
          goto _L25
        exception6;
        hashmap = hashmap3;
          goto _L25
        Exception exception2;
        Exception exception3;
        JSONObject jsonobject;
        GeoPoint geopoint;
        boolean flag;
        int k1;
        Exception exception5;
        Exception exception6;
        if (Global.App_Otobus_No.equals(jsonobject1.getString("kod")))
        {
            k = l;
        }
        l++;
          goto _L26
        i1++;
          goto _L27
    }

    public void CreateMarker(String s, int i, GeoPoint geopoint, String as[], String s1, String s2, String s3, 
            String s4, String s5)
    {
        MapOverlay mapoverlay = new MapOverlay(s, getResources().getDrawable(i), mv, as, s3, s4, s5);
        mapoverlay.addObserver(new MapOverlay.Callback() {

            final OtobusNeredeMap this$0;

            public void onButtonClick(String s6, OverlayItem overlayitem, String as1[], int j)
            {
                MarkerAction(s6, overlayitem, as1, j);
            }

            
            {
                this$0 = OtobusNeredeMap.this;
                super();
            }
        });
        mapoverlay.addOverlay(new OverlayItem(geopoint, s1, s2));
        lo.add(mapoverlay);
    }

    public void HatYenile()
    {
        String as[] = {
            "FNC", "Hat"
        };
        String as1[] = new String[4];
        as1[0] = "QUERY";
        as1[1] = Global.App_Hat_No;
        as1[2] = "YOL";
        as1[3] = "true";
        http = new Http("Hat", "hat.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final OtobusNeredeMap this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = OtobusNeredeMap.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void Isaretle(String s, GeoPoint geopoint, int i, String s1)
    {
        if (i > 0)
        {
            mc.setZoom(i);
        }
        Map.CloseBalloon(mv);
        if (location)
        {
            GeoPoint geopoint1;
            int j;
            HashMap hashmap;
            GeoPoint geopoint2;
            int k;
            int l;
            HashMap hashmap1;
            GeoPoint geopoint3;
            HashMap hashmap2;
            GeoPoint geopoint4;
            String as[];
            try
            {
                if (locationOverlay != -1)
                {
                    mv.getOverlays().remove(locationOverlay);
                    mv.invalidate();
                }
            }
            catch (Exception exception) { }
            mc.setCenter(locationPosition);
            CreateMarker("Location", 0x7f020067, locationPosition, null, "Konumum", (new StringBuilder(String.valueOf(locationAdres))).append("\n").append(locationIlce).toString(), "Yak\u0131ndaki Durak ve Hatlar", "", "");
            locationOverlay = -1 + lo.size();
        }
        if (!s.equals("Yol")) goto _L2; else goto _L1
_L1:
        new HashMap();
        geopoint1 = null;
        j = 0;
_L6:
        if (j < lstmapYol.size()) goto _L3; else goto _L2
_L2:
        if (!s.equals("Durak")) goto _L5; else goto _L4
_L4:
        new HashMap();
        k = -1;
        l = 0;
_L7:
        if (l < lstmapDurak.size())
        {
            break MISSING_BLOCK_LABEL_559;
        }
        if (k != -1)
        {
            hashmap2 = (HashMap)lstmapDurak.get(k);
            geopoint4 = Map.GP((new StringBuilder()).append((String)hashmap2.get("lat")).toString(), (new StringBuilder()).append((String)hashmap2.get("lng")).toString());
            if (IlkGoster)
            {
                mc.setCenter(geopoint4);
                BekledigimDurak = geopoint4;
            }
            CreateMarker("", 0x7f020022, geopoint4, null, "", "", "", "", "");
            as = new String[2];
            as[0] = (String)hashmap2.get("ad");
            as[1] = (String)hashmap2.get("yer");
            CreateMarker("Durak", 0x7f02001d, geopoint4, as, (new StringBuilder("B.Durak ")).append((String)hashmap2.get("ad")).toString(), (String)hashmap2.get("yer"), "Duraktan Ge\347en Hatlar", "", "Favorilerime Ekle");
        }
        IlkGoster = false;
        otobusOverlay = lo.size();
_L5:
        mv.invalidate();
        return;
_L3:
        hashmap = (HashMap)lstmapYol.get(j);
        geopoint2 = Map.GP((new StringBuilder()).append((String)hashmap.get("lat")).toString(), (new StringBuilder()).append((String)hashmap.get("lng")).toString());
        if (geopoint1 != null)
        {
            lo.add(new MapDraw("Line", geopoint1, geopoint2, Color.argb(60, 0, 0, 255), 5));
        }
        geopoint1 = geopoint2;
        j++;
          goto _L6
        hashmap1 = (HashMap)lstmapDurak.get(l);
        geopoint3 = Map.GP((new StringBuilder()).append((String)hashmap1.get("lat")).toString(), (new StringBuilder()).append((String)hashmap1.get("lng")).toString());
        if (IlkGoster && l == 0)
        {
            mc.setCenter(geopoint3);
        }
        if (Global.App_Durak_No.equals(hashmap1.get("ad")))
        {
            k = l;
        } else
        {
            lo.add(new MapDraw("Circle", geopoint3, 10, Color.argb(90, 0, 0, 255), Color.argb(90, 0, 0, 255), 5));
        }
        l++;
          goto _L7
    }

    public void Location()
    {
        gps = new Gps(this);
        gps.addObserver(new Gps.Callback() {

            final OtobusNeredeMap this$0;

            public void onComplete(Location location1)
            {
                Exception exception1;
                GeoPoint geopoint;
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location1 != null)
                {
                    break MISSING_BLOCK_LABEL_169;
                }
                Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                geopoint = Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString());
                locationAdres = "K\u0131z\u0131lay Meydan\u0131";
                locationIlce = "\307ankaya";
_L1:
                location = true;
                locationPosition = geopoint;
                Isaretle("Location", geopoint, 17, "");
                Toast.makeText(getBaseContext(), (new StringBuilder("Konumum\n\n")).append(locationAdres).append("\n").append(locationIlce).toString(), 1).show();
                return;
                try
                {
                    geopoint = Map.GP((new StringBuilder()).append(location1.getLatitude()).toString(), (new StringBuilder()).append(location1.getLongitude()).toString());
                    locationAdres = gps.GpsAdres;
                    locationIlce = gps.GpsIlce;
                }
                // Misplaced declaration of an exception variable
                catch (Exception exception1)
                {
                    return;
                }
                  goto _L1
            }

            
            {
                this$0 = OtobusNeredeMap.this;
                super();
            }
        });
        gps.Start();
    }

    public void MarkerAction(String s, OverlayItem overlayitem, String as[], int i)
    {
        Map.CloseBalloon(mv);
        if (s.equals("Location"))
        {
            Global.App_Adres_Query = "";
            Global.App_Adres_Adres = locationAdres;
            Global.App_Adres_Ilce = locationIlce;
            Global.App_Adres_Lat = (new StringBuilder()).append((double)locationPosition.getLatitudeE6() / 1000000D).toString();
            Global.App_Adres_Lng = (new StringBuilder()).append((double)locationPosition.getLongitudeE6() / 1000000D).toString();
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar), 0);
        }
        if (s.equals("Durak"))
        {
            if (i == 1)
            {
                Global.App_Favorilerim_Durak_No = as[0];
                Global.App_Favorilerim_Durak_Tanim = as[1];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar), 0);
            }
            if (i == 3)
            {
                Global.App_Favorilerim_Durak_Ekle = as[0];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimDurakDuzenle), 0);
            }
        }
        if (s.equals("Otob\374s"))
        {
            if (i == 1)
            {
                OtobusleriTakipEt = true;
            }
            if (i == 2)
            {
                OtobusleriTakipEt = false;
            }
            Global.App_Otobus_No = as[0];
            OtobusYenile(0);
        }
    }

    public void OtobusBilgisiText_OnClick(View view)
    {
        OtobusBilgisiText = false;
        ((Button)findViewById(0x7f090040)).setVisibility(0);
        ((Button)findViewById(0x7f090041)).setVisibility(8);
    }

    public void OtobusBilgisi_OnClick(View view)
    {
        if (((Button)findViewById(0x7f090041)).getVisibility() == 0)
        {
            OtobusBilgisiText = false;
            ((Button)findViewById(0x7f090040)).setVisibility(0);
            ((Button)findViewById(0x7f090041)).setVisibility(8);
            return;
        } else
        {
            OtobusBilgisiText = true;
            ((Button)findViewById(0x7f090040)).setVisibility(8);
            ((Button)findViewById(0x7f090041)).setVisibility(0);
            return;
        }
    }

    public void OtobusYenile(int i)
    {
        handlerStop();
        handlerRunnable = new Runnable() {

            final OtobusNeredeMap this$0;

            public void run()
            {
                try
                {
                    handler.removeCallbacks(handlerRunnable);
                }
                catch (Exception exception) { }
                if (handlerStatus)
                {
                    handlerStatus = false;
                    OtobusNeredeMap otobusneredemap = OtobusNeredeMap.this;
                    String as[] = {
                        "FNC", "OtobusAra"
                    };
                    String as1[] = new String[4];
                    as1[0] = "QUERY";
                    as1[1] = Global.App_Hat_No;
                    as1[2] = "DURAK";
                    as1[3] = Global.App_Durak_No;
                    otobusneredemap.http = new Http("OtobusAra", "hat.asp", as, as1);
                    http.addObserver(new Http.Callback() {

                        final _cls5 this$1;

                        public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
                        {
                            Action(s, s1, i, boolean1, s2);
                        }

            
            {
                this$1 = _cls5.this;
                super();
            }
                    });
                    http.execute(new String[0]);
                }
            }


            
            {
                this$0 = OtobusNeredeMap.this;
                super();
            }
        };
        if (i == 0)
        {
            handlerStatus = true;
            handler.postDelayed(handlerRunnable, 0L);
            return;
        } else
        {
            handlerStatus = true;
            handler.postDelayed(handlerRunnable, i);
            return;
        }
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final OtobusNeredeMap this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = OtobusNeredeMap.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void ToolBar_OnClick(View view)
    {
        String s;
        s = view.getTag().toString();
        if (!s.equals("0"))
        {
            handlerStop();
        }
        if (!s.equals("0")) goto _L2; else goto _L1
_L1:
        openOptionsMenu();
_L4:
        return;
_L2:
        if (s.equals("1"))
        {
            finish();
            return;
        }
        if (s.equals("2"))
        {
            Runnable("Location");
            return;
        }
        if (s.equals("3"))
        {
            mv.getController().zoomIn();
            return;
        }
        if (!s.equals("4"))
        {
            continue; /* Loop/switch isn't completed */
        }
        if (mv.getZoomLevel() < 12) goto _L4; else goto _L3
_L3:
        mv.getController().zoomOut();
        return;
        if (!s.equals("5") || BekledigimDurak == null) goto _L4; else goto _L5
_L5:
        if (mv.getZoomLevel() < 15)
        {
            mc.setZoom(17);
        }
        mc.setCenter(BekledigimDurak);
        Toast.makeText(getBaseContext(), "Bekledi\u011Fim Durak", 1).show();
        return;
    }

    public void Yenile_OnClick(View view)
    {
        Map.CloseBalloon(mv);
        try
        {
            Yenile = true;
            OtobusYenile(0);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public void handlerStop()
    {
        handlerStatus = false;
        try
        {
            handler.removeCallbacks(handlerRunnable);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    protected boolean isRouteDisplayed()
    {
        return false;
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        handlerStop();
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03002f);
        dialog = Tools.Waiting(this);
        mv = (MapView)findViewById(0x7f090003);
        mc = mv.getController();
        if (Global.Set_HaritaTipi.equals("Harita"))
        {
            mv.setSatellite(false);
        }
        if (Global.Set_HaritaTipi.equals("Uydu"))
        {
            mv.setSatellite(true);
        }
        mv.setBuiltInZoomControls(false);
        mc.setCenter(Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString()));
        mc.setZoom(zoom);
        Map.CloseBalloon(mv);
        mv.getOverlays().clear();
        lo = mv.getOverlays();
        lo.clear();
        locationOverlay = -1;
        otobusOverlay = -1;
        mv.setOnTouchListener(new android.view.View.OnTouchListener() {

            final OtobusNeredeMap this$0;

            public boolean onTouch(View view, MotionEvent motionevent)
            {
                if (motionevent.getAction() == 0)
                {
                    if (motionevent.getEventTime() - lastTouchDoubleTime < 250L)
                    {
                        mc.setZoom(1 + mv.getZoomLevel());
                        mv.invalidate();
                        lastTouchDoubleTime = -1L;
                        return true;
                    }
                    lastTouchDoubleTime = motionevent.getEventTime();
                }
                return false;
            }

            
            {
                this$0 = OtobusNeredeMap.this;
                super();
            }
        });
        HatYenile();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        menu.add(0, 3, 3, "Harita G\366r\374n\374m\374");
        menu.add(0, 4, 4, "Uydu G\366r\374n\374m\374");
        appMenu = menu;
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 4: default 36
    //                   1 42
    //                   2 55
    //                   3 62
    //                   4 73;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        continue; /* Loop/switch isn't completed */
_L4:
        mv.setSatellite(false);
        continue; /* Loop/switch isn't completed */
_L5:
        mv.setSatellite(true);
        if (true) goto _L1; else goto _L6
_L6:
    }

    public void onResume()
    {
        super.onResume();
        pageStatus = true;
    }

    protected void onStop()
    {
        pageStatus = false;
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        handlerStop();
        super.onStop();
    }
}
