// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            Http, Tools, Global

public class DuyurularDetay extends Activity
{

    ProgressDialog dialog;
    Http http;
    String link;

    public DuyurularDetay()
    {
        link = "";
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        Exception exception1;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200)
        {
            break MISSING_BLOCK_LABEL_164;
        }
        if (!s.equals("Ara"))
        {
            break MISSING_BLOCK_LABEL_147;
        }
        ((TextView)findViewById(0x7f09002c)).setText(http.JValue(0, "kategori"));
        ((TextView)findViewById(0x7f09002d)).setText(http.JValue(0, "tarih"));
        ((TextView)findViewById(0x7f09002e)).setText(http.JValue(0, "baslik"));
        ((TextView)findViewById(0x7f09002f)).setText(http.JValue(0, "detay"));
        link = http.JValue(0, "link");
        if (http.JValue(0, "kategori").equals(""))
        {
            finish();
        }
        return;
        exception1;
        Toast.makeText(getBaseContext(), "Duyuru Bulunamad\u0131!", 1).show();
        return;
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
    }

    public void Link_OnClick(View view)
    {
        if (!link.equals(""))
        {
            String s = link;
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(s));
            startActivity(intent);
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Duyurunun Detay\u0131 Bulunamad\u0131!", 1).show();
            return;
        }
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (!s.equals("2") && !s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030008);
        dialog = Tools.Waiting(this);
        String as[] = {
            "FNC", "Duyuru"
        };
        String as1[] = new String[2];
        as1[0] = "ID";
        as1[1] = Global.App_Duyuru_Id;
        http = new Http("Ara", "duyurular.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final DuyurularDetay this$0;

            public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
            {
                Action(s, s1, i, boolean1, s2);
            }

            
            {
                this$0 = DuyurularDetay.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
