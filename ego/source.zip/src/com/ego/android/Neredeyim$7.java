// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import com.google.android.maps.OverlayItem;

// Referenced classes of package com.ego.android:
//            Neredeyim

class this._cls0
    implements allback
{

    final Neredeyim this$0;

    public void onButtonClick(String s, OverlayItem overlayitem, String as[], int i)
    {
        MarkerAction(s, overlayitem, as, i);
    }

    layItem()
    {
        this$0 = Neredeyim.this;
        super();
    }
}
