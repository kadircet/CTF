// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import java.util.HashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.ego.android:
//            Global, Http, Map, MapDraw, 
//            MapOverlay, Gps, YakindakiDurakVeHatlar, DuraktanGecenHatlar, 
//            Tools

public class NasilGiderimMap extends MapActivity
{
    class Durak
    {

        String Ad;
        String Hat;
        String No;
        GeoPoint Point;
        String Yer;
        final NasilGiderimMap this$0;

        Durak()
        {
            this$0 = NasilGiderimMap.this;
            super();
            Point = null;
            No = "";
            Ad = "";
            Yer = "";
            Hat = "";
        }
    }


    ProgressDialog dialog;
    Durak durak[];
    int durakDolas;
    Gps gps;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    long lastTouchDoubleTime;
    List lo;
    boolean location;
    String locationAdres;
    String locationIlce;
    int locationOverlay;
    GeoPoint locationPosition;
    MapController mc;
    MapView mv;
    HashMap o;
    int zoom;

    public NasilGiderimMap()
    {
        lastTouchDoubleTime = -1L;
        location = false;
        locationAdres = "";
        locationIlce = "";
        locationOverlay = -1;
        handler = new Handler();
        handlerStatus = false;
        durak = new Durak[4];
        durakDolas = -1;
        zoom = Integer.parseInt(Global.Set_Yaklasim);
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        String s3;
        Exception exception1;
        Exception exception2;
        JSONArray jsonarray;
        byte byte0;
        int j;
        JSONObject jsonobject;
        String as[];
        GeoPoint geopoint;
        int l;
        GeoPoint geopoint1;
        String s4;
        Exception exception3;
        Exception exception4;
        JSONArray jsonarray1;
        byte byte1;
        int j1;
        int k1;
        String as2[];
        GeoPoint geopoint2;
        int l1;
        int i2;
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Hat1")) goto _L4; else goto _L3
_L3:
        s4 = http.JValue(0, "kod");
        as2 = http.JValue(0, "yol").split(" ");
        geopoint2 = null;
        l1 = 0;
_L15:
        i2 = as2.length;
        if (l1 < i2) goto _L6; else goto _L5
_L5:
        jsonarray1 = http.JArray(0, "durak");
        byte1 = -1;
        j1 = 0;
_L16:
        k1 = jsonarray1.length();
        if (j1 < k1) goto _L8; else goto _L7
_L7:
        mv.invalidate();
        int k;
        int i1;
        JSONObject jsonobject1;
        String as3[];
        GeoPoint geopoint3;
        if (!((String)o.get("kod")).equals(o.get("vkod")))
        {
            HatYenile("2", (String)o.get("vkod"));
        } else
        {
            Isaretle("Noktalar", null, zoom, "");
        }
_L4:
        if (!s.equals("Hat2")) goto _L10; else goto _L9
_L9:
        s3 = http.JValue(0, "kod");
        as = http.JValue(0, "yol").split(" ");
        geopoint = null;
        l = 0;
_L17:
        i1 = as.length;
        if (l < i1) goto _L12; else goto _L11
_L11:
        jsonarray = http.JArray(0, "durak");
        byte0 = -1;
        j = 0;
_L18:
        k = jsonarray.length();
        if (j < k) goto _L14; else goto _L13
_L13:
        mv.invalidate();
        Isaretle("Noktalar", null, zoom, "");
_L10:
        return;
_L6:
        as3 = as2[l1].split(",");
        geopoint3 = Map.GP(as3[1], as3[0]);
        if (geopoint2 == null)
        {
            break MISSING_BLOCK_LABEL_327;
        }
        lo.add(new MapDraw("Line", geopoint2, geopoint3, Color.argb(60, 0, 0, 255), 5));
        geopoint2 = geopoint3;
        l1++;
          goto _L15
_L8:
        jsonobject1 = jsonarray1.getJSONObject(j1);
        lo.add(new MapDraw("Circle", Map.GP(jsonobject1.getString("lat"), jsonobject1.getString("lng")), 10, Color.argb(90, 0, 0, 255), Color.argb(90, 0, 0, 255), 5));
        if (jsonobject1.getString("sno").equals(o.get("durakbin")))
        {
            byte1 = 0;
        }
        if (jsonobject1.getString("sno").equals(o.get("durakin")))
        {
            byte1 = 1;
        }
        if (byte1 < 0)
        {
            break MISSING_BLOCK_LABEL_565;
        }
        durak[byte1] = new Durak();
        durak[byte1].Point = Map.GP(jsonobject1.getString("lat"), jsonobject1.getString("lng"));
        durak[byte1].No = jsonobject1.getString("sno");
        durak[byte1].Ad = jsonobject1.getString("ad");
        durak[byte1].Yer = jsonobject1.getString("yer");
        durak[byte1].Hat = s4;
        byte1 = -1;
        j1++;
          goto _L16
_L12:
        String as1[] = as[l].split(",");
        geopoint1 = Map.GP(as1[1], as1[0]);
        if (geopoint == null)
        {
            break MISSING_BLOCK_LABEL_654;
        }
        lo.add(new MapDraw("Line", geopoint, geopoint1, Color.argb(60, 255, 0, 0), 5));
        geopoint = geopoint1;
        l++;
          goto _L17
_L14:
        jsonobject = jsonarray.getJSONObject(j);
        lo.add(new MapDraw("Circle", Map.GP(jsonobject.getString("lat"), jsonobject.getString("lng")), 10, Color.argb(90, 255, 0, 0), Color.argb(90, 255, 0, 0), 5));
        if (jsonobject.getString("sno").equals(o.get("vdurakbin")))
        {
            byte0 = 2;
        }
        if (jsonobject.getString("sno").equals(o.get("vdurakin")))
        {
            byte0 = 3;
        }
        if (byte0 < 0)
        {
            break MISSING_BLOCK_LABEL_892;
        }
        durak[byte0] = new Durak();
        durak[byte0].Point = Map.GP(jsonobject.getString("lat"), jsonobject.getString("lng"));
        durak[byte0].No = jsonobject.getString("sno");
        durak[byte0].Ad = jsonobject.getString("ad");
        durak[byte0].Yer = jsonobject.getString("yer");
        durak[byte0].Hat = s3;
        byte0 = -1;
        j++;
          goto _L18
_L2:
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
        exception2;
          goto _L13
        exception1;
          goto _L11
        exception4;
          goto _L7
        exception3;
          goto _L5
    }

    public void CreateMarker(String s, int i, GeoPoint geopoint, String as[], String s1, String s2, String s3, 
            String s4, String s5)
    {
        MapOverlay mapoverlay = new MapOverlay(s, getResources().getDrawable(i), mv, as, s3, s4, s5);
        mapoverlay.addObserver(new MapOverlay.Callback() {

            final NasilGiderimMap this$0;

            public void onButtonClick(String s6, OverlayItem overlayitem, String as1[], int j)
            {
                MarkerAction(s6, overlayitem, as1, j);
            }

            
            {
                this$0 = NasilGiderimMap.this;
                super();
            }
        });
        mapoverlay.addOverlay(new OverlayItem(geopoint, s1, s2));
        lo.add(mapoverlay);
    }

    public void Dolas_OnClick(View view)
    {
        GeoPoint geopoint;
        String s;
        geopoint = new GeoPoint(0, 0);
        s = "";
        durakDolas = 1 + durakDolas;
        if (durakDolas == 0)
        {
            geopoint = Map.GP((new StringBuilder()).append(Global.App_Nereden_Lat).toString(), (new StringBuilder()).append(Global.App_Nereden_Lng).toString());
            s = (new StringBuilder("Nereden ?\n\n")).append(Global.App_Nereden_Adres).append("\n").append(Global.App_Nereden_Ilce).toString();
        }
        if (durakDolas == 1)
        {
            geopoint = durak[0].Point;
            s = (new StringBuilder("1.Ad\u0131m > Binin\n\n")).append(durak[0].Hat).append(" Nolu Hatt\u0131n\nBu Dura\u011F\u0131ndan Binin\n\n").append("Durak ").append(durak[0].Ad).append(" (").append(durak[0].No).append(")").append("\n\n").append(durak[0].Yer).toString();
        }
        if (durakDolas == 2)
        {
            geopoint = durak[1].Point;
            s = (new StringBuilder("2.Ad\u0131m > \u0130nin\n\n")).append(durak[1].Hat).append(" Nolu Hatt\u0131n\nBu Dura\u011F\u0131nda \u0130nin\n\n").append("Durak ").append(durak[1].Ad).append(" (").append(durak[1].No).append(")").append("\n\n").append(durak[1].Yer).toString();
        }
        if (!((String)o.get("kod")).equals(o.get("vkod"))) goto _L2; else goto _L1
_L1:
        if (durakDolas == 3)
        {
            geopoint = Map.GP((new StringBuilder()).append(Global.App_Nereye_Lat).toString(), (new StringBuilder()).append(Global.App_Nereye_Lng).toString());
            s = (new StringBuilder("Nereye ?\n\n")).append(Global.App_Nereye_Adres).append("\n").append(Global.App_Nereye_Ilce).toString();
            durakDolas = -1;
        }
_L4:
        mc.setCenter(geopoint);
        mc.setZoom(17);
        Toast.makeText(getBaseContext(), s, 1).show();
        return;
_L2:
        if (durakDolas == 3)
        {
            geopoint = durak[2].Point;
            s = (new StringBuilder("3.Ad\u0131m > Binin\n\n")).append(durak[2].Hat).append(" Nolu Hatt\u0131n\nBu Dura\u011F\u0131ndan Binin\n\n").append("Durak ").append(durak[2].Ad).append(" (").append(durak[2].No).append(")").append("\n\n").append(durak[2].Yer).toString();
        }
        if (durakDolas == 4)
        {
            geopoint = durak[3].Point;
            s = (new StringBuilder("4.Ad\u0131m > \u0130nin\n\n")).append(durak[3].Hat).append(" Nolu Hatt\u0131n\nBu Dura\u011F\u0131nda \u0130nin\n\n").append("Durak ").append(durak[3].Ad).append(" (").append(durak[3].No).append(")").append("\n\n").append(durak[3].Yer).toString();
        }
        if (durakDolas == 5)
        {
            geopoint = Map.GP((new StringBuilder()).append(Global.App_Nereye_Lat).toString(), (new StringBuilder()).append(Global.App_Nereye_Lng).toString());
            s = (new StringBuilder("Nereye ?\n\n")).append(Global.App_Nereye_Adres).append("\n").append(Global.App_Nereye_Ilce).toString();
            durakDolas = -1;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public void HatYenile(String s, String s1)
    {
        http = new Http((new StringBuilder("Hat")).append(s).toString(), "hat.asp", new String[] {
            "FNC", "Hat"
        }, new String[] {
            "QUERY", s1, "YOL", "true"
        });
        http.addObserver(new Http.Callback() {

            final NasilGiderimMap this$0;

            public void onComplete(String s2, String s3, int i, Boolean boolean1, String s4)
            {
                Action(s2, s3, i, boolean1, s4);
            }

            
            {
                this$0 = NasilGiderimMap.this;
                super();
            }
        });
        dialog.show();
        http.execute(new String[0]);
    }

    public void Isaretle(String s, GeoPoint geopoint, int i, String s1)
    {
        if (i > 0)
        {
            mc.setZoom(i);
        }
        Map.CloseBalloon(mv);
        if (s.equals("Noktalar"))
        {
            GeoPoint geopoint1 = Map.GP((new StringBuilder()).append(Global.App_Nereden_Lat).toString(), (new StringBuilder()).append(Global.App_Nereden_Lng).toString());
            lo.add(new MapDraw("Circle", geopoint1, 50, Color.argb(60, 0, 0, 0), Color.argb(60, 255, 255, 0), 10));
            String as[] = new String[4];
            as[0] = Global.App_Nereden_Adres;
            as[1] = Global.App_Nereden_Ilce;
            as[2] = Global.App_Nereden_Lat;
            as[3] = Global.App_Nereden_Lng;
            CreateMarker("Nereden", 0x7f02001e, geopoint1, as, "Nereden ?", (new StringBuilder(String.valueOf(Global.App_Nereden_Adres))).append("\n").append(Global.App_Nereden_Ilce).toString(), "Yak\u0131ndaki Durak ve Hatlar", "", "");
            mc.setCenter(geopoint1);
            mc.setZoom(i);
            GeoPoint geopoint2 = Map.GP((new StringBuilder()).append(Global.App_Nereye_Lat).toString(), (new StringBuilder()).append(Global.App_Nereye_Lng).toString());
            lo.add(new MapDraw("Circle", geopoint2, 50, Color.argb(60, 0, 0, 0), Color.argb(60, 255, 255, 0), 10));
            String as1[] = new String[4];
            as1[0] = Global.App_Nereye_Adres;
            as1[1] = Global.App_Nereye_Ilce;
            as1[2] = Global.App_Nereye_Lat;
            as1[3] = Global.App_Nereye_Lng;
            CreateMarker("Nereye", 0x7f020035, geopoint2, as1, "Nereye ?", (new StringBuilder(String.valueOf(Global.App_Nereye_Adres))).append("\n").append(Global.App_Nereye_Ilce).toString(), "Yak\u0131ndaki Durak ve Hatlar", "", "");
            lo.add(new MapDraw("Circle", durak[0].Point, 50, Color.argb(60, 0, 0, 255), Color.argb(60, 255, 0, 0), 10));
            GeoPoint geopoint3 = durak[0].Point;
            String as2[] = new String[2];
            as2[0] = durak[0].Ad;
            as2[1] = durak[0].Yer;
            CreateMarker("Durak", 0x7f02001d, geopoint3, as2, "1.Ad\u0131m > Binin", (new StringBuilder(String.valueOf(durak[0].Hat))).append(" Nolu Hatt\u0131n\nBu Dura\u011F\u0131ndan Binin\n\n").append("Durak ").append(durak[0].Ad).append(" (").append(durak[0].No).append(")").append("\n\n").append(durak[0].Yer).toString(), "Duraktan Ge\347en Hatlar", "", "");
            lo.add(new MapDraw("Circle", durak[1].Point, 50, Color.argb(60, 0, 0, 255), Color.argb(60, 255, 0, 0), 10));
            GeoPoint geopoint4 = durak[1].Point;
            String as3[] = new String[2];
            as3[0] = durak[1].Ad;
            as3[1] = durak[1].Yer;
            CreateMarker("Durak", 0x7f02001d, geopoint4, as3, "2.Ad\u0131m > \u0130nin", (new StringBuilder(String.valueOf(durak[1].Hat))).append(" Nolu Hatt\u0131n\nBu Dura\u011F\u0131nda \u0130nin\n\n").append("Durak ").append(durak[1].Ad).append(" (").append(durak[1].No).append(")").append("\n\n").append(durak[1].Yer).toString(), "Duraktan Ge\347en Hatlar", "", "");
            if (!((String)o.get("kod")).equals(o.get("vkod")))
            {
                lo.add(new MapDraw("Circle", durak[2].Point, 50, Color.argb(60, 255, 0, 0), Color.argb(60, 0, 0, 255), 10));
                GeoPoint geopoint5 = durak[2].Point;
                String as4[] = new String[2];
                as4[0] = durak[2].Ad;
                as4[1] = durak[2].Yer;
                CreateMarker("Durak", 0x7f020020, geopoint5, as4, "3.Ad\u0131m > Binin", (new StringBuilder(String.valueOf(durak[2].Hat))).append(" Nolu Hatt\u0131n\nBu Dura\u011F\u0131ndan Binin\n\n").append("Durak ").append(durak[2].Ad).append(" (").append(durak[2].No).append(")").append("\n\n").append(durak[2].Yer).toString(), "Duraktan Ge\347en Hatlar", "", "");
                lo.add(new MapDraw("Circle", durak[3].Point, 50, Color.argb(60, 255, 0, 0), Color.argb(60, 0, 0, 255), 10));
                GeoPoint geopoint6 = durak[3].Point;
                String as5[] = new String[2];
                as5[0] = durak[3].Ad;
                as5[1] = durak[3].Yer;
                CreateMarker("Durak", 0x7f020020, geopoint6, as5, "4.Ad\u0131m > \u0130nin", (new StringBuilder(String.valueOf(durak[3].Hat))).append(" Nolu Hatt\u0131n\nBu Dura\u011F\u0131nda \u0130nin\n\n").append("Durak ").append(durak[3].Ad).append(" (").append(durak[3].No).append(")").append("\n\n").append(durak[3].Yer).toString(), "Duraktan Ge\347en Hatlar", "", "");
            }
        }
        if (location)
        {
            try
            {
                if (locationOverlay != -1)
                {
                    mv.getOverlays().remove(locationOverlay);
                    mv.invalidate();
                }
            }
            catch (Exception exception) { }
            mc.setCenter(locationPosition);
            CreateMarker("Location", 0x7f020067, locationPosition, null, "Konumum", (new StringBuilder(String.valueOf(locationAdres))).append("\n").append(locationIlce).toString(), "Yak\u0131ndaki Durak ve Hatlar", "", "");
            locationOverlay = -1 + lo.size();
        }
        mv.invalidate();
    }

    public void Location()
    {
        gps = new Gps(this);
        gps.addObserver(new Gps.Callback() {

            final NasilGiderimMap this$0;

            public void onComplete(Location location1)
            {
                Exception exception1;
                GeoPoint geopoint;
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location1 != null)
                {
                    break MISSING_BLOCK_LABEL_169;
                }
                Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                geopoint = Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString());
                locationAdres = "K\u0131z\u0131lay Meydan\u0131";
                locationIlce = "\307ankaya";
_L1:
                location = true;
                locationPosition = geopoint;
                Isaretle("Location", geopoint, 17, "");
                Toast.makeText(getBaseContext(), (new StringBuilder("Konumum\n\n")).append(locationAdres).append("\n").append(locationIlce).toString(), 1).show();
                return;
                try
                {
                    geopoint = Map.GP((new StringBuilder()).append(location1.getLatitude()).toString(), (new StringBuilder()).append(location1.getLongitude()).toString());
                    locationAdres = gps.GpsAdres;
                    locationIlce = gps.GpsIlce;
                }
                // Misplaced declaration of an exception variable
                catch (Exception exception1)
                {
                    return;
                }
                  goto _L1
            }

            
            {
                this$0 = NasilGiderimMap.this;
                super();
            }
        });
        gps.Start();
    }

    public void MarkerAction(String s, OverlayItem overlayitem, String as[], int i)
    {
        if (s.equals("Location"))
        {
            Global.App_Adres_Query = "";
            Global.App_Adres_Adres = locationAdres;
            Global.App_Adres_Ilce = locationIlce;
            Global.App_Adres_Lat = (new StringBuilder()).append((double)locationPosition.getLatitudeE6() / 1000000D).toString();
            Global.App_Adres_Lng = (new StringBuilder()).append((double)locationPosition.getLongitudeE6() / 1000000D).toString();
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar), 0);
        }
        if ((s.equals("Nereden") || s.equals("Nereye")) && i == 1)
        {
            Global.App_Adres_Query = "";
            Global.App_Adres_Adres = as[0];
            Global.App_Adres_Ilce = as[1];
            Global.App_Adres_Lat = (new StringBuilder()).append(as[2]).toString();
            Global.App_Adres_Lng = (new StringBuilder()).append(as[3]).toString();
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar), 0);
        }
        if (s.equals("Durak") && i == 1)
        {
            Global.App_Favorilerim_Durak_No = as[0];
            Global.App_Favorilerim_Durak_Tanim = as[1];
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar), 0);
        }
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final NasilGiderimMap this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = NasilGiderimMap.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (s.equals("2"))
            {
                Runnable("Location");
                return;
            }
            if (s.equals("3"))
            {
                mv.getController().zoomIn();
                return;
            }
            if (s.equals("4") && mv.getZoomLevel() >= 12)
            {
                mv.getController().zoomOut();
                return;
            }
        }
    }

    protected boolean isRouteDisplayed()
    {
        return false;
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f03002a);
        dialog = Tools.Waiting(this);
        mv = (MapView)findViewById(0x7f090003);
        mc = mv.getController();
        if (Global.Set_HaritaTipi.equals("Harita"))
        {
            mv.setSatellite(false);
        }
        if (Global.Set_HaritaTipi.equals("Uydu"))
        {
            mv.setSatellite(true);
        }
        mv.setBuiltInZoomControls(false);
        mc.setCenter(Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString()));
        mc.setZoom(zoom);
        lo = mv.getOverlays();
        mv.setOnTouchListener(new android.view.View.OnTouchListener() {

            final NasilGiderimMap this$0;

            public boolean onTouch(View view, MotionEvent motionevent)
            {
                if (motionevent.getAction() == 0)
                {
                    if (motionevent.getEventTime() - lastTouchDoubleTime < 250L)
                    {
                        mc.setZoom(1 + mv.getZoomLevel());
                        mv.invalidate();
                        lastTouchDoubleTime = -1L;
                        return true;
                    }
                    lastTouchDoubleTime = motionevent.getEventTime();
                }
                return false;
            }

            
            {
                this$0 = NasilGiderimMap.this;
                super();
            }
        });
        o = Global.App_NasilGiderim;
        ((TextView)findViewById(0x7f090060)).setText((new StringBuilder(String.valueOf((String)o.get("kod")))).append(" - ").append((String)o.get("ad")).toString());
        if (!((String)o.get("kod")).equals(o.get("vkod")))
        {
            ((TextView)findViewById(0x7f090061)).setText((new StringBuilder(String.valueOf((String)o.get("vkod")))).append(" - ").append((String)o.get("vad")).toString());
            ((TextView)findViewById(0x7f090061)).setVisibility(0);
        }
        HatYenile("1", (String)o.get("kod"));
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        menu.add(0, 3, 3, "Harita G\366r\374n\374m\374");
        menu.add(0, 4, 4, "Uydu G\366r\374n\374m\374");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 4: default 36
    //                   1 42
    //                   2 55
    //                   3 62
    //                   4 73;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        continue; /* Loop/switch isn't completed */
_L4:
        mv.setSatellite(false);
        continue; /* Loop/switch isn't completed */
_L5:
        mv.setSatellite(true);
        if (true) goto _L1; else goto _L6
_L6:
    }

    protected void onStop()
    {
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        super.onStop();
    }
}
