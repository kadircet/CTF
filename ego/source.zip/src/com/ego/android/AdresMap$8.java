// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Dialog;
import android.view.View;
import android.widget.Button;

// Referenced classes of package com.ego.android:
//            AdresMap, Global

class val.dialogBox
    implements android.view.kListener
{

    final AdresMap this$0;
    private final Dialog val$dialogBox;

    public void onClick(View view)
    {
        String as[] = ((Button)view).getTag().toString().toString().split(";");
        val$dialogBox.dismiss();
        Global.Set_Yakinlik = as[1];
        Isaretle("Konum", konumPosition, 17 - Integer.parseInt(as[0]), "");
    }

    stener()
    {
        this$0 = final_adresmap;
        val$dialogBox = Dialog.this;
        super();
    }
}
