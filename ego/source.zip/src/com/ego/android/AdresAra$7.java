// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            AdresAra, Global, YakindakiDuraklar, YakindakiDurakVeHatlar

class this._cls0
    implements android.widget..OnItemClickListener
{

    final AdresAra this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        HashMap hashmap = (HashMap)((ListView)findViewById(0x7f090002)).getItemAtPosition(i);
        Global.App_Adres_Adres = (String)hashmap.get("adres");
        Global.App_Adres_Ilce = (String)hashmap.get("ilce");
        Global.App_Adres_Lat = (String)hashmap.get("lat");
        Global.App_Adres_Lng = (String)hashmap.get("lng");
        Boolean boolean1 = Boolean.valueOf(((CheckBox)findViewById(0x7f090001)).isChecked());
        if (Global.App_Adres_Sec.equals("AdresAra") && !Global.App_Adres_Status.equals("Menu"))
        {
            Intent intent2 = new Intent();
            setResult(10, intent2);
            finish();
            return;
        }
        if (boolean1.booleanValue())
        {
            Global.App_Adres_Query = Global.App_Adres_Ara;
            Intent intent1 = new Intent(getBaseContext(), com/ego/android/YakindakiDuraklar);
            startActivityForResult(intent1, 0);
            return;
        } else
        {
            Global.App_Adres_Query = "";
            Intent intent = new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar);
            startActivityForResult(intent, 0);
            return;
        }
    }

    rakVeHatlar()
    {
        this$0 = AdresAra.this;
        super();
    }
}
