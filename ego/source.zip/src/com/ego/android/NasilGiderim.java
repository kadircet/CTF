// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            Global, AdresAra, Gps, Map, 
//            NasilGiderimListe, Tools, Http

public class NasilGiderim extends Activity
{

    String AdresAra;
    String LocationAra;
    ProgressDialog dialog;
    Gps gps;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;

    public NasilGiderim()
    {
        handler = new Handler();
        handlerStatus = false;
        AdresAra = "";
        LocationAra = "";
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i == 200)
        {
            s.equals("");
            return;
        } else
        {
            Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
            return;
        }
    }

    public void Adres_OnClick(View view)
    {
        AdresAra = ((LinearLayout)view).getTag().toString();
        Global.App_Adres_Sec = "AdresAra";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/AdresAra), 0);
    }

    public void ListImage_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        String as[];
        try
        {
            as = s.split(";");
            if (as.length > 1)
            {
                Toast.makeText(getBaseContext(), (new StringBuilder(String.valueOf(as[0]))).append(" ").append(as[1]).toString(), 1).show();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getBaseContext(), as[0], 1).show();
        return;
    }

    public void Location()
    {
        gps = new Gps(this);
        gps.addObserver(new Gps.Callback() {

            final NasilGiderim this$0;

            public void onComplete(Location location)
            {
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location == null)
                {
                    try
                    {
                        Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                        return;
                    }
                    catch (Exception exception1)
                    {
                        return;
                    }
                }
                if (!gps.GpsAdres.equals(""))
                {
                    break MISSING_BLOCK_LABEL_97;
                }
                Toast.makeText(getBaseContext(), "Adres Bulunamad\u0131!", 1).show();
                NeredenNereye(LocationAra, "", "", "", "");
_L2:
                LocationAra = "";
                return;
                NeredenNereye(LocationAra, gps.GpsAdres, gps.GpsIlce, (new StringBuilder()).append(gps.GpsLat).toString(), (new StringBuilder()).append(gps.GpsLng).toString());
                if (true) goto _L2; else goto _L1
_L1:
            }

            
            {
                this$0 = NasilGiderim.this;
                super();
            }
        });
        gps.Start();
    }

    public void Location_OnClick(View view)
    {
        LocationAra = ((ImageButton)view).getTag().toString();
        Runnable("Location");
    }

    public void NeredenNereye(String s, String s1, String s2, String s3, String s4)
    {
        String s5;
        double d;
        if (s.equals("Nereden"))
        {
            String s6;
            if (s1.equals(""))
            {
                ((TextView)findViewById(0x7f090059)).setText("- Adres Se\347iniz -");
            } else
            {
                ((TextView)findViewById(0x7f090059)).setText((new StringBuilder(String.valueOf(s1))).append("\n").append(s2).toString());
            }
            Global.App_Nereden_Adres = s1;
            Global.App_Nereden_Ilce = s2;
            Global.App_Nereden_Lat = s3;
            Global.App_Nereden_Lng = s4;
        }
        if (s.equals("Nereye"))
        {
            if (s1.equals(""))
            {
                ((TextView)findViewById(0x7f09005a)).setText("- Adres Se\347iniz -");
            } else
            {
                ((TextView)findViewById(0x7f09005a)).setText((new StringBuilder(String.valueOf(s1))).append("\n").append(s2).toString());
            }
            Global.App_Nereye_Adres = s1;
            Global.App_Nereye_Ilce = s2;
            Global.App_Nereye_Lat = s3;
            Global.App_Nereye_Lng = s4;
        }
        s5 = "2 Nokta Aras\u0131ndaki Mesafe";
        if (Global.App_Nereden_Adres.equals("") || Global.App_Nereye_Adres.equals("")) goto _L2; else goto _L1
_L1:
        d = Map.Distance(Global.App_Nereden_Lat, Global.App_Nereden_Lng, Global.App_Nereye_Lat, Global.App_Nereye_Lng);
        if (d < 1000D) goto _L4; else goto _L3
_L3:
        s6 = (new StringBuilder(String.valueOf(s5))).append(" Yakla\u015F\u0131k ").append(Math.round(d / 1000D)).append(" Km").toString();
        s5 = s6;
_L2:
        ((TextView)findViewById(0x7f09003c)).setText(s5);
        return;
_L4:
        if (d >= 250D)
        {
            String s7;
            try
            {
                s5 = (new StringBuilder(String.valueOf(s5))).append(" Yakla\u015F\u0131k ").append(Math.round(d / 1.0D)).append(" Metre").toString();
            }
            catch (Exception exception) { }
            continue; /* Loop/switch isn't completed */
        }
        s7 = (new StringBuilder(String.valueOf(s5))).append(" \307ok Yak\u0131n").toString();
        s5 = s7;
        if (true) goto _L2; else goto _L5
_L5:
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final NasilGiderim this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = NasilGiderim.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void Sorgula_OnClick(View view)
    {
        if (Global.App_Nereden_Adres.equals(""))
        {
            Toast.makeText(getBaseContext(), "Nereden ? Adres Se\347imi Yap\u0131lmad\u0131!", 1).show();
            return;
        }
        if (Global.App_Nereye_Adres.equals(""))
        {
            Toast.makeText(getBaseContext(), "Nereye ? Adres Se\347imi Yap\u0131lmad\u0131!", 1).show();
            return;
        }
        if (((Spinner)findViewById(0x7f09005b)).getSelectedItem().toString().equals("En K\u0131sa Mesafe"))
        {
            Global.App_NasilGiderim_Siralama = "Mesafe";
        } else
        {
            Global.App_NasilGiderim_Siralama = "S\374re";
        }
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/NasilGiderimListe), 0);
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (!s.equals("2") && !s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
        if (Global.App_Adres_Sec.equals("AdresAra"))
        {
            if (j == 10)
            {
                if (!Global.App_Adres_Lat.equals("") && !Global.App_Adres_Lng.equals(""))
                {
                    NeredenNereye(AdresAra, Global.App_Adres_Adres, Global.App_Adres_Ilce, (new StringBuilder()).append(Global.App_Adres_Lat).toString(), (new StringBuilder()).append(Global.App_Adres_Lng).toString());
                } else
                {
                    NeredenNereye(AdresAra, "", "", "", "");
                }
            }
            AdresAra = "";
            Global.App_Adres_Sec = "";
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030027);
        dialog = Tools.Waiting(this);
        Spinner spinner = (Spinner)findViewById(0x7f09005b);
        ArrayAdapter arrayadapter = new ArrayAdapter(this, 0x1090008, new String[] {
            "En K\u0131sa Mesafe", "En K\u0131sa S\374re"
        });
        arrayadapter.setDropDownViewResource(0x1090009);
        spinner.setAdapter(arrayadapter);
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        super.onStop();
    }
}
