// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;


// Referenced classes of package com.ego.android:
//            R

public static final class 
{

    public static final int action_settings = 0x7f060002;
    public static final int app_name = 0x7f060000;
    public static final int title_activity_main = 0x7f060001;

    public ()
    {
    }
}
