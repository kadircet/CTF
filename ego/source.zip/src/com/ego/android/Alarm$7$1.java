// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Handler;
import android.text.Editable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            Alarm, Global, Http

class this._cls1
    implements ack
{

    final on this$1;

    public void onComplete(String s, String s1, int i, Boolean boolean1, String s2)
    {
        Action(s, s1, i, boolean1, s2);
    }

    is._cls0()
    {
        this$1 = this._cls1.this;
        super();
    }

    // Unreferenced inner class com/ego/android/Alarm$7

/* anonymous class */
    class Alarm._cls7
        implements Runnable
    {

        final Alarm this$0;

        public void run()
        {
label0:
            {
label1:
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception) { }
                    if (Global.App_Alarm_Acik)
                    {
                        if (!handlerStatus)
                        {
                            break label0;
                        }
                        String s = ((EditText)findViewById(0x7f090007)).getText().toString();
                        String s1 = ((EditText)findViewById(0x7f090009)).getText().toString();
                        handlerStatus = false;
                        if (!s.equals(""))
                        {
                            ((LinearLayout)findViewById(0x7f09000f)).setVisibility(8);
                        } else
                        {
                            ((LinearLayout)findViewById(0x7f09000f)).setVisibility(0);
                        }
                        if (s1.equals(""))
                        {
                            break label1;
                        }
                        if (!s.equals(""))
                        {
                            http = new Http("OtobusAra", "hat.asp", new String[] {
                                "FNC", "OtobusAra"
                            }, new String[] {
                                "QUERY", s, "DURAK", s1, "TYPE", "true"
                            });
                        } else
                        {
                            http = new Http("OtobusDurakAra", "durak.asp", new String[] {
                                "FNC", "DurakAra"
                            }, new String[] {
                                "QUERY", s1, "HATNO", s, "TYPE", "true"
                            });
                        }
                        http.addObserver(new Alarm._cls7._cls1());
                        dialog.show();
                        http.execute(new String[0]);
                        ((Button)findViewById(0x7f090011)).setBackgroundColor(Color.parseColor("#FF009900"));
                    }
                    return;
                }
                Toast.makeText(getBaseContext(), "Durak Numaras\u0131n\u0131 Giriniz!", 1).show();
                return;
            }
            handlerStop();
        }


            
            {
                this$0 = Alarm.this;
                super();
            }
    }

}
