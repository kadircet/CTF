// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Point;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import com.google.android.maps.Projection;
import java.util.List;
import org.json.JSONArray;

// Referenced classes of package com.ego.android:
//            Global, Http, Map, MapOverlay, 
//            MapDraw, Gps, YakindakiDurakVeHatlar, DuraktanGecenHatlar, 
//            OtobusNerede, FavorilerimDurakDuzenle, Tools

public class KonumMap extends MapActivity
{

    ProgressDialog dialog;
    Gps gps;
    Handler handler;
    Runnable handlerRunnable;
    boolean handlerStatus;
    Http http;
    boolean konum;
    String konumAdres;
    String konumAdresSlc;
    String konumBaslik;
    String konumDurakNo;
    String konumDurakTanim;
    String konumIlce;
    String konumIlceSlc;
    GeoPoint konumPosition;
    GeoPoint konumPositionSlc;
    boolean konumSlc;
    long lastTouchDoubleTime;
    Point lastTouchPositon;
    long lastTouchTime;
    List lo;
    boolean location;
    String locationAdres;
    String locationIlce;
    GeoPoint locationPosition;
    MapController mc;
    MapView mv;
    int zoom;

    public KonumMap()
    {
        lastTouchTime = -1L;
        lastTouchDoubleTime = -1L;
        lastTouchPositon = new Point(0, 0);
        location = false;
        locationAdres = "";
        locationIlce = "";
        konum = false;
        konumBaslik = "";
        konumAdres = "";
        konumIlce = "";
        konumDurakNo = "";
        konumDurakTanim = "";
        konumSlc = false;
        konumAdresSlc = "";
        konumIlceSlc = "";
        handler = new Handler();
        handlerStatus = false;
        zoom = Integer.parseInt(Global.Set_Yaklasim);
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        int j;
        Exception exception1;
        GeoPoint geopoint;
        String as[];
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (i != 200)
        {
            break MISSING_BLOCK_LABEL_231;
        }
        if (!s.equals("YakinDuraklar"))
        {
            break MISSING_BLOCK_LABEL_253;
        }
        j = 0;
        try
        {
            if (j >= http.jArray.length())
            {
                mv.invalidate();
                return;
            }
        }
        // Misplaced declaration of an exception variable
        catch (Exception exception1)
        {
            return;
        }
        geopoint = Map.GP((new StringBuilder()).append(http.JValue(j, "lat")).toString(), (new StringBuilder()).append(http.JValue(j, "lng")).toString());
        as = new String[2];
        as[0] = http.JValue(j, "ad");
        as[1] = http.JValue(j, "yer");
        CreateMarker("Durak", 0x7f02001d, geopoint, as, (new StringBuilder("Durak ")).append(http.JValue(j, "ad")).toString(), (new StringBuilder(String.valueOf(http.JValue(j, "yer")))).append("\n\n").append(http.JValue(j, "aciklama")).toString(), "Duraktan Ge\347en Hatlar", "Otob\374s Nerede ?", "Favorilerime Ekle");
        j++;
        break MISSING_BLOCK_LABEL_26;
        Toast.makeText(getBaseContext(), "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!", 1).show();
        return;
    }

    public void CreateMarker(String s, int i, GeoPoint geopoint, String as[], String s1, String s2, String s3, 
            String s4, String s5)
    {
        MapOverlay mapoverlay = new MapOverlay(s, getResources().getDrawable(i), mv, as, s3, s4, s5);
        mapoverlay.addObserver(new MapOverlay.Callback() {

            final KonumMap this$0;

            public void onButtonClick(String s6, OverlayItem overlayitem, String as1[], int j)
            {
                MarkerAction(s6, overlayitem, as1, j);
            }

            
            {
                this$0 = KonumMap.this;
                super();
            }
        });
        mapoverlay.addOverlay(new OverlayItem(geopoint, s1, s2));
        lo.add(mapoverlay);
    }

    public void Isaretle(String s, GeoPoint geopoint, int i, String s1)
    {
        if (i > 0)
        {
            mc.setZoom(i);
        }
        Map.CloseBalloon(mv);
        if (geopoint != null)
        {
            mc.setCenter(geopoint);
        }
        lo = mv.getOverlays();
        lo.clear();
        MapDraw mapdraw = new MapDraw("Circle", konumPosition, 100, 0xffff0000, Color.argb(20, 255, 0, 0), 1);
        lo.add(mapdraw);
        if (!konumDurakNo.equals(""))
        {
            GeoPoint geopoint1 = konumPosition;
            String as2[] = new String[2];
            as2[0] = konumDurakNo;
            as2[1] = konumDurakTanim;
            CreateMarker("Durak", 0x7f020020, geopoint1, as2, konumBaslik, (new StringBuilder(String.valueOf(konumAdres))).append("\n").append(konumIlce).toString(), "Duraktan Ge\347en Hatlar", "Otob\374s Nerede ?", "Favorilerime Ekle");
        } else
        {
            CreateMarker("Konum", 0x7f020068, konumPosition, null, konumBaslik, (new StringBuilder(String.valueOf(konumAdres))).append("\n").append(konumIlce).toString(), "Yak\u0131ndaki Durak ve Hatlar", "", "");
        }
        if (location)
        {
            CreateMarker("Location", 0x7f020067, locationPosition, null, "Konumum", (new StringBuilder(String.valueOf(locationAdres))).append("\n").append(locationIlce).toString(), "Yak\u0131ndaki Durak ve Hatlar", "", "");
        }
        if (konumSlc)
        {
            MapDraw mapdraw1 = new MapDraw("Circle", konumPositionSlc, Integer.parseInt(Global.Set_Yakinlik), 0xff0000ff, Color.argb(20, 0, 0, 255), 1);
            lo.add(mapdraw1);
            String as[] = {
                "FNC", "YakinDuraklar"
            };
            String as1[] = new String[8];
            as1[0] = "QUERY";
            as1[1] = "";
            as1[2] = "LAT";
            as1[3] = (new StringBuilder()).append((double)konumPositionSlc.getLatitudeE6() / 1000000D).toString();
            as1[4] = "LNG";
            as1[5] = (new StringBuilder()).append((double)konumPositionSlc.getLongitudeE6() / 1000000D).toString();
            as1[6] = "MESAFE";
            as1[7] = Global.Set_Yakinlik;
            http = new Http("YakinDuraklar", "hat.asp", as, as1);
            http.addObserver(new Http.Callback() {

                final KonumMap this$0;

                public void onComplete(String s2, String s3, int j, Boolean boolean1, String s4)
                {
                    Action(s2, s3, j, boolean1, s4);
                }

            
            {
                this$0 = KonumMap.this;
                super();
            }
            });
            dialog.show();
            http.execute(new String[0]);
        }
        mv.invalidate();
    }

    public void Location()
    {
        gps = new Gps(this);
        gps.addObserver(new Gps.Callback() {

            final KonumMap this$0;

            public void onComplete(Location location1)
            {
                Exception exception1;
                GeoPoint geopoint;
                try
                {
                    dialog.dismiss();
                }
                catch (Exception exception) { }
                if (location1 != null)
                {
                    break MISSING_BLOCK_LABEL_169;
                }
                Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                geopoint = Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString());
                locationAdres = "K\u0131z\u0131lay Meydan\u0131";
                locationIlce = "\307ankaya";
_L1:
                location = true;
                locationPosition = geopoint;
                Isaretle("Location", geopoint, 17, "");
                Toast.makeText(getBaseContext(), (new StringBuilder("Konumum\n\n")).append(locationAdres).append("\n").append(locationIlce).toString(), 1).show();
                return;
                try
                {
                    geopoint = Map.GP((new StringBuilder()).append(location1.getLatitude()).toString(), (new StringBuilder()).append(location1.getLongitude()).toString());
                    locationAdres = gps.GpsAdres;
                    locationIlce = gps.GpsIlce;
                }
                // Misplaced declaration of an exception variable
                catch (Exception exception1)
                {
                    return;
                }
                  goto _L1
            }

            
            {
                this$0 = KonumMap.this;
                super();
            }
        });
        gps.Start();
    }

    public void MarkerAction(String s, OverlayItem overlayitem, String as[], int i)
    {
        if (s.equals("Location"))
        {
            Global.App_Adres_Query = "";
            Global.App_Adres_Adres = locationAdres;
            Global.App_Adres_Ilce = locationIlce;
            Global.App_Adres_Lat = (new StringBuilder()).append((double)locationPosition.getLatitudeE6() / 1000000D).toString();
            Global.App_Adres_Lng = (new StringBuilder()).append((double)locationPosition.getLongitudeE6() / 1000000D).toString();
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar), 0);
        }
        if (s.equals("Konum"))
        {
            Global.App_Adres_Query = "";
            Global.App_Adres_Adres = konumAdres;
            Global.App_Adres_Ilce = konumIlce;
            Global.App_Adres_Lat = (new StringBuilder()).append((double)konumPosition.getLatitudeE6() / 1000000D).toString();
            Global.App_Adres_Lng = (new StringBuilder()).append((double)konumPosition.getLongitudeE6() / 1000000D).toString();
            startActivityForResult(new Intent(getBaseContext(), com/ego/android/YakindakiDurakVeHatlar), 0);
        }
        if (s.equals("Durak"))
        {
            if (i == 1)
            {
                Global.App_Favorilerim_Durak_No = as[0];
                Global.App_Favorilerim_Durak_Tanim = as[1];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/DuraktanGecenHatlar), 0);
            }
            if (i == 2)
            {
                Global.App_Durak_No = as[0];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/OtobusNerede), 0);
            }
            if (i == 3)
            {
                Global.App_Favorilerim_Durak_Ekle = as[0];
                startActivityForResult(new Intent(getBaseContext(), com/ego/android/FavorilerimDurakDuzenle), 0);
            }
        }
    }

    public void Runnable(String s)
    {
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception) { }
        if (s.equals("Location"))
        {
            handlerRunnable = new Runnable() {

                final KonumMap this$0;

                public void run()
                {
                    try
                    {
                        handler.removeCallbacks(handlerRunnable);
                    }
                    catch (Exception exception1) { }
                    if (handlerStatus)
                    {
                        handlerStatus = false;
                        Location();
                    }
                }

            
            {
                this$0 = KonumMap.this;
                super();
            }
            };
        }
        handlerStatus = true;
        handler.postDelayed(handlerRunnable, 100L);
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (!s.equals("0")) goto _L2; else goto _L1
_L1:
        openOptionsMenu();
_L4:
        return;
_L2:
        if (s.equals("1"))
        {
            finish();
            return;
        }
        if (s.equals("2"))
        {
            Runnable("Location");
            return;
        }
        if (s.equals("3"))
        {
            mv.getController().zoomIn();
            return;
        }
        if (!s.equals("4"))
        {
            continue; /* Loop/switch isn't completed */
        }
        if (mv.getZoomLevel() < 12) goto _L4; else goto _L3
_L3:
        mv.getController().zoomOut();
        return;
        if (!s.equals("5")) goto _L4; else goto _L5
_L5:
        mc.setCenter(konumPosition);
        mc.setZoom(17);
        return;
    }

    protected boolean isRouteDisplayed()
    {
        return false;
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030013);
        dialog = Tools.Waiting(this);
        konum = true;
        konumPosition = Map.GP((new StringBuilder()).append(Global.App_Konum_Lat).toString(), (new StringBuilder()).append(Global.App_Konum_Lng).toString());
        konumBaslik = Global.App_Konum;
        konumAdres = Global.App_Konum_Adres;
        konumIlce = Global.App_Konum_Ilce;
        if (konumBaslik.equals("Adres"))
        {
            konumBaslik = "S.Konum";
        }
        if (!Global.App_Konum_Durak_No.equals(""))
        {
            konumDurakNo = Global.App_Konum_Durak_No;
            konumDurakTanim = Global.App_Konum_Durak_Tanim;
            Global.App_Konum_Durak_No = "";
            Global.App_Konum_Durak_Tanim = "";
        }
        if (!Global.App_Konum.equals("\326nemli Yer"))
        {
            String as[] = Tools.GeoCoder(konumPosition);
            if (!as[0].equals(""))
            {
                konumAdres = as[0];
                konumIlce = as[1];
            }
        }
        mv = (MapView)findViewById(0x7f090003);
        mc = mv.getController();
        if (Global.Set_HaritaTipi.equals("Harita"))
        {
            mv.setSatellite(false);
        }
        if (Global.Set_HaritaTipi.equals("Uydu"))
        {
            mv.setSatellite(true);
        }
        mv.setBuiltInZoomControls(false);
        mc.setCenter(Map.GP((new StringBuilder()).append(Global.App_Merkez_Lat).toString(), (new StringBuilder()).append(Global.App_Merkez_Lng).toString()));
        mc.setZoom(17);
        Isaretle("Konum", konumPosition, mv.getZoomLevel(), "");
        mv.setOnTouchListener(new android.view.View.OnTouchListener() {

            final KonumMap this$0;

            public boolean onTouch(View view, MotionEvent motionevent)
            {
                if (motionevent.getAction() != 1) goto _L2; else goto _L1
_L1:
                if (lastTouchPositon == null) goto _L4; else goto _L3
_L3:
                GeoPoint geopoint;
                int k;
                int l;
                geopoint = mv.getProjection().fromPixels((int)motionevent.getX(), (int)motionevent.getY());
                int i = (int)motionevent.getX() - lastTouchPositon.x;
                int j = (int)motionevent.getY() - lastTouchPositon.y;
                k = Math.abs(i);
                l = Math.abs(j);
                if (k > 10 || l > 10)
                {
                    break MISSING_BLOCK_LABEL_277;
                }
                if (motionevent.getEventTime() - lastTouchTime < 250L || motionevent.getEventTime() - lastTouchTime > 1000L)
                {
                    break MISSING_BLOCK_LABEL_287;
                }
                konumSlc = true;
                konumPositionSlc = geopoint;
                konumAdresSlc = "";
                konumIlceSlc = "";
                String as1[] = Tools.GeoCoder(konumPositionSlc);
                if (!as1[0].equals(""))
                {
                    konumAdresSlc = as1[0];
                    konumIlceSlc = as1[1];
                }
                Isaretle("Konum", konumPositionSlc, 0, "");
                lastTouchTime = -1L;
                lastTouchDoubleTime = -1L;
                lastTouchPositon = null;
                return true;
                try
                {
                    lastTouchTime = -1L;
                }
                catch (Exception exception) { }
                lastTouchTime = -1L;
_L2:
                if (motionevent.getAction() != 0)
                {
                    break MISSING_BLOCK_LABEL_445;
                }
                if (motionevent.getEventTime() - lastTouchDoubleTime < 250L)
                {
                    mc.setZoom(1 + mv.getZoomLevel());
                    mv.invalidate();
                    lastTouchTime = -1L;
                    lastTouchDoubleTime = -1L;
                    lastTouchPositon = null;
                    return true;
                }
                break; /* Loop/switch isn't completed */
_L4:
                lastTouchTime = -1L;
                if (true) goto _L2; else goto _L5
_L5:
                lastTouchPositon = new Point((int)motionevent.getX(), (int)motionevent.getY());
                lastTouchTime = motionevent.getEventTime();
                lastTouchDoubleTime = motionevent.getEventTime();
                return false;
            }

            
            {
                this$0 = KonumMap.this;
                super();
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        menu.add(0, 3, 3, "Harita G\366r\374n\374m\374");
        menu.add(0, 4, 4, "Uydu G\366r\374n\374m\374");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 4: default 36
    //                   1 42
    //                   2 55
    //                   3 62
    //                   4 73;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        continue; /* Loop/switch isn't completed */
_L4:
        mv.setSatellite(false);
        continue; /* Loop/switch isn't completed */
_L5:
        mv.setSatellite(true);
        if (true) goto _L1; else goto _L6
_L6:
    }

    protected void onStop()
    {
        try
        {
            gps.Stop();
        }
        catch (Exception exception) { }
        super.onStop();
    }
}
