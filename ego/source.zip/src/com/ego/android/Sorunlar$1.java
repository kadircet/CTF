// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Sorunlar, Global, SorunlarBildir, SorunlarListe

class this._cls0
    implements android.widget..OnItemClickListener
{

    final Sorunlar this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        HashMap hashmap = (HashMap)((ListView)findViewById(0x7f090067)).getItemAtPosition(i);
        if (Global.Set_AdSoyad.equals("") || Global.Set_Telefon.equals("") || Global.Set_EPosta.equals(""))
        {
            Toast.makeText(getBaseContext(), "Kullan\u0131c\u0131 Bilgilerinizi\nAyarlar B\366l\374m\374nden Giriniz!", 1).show();
        } else
        {
            if (hashmap.get("id") == "0")
            {
                Intent intent = new Intent(getBaseContext(), com/ego/android/SorunlarBildir);
                startActivityForResult(intent, 0);
            }
            if (hashmap.get("id") == "1")
            {
                Intent intent1 = new Intent(getBaseContext(), com/ego/android/SorunlarListe);
                startActivityForResult(intent1, 0);
                return;
            }
        }
    }

    te()
    {
        this$0 = Sorunlar.this;
        super();
    }
}
