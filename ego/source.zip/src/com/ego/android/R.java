// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;


public final class R
{
    public static final class attr
    {

        public attr()
        {
        }
    }

    public static final class dimen
    {

        public static final int activity_horizontal_margin = 0x7f050000;
        public static final int activity_vertical_margin = 0x7f050001;

        public dimen()
        {
        }
    }

    public static final class drawable
    {

        public static final int abb_logo = 0x7f020000;
        public static final int action_bg = 0x7f020001;
        public static final int action_bg_select = 0x7f020002;
        public static final int action_bg_selector = 0x7f020003;
        public static final int add = 0x7f020004;
        public static final int airport = 0x7f020005;
        public static final int alarm = 0x7f020006;
        public static final int ankaray = 0x7f020007;
        public static final int ara = 0x7f020008;
        public static final int asti = 0x7f020009;
        public static final int back = 0x7f02000a;
        public static final int balloon_overlay_bg_selector = 0x7f02000b;
        public static final int balloon_overlay_close = 0x7f02000c;
        public static final int balloon_overlay_focused = 0x7f02000d;
        public static final int balloon_overlay_unfocused = 0x7f02000e;
        public static final int bg = 0x7f02000f;
        public static final int border = 0x7f020010;
        public static final int bus = 0x7f020011;
        public static final int bus_black = 0x7f020012;
        public static final int bus_ego = 0x7f020013;
        public static final int bus_ego_0 = 0x7f020014;
        public static final int bus_ego_1 = 0x7f020015;
        public static final int bus_ego_2 = 0x7f020016;
        public static final int bus_ego_3 = 0x7f020017;
        public static final int bus_ego_4 = 0x7f020018;
        public static final int bus_ego_5 = 0x7f020019;
        public static final int bus_ego_6 = 0x7f02001a;
        public static final int bus_ego_7 = 0x7f02001b;
        public static final int bus_ego_zemin = 0x7f02001c;
        public static final int bus_stop = 0x7f02001d;
        public static final int bus_stop_black = 0x7f02001e;
        public static final int bus_stop_map = 0x7f02001f;
        public static final int bus_stop_red = 0x7f020020;
        public static final int bus_stop_white = 0x7f020021;
        public static final int bus_stop_zemin = 0x7f020022;
        public static final int bus_white = 0x7f020023;
        public static final int cell_btn_bg = 0x7f020024;
        public static final int cell_btn_bg_select = 0x7f020025;
        public static final int cell_btn_bg_selector = 0x7f020026;
        public static final int check = 0x7f020027;
        public static final int check_big = 0x7f020028;
        public static final int clock = 0x7f020029;
        public static final int clock_black = 0x7f02002a;
        public static final int clock_white = 0x7f02002b;
        public static final int close = 0x7f02002c;
        public static final int delete = 0x7f02002d;
        public static final int download = 0x7f02002e;
        public static final int durak = 0x7f02002f;
        public static final int ego = 0x7f020030;
        public static final int ego_logo = 0x7f020031;
        public static final int email = 0x7f020032;
        public static final int favs = 0x7f020033;
        public static final int flag = 0x7f020034;
        public static final int flag_black = 0x7f020035;
        public static final int flag_white = 0x7f020036;
        public static final int hat = 0x7f020037;
        public static final int home = 0x7f020038;
        public static final int home_black = 0x7f020039;
        public static final int home_white = 0x7f02003a;
        public static final int ic_launcher = 0x7f02003b;
        public static final int image = 0x7f02003c;
        public static final int image_black = 0x7f02003d;
        public static final int image_white = 0x7f02003e;
        public static final int konum = 0x7f02003f;
        public static final int location = 0x7f020040;
        public static final int location_black = 0x7f020041;
        public static final int location_white = 0x7f020042;
        public static final int map = 0x7f020043;
        public static final int map_black = 0x7f020044;
        public static final int map_white = 0x7f020045;
        public static final int menu_abb = 0x7f020046;
        public static final int menu_adresara = 0x7f020047;
        public static final int menu_adresara_img = 0x7f020048;
        public static final int menu_bg_blue = 0x7f020049;
        public static final int menu_bg_blue_select = 0x7f02004a;
        public static final int menu_bg_blue_selector = 0x7f02004b;
        public static final int menu_bg_white = 0x7f02004c;
        public static final int menu_bg_white_select = 0x7f02004d;
        public static final int menu_bg_white_selector = 0x7f02004e;
        public static final int menu_cikis = 0x7f02004f;
        public static final int menu_duyurular = 0x7f020050;
        public static final int menu_duyurular_img = 0x7f020051;
        public static final int menu_ego = 0x7f020052;
        public static final int menu_favorilerim = 0x7f020053;
        public static final int menu_favorilerim_img = 0x7f020054;
        public static final int menu_hatara = 0x7f020055;
        public static final int menu_hatara_img = 0x7f020056;
        public static final int menu_nasilgiderim = 0x7f020057;
        public static final int menu_nasilgiderim_img = 0x7f020058;
        public static final int menu_neredeyim = 0x7f020059;
        public static final int menu_neredeyim_img = 0x7f02005a;
        public static final int menu_onemliyerler = 0x7f02005b;
        public static final int menu_onemliyerler_img = 0x7f02005c;
        public static final int menu_otobusnerede = 0x7f02005d;
        public static final int menu_otobusnerede_img = 0x7f02005e;
        public static final int menu_sorunbildir = 0x7f02005f;
        public static final int menu_sorunbildir_img = 0x7f020060;
        public static final int metro = 0x7f020061;
        public static final int minus = 0x7f020062;
        public static final int otobus = 0x7f020063;
        public static final int panel = 0x7f020064;
        public static final int pause = 0x7f020065;
        public static final int pin = 0x7f020066;
        public static final int pin_location = 0x7f020067;
        public static final int pin_select = 0x7f020068;
        public static final int pin_zemin_kirmizi = 0x7f020069;
        public static final int pin_zemin_yesil = 0x7f02006a;
        public static final int play = 0x7f02006b;
        public static final int play_white = 0x7f02006c;
        public static final int progress_style = 0x7f02006d;
        public static final int refresh = 0x7f02006e;
        public static final int refresh_big = 0x7f02006f;
        public static final int save = 0x7f020070;
        public static final int search = 0x7f020071;
        public static final int search_black = 0x7f020072;
        public static final int search_white = 0x7f020073;
        public static final int settings = 0x7f020074;
        public static final int shuffle_black = 0x7f020075;
        public static final int shuffle_white = 0x7f020076;
        public static final int sorgula = 0x7f020077;
        public static final int star_black = 0x7f020078;
        public static final int star_white = 0x7f020079;
        public static final int toolbar_bg = 0x7f02007a;
        public static final int toolbar_bg_select = 0x7f02007b;
        public static final int toolbar_bg_selector = 0x7f02007c;
        public static final int train = 0x7f02007d;
        public static final int yakinlik = 0x7f02007e;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int Aciklama = 0x7f090037;
        public static final int Ad = 0x7f09003a;
        public static final int AdSoyad = 0x7f090013;
        public static final int Adres = 0x7f09006f;
        public static final int Aktif = 0x7f090066;
        public static final int Ara = 0x7f090000;
        public static final int Baslik = 0x7f09002e;
        public static final int Birim = 0x7f090068;
        public static final int Button1 = 0x7f090022;
        public static final int Button2 = 0x7f090023;
        public static final int Button3 = 0x7f090024;
        public static final int Button4 = 0x7f090025;
        public static final int Button5 = 0x7f090026;
        public static final int Button6 = 0x7f090027;
        public static final int Button7 = 0x7f090028;
        public static final int ButtonClose = 0x7f090020;
        public static final int ButtonOk = 0x7f090029;
        public static final int CELL_1 = 0x7f090045;
        public static final int CELL_1A = 0x7f09004c;
        public static final int CELL_1_BTN = 0x7f090053;
        public static final int CELL_1_COLOR = 0x7f090051;
        public static final int CELL_1_TEXT = 0x7f090054;
        public static final int CELL_1_TITLE = 0x7f090052;
        public static final int CELL_2 = 0x7f090046;
        public static final int CELL_2A = 0x7f09004d;
        public static final int CELL_2_BTN = 0x7f090057;
        public static final int CELL_2_COLOR = 0x7f090055;
        public static final int CELL_2_TEXT = 0x7f090058;
        public static final int CELL_2_TITLE = 0x7f090056;
        public static final int CELL_3 = 0x7f090048;
        public static final int CELL_3A = 0x7f09004e;
        public static final int CELL_4 = 0x7f090049;
        public static final int CELL_5 = 0x7f09004a;
        public static final int CELL_6 = 0x7f09004b;
        public static final int CELL_7 = 0x7f09004f;
        public static final int CELL_8 = 0x7f090050;
        public static final int CELL_BTN = 0x7f090047;
        public static final int DaraltGenisle = 0x7f090005;
        public static final int Detay = 0x7f09002f;
        public static final int DurakNo = 0x7f090009;
        public static final int DurakTanim = 0x7f09000a;
        public static final int EPosta = 0x7f090015;
        public static final int Fotograf1 = 0x7f09006b;
        public static final int Fotograf2 = 0x7f09006c;
        public static final int Hat = 0x7f09003f;
        public static final int Hat1 = 0x7f090060;
        public static final int Hat2 = 0x7f090061;
        public static final int HatNo = 0x7f090007;
        public static final int HatTanim = 0x7f090008;
        public static final int Ilce = 0x7f090070;
        public static final int Kategori = 0x7f09002c;
        public static final int Kayit = 0x7f090063;
        public static final int Klavye = 0x7f090039;
        public static final int Konu = 0x7f090069;
        public static final int Konum = 0x7f09006d;
        public static final int LinearLayoutHat = 0x7f09000f;
        public static final int LinearLayoutOtobus = 0x7f090064;
        public static final int Link = 0x7f090030;
        public static final int ListViewAdres = 0x7f090002;
        public static final int ListViewAyarlar = 0x7f090016;
        public static final int ListViewDetay = 0x7f09005f;
        public static final int ListViewDurak = 0x7f090033;
        public static final int ListViewDuyuru = 0x7f09002b;
        public static final int ListViewHat = 0x7f09002a;
        public static final int ListViewMenu = 0x7f090067;
        public static final int ListViewOnemliYer = 0x7f090062;
        public static final int ListViewOtobus = 0x7f090010;
        public static final int ListViewPanel = 0x7f090065;
        public static final int ListViewSaat = 0x7f09003d;
        public static final int ListViewSorun = 0x7f09006e;
        public static final int Map = 0x7f090003;
        public static final int Mesafe = 0x7f09003c;
        public static final int Nereden = 0x7f090059;
        public static final int NeredenIlce = 0x7f09005c;
        public static final int Nereye = 0x7f09005a;
        public static final int NereyeIlce = 0x7f09005d;
        public static final int No = 0x7f090035;
        public static final int OtobusBilgisi = 0x7f090040;
        public static final int OtobusBilgisiText = 0x7f090041;
        public static final int Panel = 0x7f090006;
        public static final int Pause = 0x7f090012;
        public static final int Play = 0x7f090011;
        public static final int Renk = 0x7f090038;
        public static final int Sec = 0x7f090004;
        public static final int Siralama = 0x7f09005b;
        public static final int Sorun = 0x7f09006a;
        public static final int Sure = 0x7f09003b;
        public static final int Tanim = 0x7f090036;
        public static final int Tarih = 0x7f09002d;
        public static final int Telefon = 0x7f090014;
        public static final int Text = 0x7f090021;
        public static final int Title = 0x7f09001f;
        public static final int Tur = 0x7f09005e;
        public static final int Type = 0x7f090001;
        public static final int Yaklasma = 0x7f09000d;
        public static final int Yenile = 0x7f090042;
        public static final int Yenileme = 0x7f09000b;
        public static final int action_settings = 0x7f090071;
        public static final int balloon_button_1 = 0x7f09001c;
        public static final int balloon_button_2 = 0x7f09001d;
        public static final int balloon_button_3 = 0x7f09001e;
        public static final int balloon_inner_layout = 0x7f090018;
        public static final int balloon_item_snippet = 0x7f09001a;
        public static final int balloon_item_title = 0x7f090019;
        public static final int balloon_main_layout = 0x7f090017;
        public static final int close_img_button = 0x7f09001b;
        public static final int group1 = 0x7f090072;
        public static final int item1 = 0x7f090073;
        public static final int item2 = 0x7f090074;
        public static final int seekBar = 0x7f090043;
        public static final int seekBarNumber = 0x7f090044;
        public static final int seekBarYaklasma = 0x7f09000e;
        public static final int seekBarYenileme = 0x7f09000c;
        public static final int tabcontent1 = 0x7f090032;
        public static final int tabcontent2 = 0x7f090034;
        public static final int tabcontent3 = 0x7f09003e;
        public static final int tabhost = 0x7f090031;

        public id()
        {
        }
    }

    public static final class layout
    {

        public static final int adresara = 0x7f030000;
        public static final int adresmap = 0x7f030001;
        public static final int alarm = 0x7f030002;
        public static final int ayarlar = 0x7f030003;
        public static final int balloon_map_overlay = 0x7f030004;
        public static final int dialog = 0x7f030005;
        public static final int duraktangecenhatlar = 0x7f030006;
        public static final int duyurular = 0x7f030007;
        public static final int duyurulardetay = 0x7f030008;
        public static final int egootobushatlari = 0x7f030009;
        public static final int favorilerim = 0x7f03000a;
        public static final int favorilerimdurak = 0x7f03000b;
        public static final int favorilerimdurakduzenle = 0x7f03000c;
        public static final int favorilerimhat = 0x7f03000d;
        public static final int favorilerimhatduzenle = 0x7f03000e;
        public static final int hatara = 0x7f03000f;
        public static final int hatbilgileri = 0x7f030010;
        public static final int hatduraklar = 0x7f030011;
        public static final int hatmap = 0x7f030012;
        public static final int konummap = 0x7f030013;
        public static final int listadres = 0x7f030014;
        public static final int listadresbtn = 0x7f030015;
        public static final int listayar = 0x7f030016;
        public static final int listdurak = 0x7f030017;
        public static final int listdurakbtn = 0x7f030018;
        public static final int listduyuru = 0x7f030019;
        public static final int listhat = 0x7f03001a;
        public static final int listhatbtn = 0x7f03001b;
        public static final int listhatdurak = 0x7f03001c;
        public static final int listhatotobus = 0x7f03001d;
        public static final int listhatsaat = 0x7f03001e;
        public static final int listmenu = 0x7f03001f;
        public static final int listonemliyer = 0x7f030020;
        public static final int listonemliyerbtn = 0x7f030021;
        public static final int listotobus = 0x7f030022;
        public static final int listotobusbtn = 0x7f030023;
        public static final int listpanel = 0x7f030024;
        public static final int listsorun = 0x7f030025;
        public static final int mainmenu = 0x7f030026;
        public static final int nasilgiderim = 0x7f030027;
        public static final int nasilgiderimdetay = 0x7f030028;
        public static final int nasilgiderimliste = 0x7f030029;
        public static final int nasilgiderimmap = 0x7f03002a;
        public static final int neredeyim = 0x7f03002b;
        public static final int onemliyerler = 0x7f03002c;
        public static final int onemliyerlerdetay = 0x7f03002d;
        public static final int otobusnerede = 0x7f03002e;
        public static final int otobusneredemap = 0x7f03002f;
        public static final int panelim = 0x7f030030;
        public static final int panelimduzenle = 0x7f030031;
        public static final int progress = 0x7f030032;
        public static final int sorunlar = 0x7f030033;
        public static final int sorunlarbildir = 0x7f030034;
        public static final int sorunlardetay = 0x7f030035;
        public static final int sorunlarliste = 0x7f030036;
        public static final int template = 0x7f030037;
        public static final int yakindakiduraklar = 0x7f030038;
        public static final int yakindakidurakvehatlar = 0x7f030039;
        public static final int yakindakihatlar = 0x7f03003a;

        public layout()
        {
        }
    }

    public static final class menu
    {

        public static final int main = 0x7f080000;
        public static final int mainmenu = 0x7f080001;

        public menu()
        {
        }
    }

    public static final class raw
    {

        public static final int beep = 0x7f040000;

        public raw()
        {
        }
    }

    public static final class string
    {

        public static final int action_settings = 0x7f060002;
        public static final int app_name = 0x7f060000;
        public static final int title_activity_main = 0x7f060001;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int AppBaseTheme = 0x7f070003;
        public static final int AppTheme = 0x7f070004;
        public static final int CustomTheme = 0x7f070000;
        public static final int SpinnerItem = 0x7f070001;
        public static final int SpinnerItem_DropDownItem = 0x7f070002;

        public style()
        {
        }
    }


    public R()
    {
    }
}
