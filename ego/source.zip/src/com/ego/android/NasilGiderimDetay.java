// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            Global, NasilGiderimMap, HatBilgileri

public class NasilGiderimDetay extends Activity
{

    HashMap o;

    public NasilGiderimDetay()
    {
    }

    public void Harita_OnClick(View view)
    {
        Global.App_Hat_No = (String)o.get("kod");
        Global.App_Durak_No = "";
        Global.App_Otobus_No = "";
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/NasilGiderimMap), 0);
    }

    public void Hatlar_OnClick(View view)
    {
        String s = ((Button)view).getTag().toString();
        if (s.equals("1"))
        {
            Global.App_Hat_No = (String)o.get("kod");
            Global.App_Durak_No = (String)o.get("durakbin");
            Global.App_Otobus_No = "";
        }
        if (s.equals("2"))
        {
            if (((String)o.get("kod")).equals(o.get("vkod")))
            {
                Toast.makeText(getBaseContext(), "Aktarmal\u0131 Hat De\u011Fil!", 1).show();
                return;
            }
            Global.App_Hat_No = (String)o.get("vkod");
            Global.App_Durak_No = (String)o.get("vdurakbin");
            Global.App_Otobus_No = "";
        }
        startActivityForResult(new Intent(getBaseContext(), com/ego/android/HatBilgileri), 0);
    }

    public void ToolBar_OnClick(View view)
    {
        String s = view.getTag().toString();
        if (s.equals("0"))
        {
            openOptionsMenu();
        } else
        {
            if (s.equals("1"))
            {
                finish();
                return;
            }
            if (!s.equals("2") && !s.equals("3"))
            {
                s.equals("4");
                return;
            }
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if (j == 99)
        {
            setResult(99);
            finish();
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030028);
        ((TextView)findViewById(0x7f090059)).setText(Global.App_Nereden_Adres);
        ((TextView)findViewById(0x7f09005c)).setText(Global.App_Nereden_Ilce);
        ((TextView)findViewById(0x7f09005a)).setText(Global.App_Nereye_Adres);
        ((TextView)findViewById(0x7f09005d)).setText(Global.App_Nereye_Ilce);
        o = Global.App_NasilGiderim;
        String s = (new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf(""))).append((String)o.get("kod")).append(" ").append((String)o.get("ad")).append(" Hatt\u0131n\u0131n\n").toString()))).append("  ").append((String)o.get("durakbin")).append(". Dura\u011F\u0131ndan Binip\n").toString()))).append("  ").append((String)o.get("durakin")).append(". Dura\u011F\u0131nda \u0130nin\n\n").toString();
        if (!((String)o.get("kod")).equals(o.get("vkod")))
        {
            s = (new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf((new StringBuilder(String.valueOf(s))).append("Hatt\u0131 De\u011Fi\u015Ftirin\n\n").toString()))).append((String)o.get("vkod")).append(" ").append((String)o.get("vad")).append(" Hatt\u0131n\u0131n\n").toString()))).append("  ").append((String)o.get("vdurakbin")).append(". Dura\u011F\u0131ndan Binip\n").toString()))).append("  ").append((String)o.get("vdurakin")).append(". Dura\u011F\u0131nda \u0130nin\n\n").toString();
        }
        String s1 = (new StringBuilder(String.valueOf(s))).append("S\374resi: ").append((String)o.get("sure")).append(", Mesafe: ").append((String)o.get("mesafe")).toString();
        ((TextView)findViewById(0x7f09005e)).setText((new StringBuilder(String.valueOf((String)o.get("tur")))).append(" Hat").toString());
        ((TextView)findViewById(0x7f09002f)).setText(s1);
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 1, "Ana Men\374");
        menu.add(0, 2, 2, "Geri");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        menuitem.getItemId();
        JVM INSTR tableswitch 1 2: default 28
    //                   1 34
    //                   2 47;
           goto _L1 _L2 _L3
_L1:
        return super.onOptionsItemSelected(menuitem);
_L2:
        setResult(99);
        finish();
        continue; /* Loop/switch isn't completed */
_L3:
        finish();
        if (true) goto _L1; else goto _L4
_L4:
    }

    protected void onStop()
    {
        super.onStop();
    }
}
