// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.view.MotionEvent;
import android.view.View;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;

// Referenced classes of package com.ego.android:
//            HatMap

class this._cls0
    implements android.view.uchListener
{

    final HatMap this$0;

    public boolean onTouch(View view, MotionEvent motionevent)
    {
        if (motionevent.getAction() == 0)
        {
            if (motionevent.getEventTime() - lastTouchDoubleTime < 250L)
            {
                mc.setZoom(1 + mv.getZoomLevel());
                mv.invalidate();
                lastTouchDoubleTime = -1L;
                return true;
            }
            lastTouchDoubleTime = motionevent.getEventTime();
        }
        return false;
    }

    apController()
    {
        this$0 = HatMap.this;
        super();
    }
}
