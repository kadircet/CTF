// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.maps.OverlayItem;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class BalloonOverlayView extends FrameLayout
{
    public static interface Callback
    {

        public abstract void onButtonClick(int i);
    }


    private Set callbacks;
    private LinearLayout layout;
    private TextView snippet;
    private TextView title;

    public BalloonOverlayView(Context context, int i)
    {
        super(context);
        callbacks = new HashSet();
        setPadding(10, 0, 10, i);
        layout = new LinearLayout(context);
        layout.setVisibility(0);
        View view = ((LayoutInflater)context.getSystemService("layout_inflater")).inflate(0x7f030004, layout);
        title = (TextView)view.findViewById(0x7f090019);
        snippet = (TextView)view.findViewById(0x7f09001a);
        ImageView imageview = (ImageView)view.findViewById(0x7f09001b);
        view.setOnClickListener(new android.view.View.OnClickListener() {

            final BalloonOverlayView this$0;

            public void onClick(View view1)
            {
                layout.setVisibility(8);
            }

            
            {
                this$0 = BalloonOverlayView.this;
                super();
            }
        });
        imageview.setOnClickListener(new android.view.View.OnClickListener() {

            final BalloonOverlayView this$0;

            public void onClick(View view1)
            {
                layout.setVisibility(8);
            }

            
            {
                this$0 = BalloonOverlayView.this;
                super();
            }
        });
        ((Button)view.findViewById(0x7f09001c)).setOnClickListener(new android.view.View.OnClickListener() {

            final BalloonOverlayView this$0;

            public void onClick(View view1)
            {
                buttonClick(1);
            }

            
            {
                this$0 = BalloonOverlayView.this;
                super();
            }
        });
        ((Button)view.findViewById(0x7f09001d)).setOnClickListener(new android.view.View.OnClickListener() {

            final BalloonOverlayView this$0;

            public void onClick(View view1)
            {
                buttonClick(2);
            }

            
            {
                this$0 = BalloonOverlayView.this;
                super();
            }
        });
        ((Button)view.findViewById(0x7f09001e)).setOnClickListener(new android.view.View.OnClickListener() {

            final BalloonOverlayView this$0;

            public void onClick(View view1)
            {
                buttonClick(3);
            }

            
            {
                this$0 = BalloonOverlayView.this;
                super();
            }
        });
        android.widget.FrameLayout.LayoutParams layoutparams = new android.widget.FrameLayout.LayoutParams(-2, -2);
        layoutparams.gravity = 0;
        addView(layout, layoutparams);
    }

    public void addObserver(Callback callback)
    {
        callbacks.add(callback);
    }

    public void buttonClick(int i)
    {
        Iterator iterator = callbacks.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                return;
            }
            ((Callback)iterator.next()).onButtonClick(i);
        } while (true);
    }

    public void setData(OverlayItem overlayitem)
    {
        layout.setVisibility(0);
        if (overlayitem.getTitle() != null)
        {
            title.setVisibility(0);
            title.setText(overlayitem.getTitle());
        } else
        {
            title.setVisibility(8);
        }
        if (overlayitem.getSnippet() != null)
        {
            snippet.setVisibility(0);
            snippet.setText(overlayitem.getSnippet());
            return;
        } else
        {
            snippet.setVisibility(8);
            return;
        }
    }

    public void setText(String s)
    {
        layout.setVisibility(0);
        snippet.setText(s);
    }

    public void setTitle(String s)
    {
        layout.setVisibility(0);
        title.setText(s);
    }

}
