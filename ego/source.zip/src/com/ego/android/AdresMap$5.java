// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.os.Handler;

// Referenced classes of package com.ego.android:
//            AdresMap, Tools

class this._cls0
    implements Runnable
{

    final AdresMap this$0;

    public void run()
    {
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        try
        {
            handler.removeCallbacks(handlerRunnable);
        }
        catch (Exception exception1) { }
        if (handlerStatus)
        {
            handlerStatus = false;
            String as[] = Tools.GeoCoder(konumPosition);
            if (!as[0].equals(""))
            {
                konumAdres = as[0];
                konumIlce = as[1];
            }
        }
    }

    ()
    {
        this$0 = AdresMap.this;
        super();
    }
}
