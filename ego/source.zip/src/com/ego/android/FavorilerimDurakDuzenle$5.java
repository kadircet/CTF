// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.DialogInterface;

// Referenced classes of package com.ego.android:
//            FavorilerimDurakDuzenle, Global, Http

class this._cls0
    implements android.content.tener
{

    final FavorilerimDurakDuzenle this$0;

    public void onClick(DialogInterface dialoginterface, int i)
    {
        FavorilerimDurakDuzenle favorilerimdurakduzenle = FavorilerimDurakDuzenle.this;
        String as[] = {
            "FNC", "FavoriSil"
        };
        String as1[] = new String[6];
        as1[0] = "UID";
        as1[1] = Global.Device_ID;
        as1[2] = "TIP";
        as1[3] = "Durak";
        as1[4] = "NO";
        as1[5] = Favorilerim_Durak_No;
        favorilerimdurakduzenle.http = new Http("FavoriSil", "favori.asp", as, as1);
        http.addObserver(new Http.Callback() {

            final FavorilerimDurakDuzenle._cls5 this$1;

            public void onComplete(String s, String s1, int j, Boolean boolean1, String s2)
            {
                Action(s, s1, j, boolean1, s2);
            }

            
            {
                this$1 = FavorilerimDurakDuzenle._cls5.this;
                super();
            }
        });
        http.execute(new String[0]);
    }


    _cls1.this._cls1()
    {
        this$0 = FavorilerimDurakDuzenle.this;
        super();
    }
}
