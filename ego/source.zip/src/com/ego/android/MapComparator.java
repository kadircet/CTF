// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import java.util.Comparator;
import java.util.Map;

class MapComparator
    implements Comparator
{

    private final String key;

    public MapComparator(String s)
    {
        key = s;
    }

    public volatile int compare(Object obj, Object obj1)
    {
        return compare((Map)obj, (Map)obj1);
    }

    public int compare(Map map, Map map1)
    {
        return ((String)map.get(key)).compareTo((String)map1.get(key));
    }
}
