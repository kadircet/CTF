// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.os.AsyncTask;
import android.os.Build;
import java.net.URI;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

// Referenced classes of package com.ego.android:
//            Global

public class Http extends AsyncTask
{
    public static interface Callback
    {

        public abstract void onComplete(String s, String s1, int i, Boolean boolean1, String s2);
    }


    public String Action;
    public boolean Error;
    public String ErrorMessage;
    public String Parameter[];
    public String Post[];
    public String Response;
    public int ResponseCode;
    public String Url;
    private Set callbacks;
    public JSONArray jArray;
    public String jName;
    public JSONObject jObject;
    public JSONTokener jToken;

    public Http(String s)
    {
        Action = null;
        Url = null;
        Parameter = null;
        Post = null;
        Response = null;
        ResponseCode = -1;
        jToken = null;
        jObject = null;
        jArray = null;
        jName = "data";
        Error = false;
        ErrorMessage = null;
        callbacks = new HashSet();
        Action = s;
    }

    public Http(String s, String s1)
    {
        Action = null;
        Url = null;
        Parameter = null;
        Post = null;
        Response = null;
        ResponseCode = -1;
        jToken = null;
        jObject = null;
        jArray = null;
        jName = "data";
        Error = false;
        ErrorMessage = null;
        callbacks = new HashSet();
        Action = s;
        Url = s1;
    }

    public Http(String s, String s1, String as[])
    {
        Action = null;
        Url = null;
        Parameter = null;
        Post = null;
        Response = null;
        ResponseCode = -1;
        jToken = null;
        jObject = null;
        jArray = null;
        jName = "data";
        Error = false;
        ErrorMessage = null;
        callbacks = new HashSet();
        Action = s;
        Url = s1;
        Parameter = as;
    }

    public Http(String s, String s1, String as[], String as1[])
    {
        Action = null;
        Url = null;
        Parameter = null;
        Post = null;
        Response = null;
        ResponseCode = -1;
        jToken = null;
        jObject = null;
        jArray = null;
        jName = "data";
        Error = false;
        ErrorMessage = null;
        callbacks = new HashSet();
        Action = s;
        Url = s1;
        Parameter = as;
        Post = as1;
    }

    public String EncodeParameter(String s)
    {
        String s1;
        try
        {
            s1 = URLEncoder.encode(s, "UTF-8");
        }
        catch (Exception exception)
        {
            return s;
        }
        return s1;
    }

    public String EncodeUrl(String s)
    {
        String as[] = {
            "\347", "\307", "\u011F", "\u011E", "\u0131", "\u0130", "\366", "\326", "\u015F", "\u015E", 
            "\374", "\334", " "
        };
        String as1[] = {
            "%C3%A7", "%C3%87", "%C4%9F", "%C4%9E", "%C4%B1", "%C4%B0", "%C3%B6", "%C3%96", "%C5%9F", "%C5%9E", 
            "%C3%BC", "%C3%9C", "%20"
        };
        int i = 0;
        do
        {
            if (i >= as.length)
            {
                return s;
            }
            s = s.replace(as[i], as1[i]);
            i++;
        } while (true);
    }

    public JSONArray JArray(int i, String s)
    {
        JSONArray jsonarray = jArray;
        JSONArray jsonarray1 = null;
        if (jsonarray != null)
        {
            JSONArray jsonarray2;
            try
            {
                jsonarray2 = jArray.getJSONObject(i).getJSONArray(s);
            }
            catch (Exception exception)
            {
                return null;
            }
            jsonarray1 = jsonarray2;
        }
        return jsonarray1;
    }

    public String JString(String s)
    {
        JSONObject jsonobject = jObject;
        String s1 = null;
        if (jsonobject != null)
        {
            String s2;
            try
            {
                s2 = jObject.getString(s);
            }
            catch (Exception exception)
            {
                return null;
            }
            s1 = s2;
        }
        return s1;
    }

    public String JValue(int i, String s)
    {
        if (jArray != null)
        {
            String s1;
            try
            {
                s1 = jArray.getJSONObject(i).getString(s);
            }
            catch (Exception exception)
            {
                return "";
            }
            return s1;
        } else
        {
            return null;
        }
    }

    public void addObserver(Callback callback)
    {
        callbacks.add(callback);
    }

    protected volatile transient Object doInBackground(Object aobj[])
    {
        return doInBackground((String[])aobj);
    }

    protected transient String doInBackground(String as[])
    {
        DefaultHttpClient defaulthttpclient;
        Response = "";
        ResponseCode = -1;
        Error = false;
        ErrorMessage = "";
        jToken = null;
        jObject = null;
        jArray = null;
        BasicHttpParams basichttpparams = new BasicHttpParams();
        HttpProtocolParams.setVersion(basichttpparams, HttpVersion.HTTP_1_1);
        HttpProtocolParams.setUseExpectContinue(basichttpparams, true);
        HttpConnectionParams.setStaleCheckingEnabled(basichttpparams, false);
        HttpConnectionParams.setTcpNoDelay(basichttpparams, true);
        HttpConnectionParams.setConnectionTimeout(basichttpparams, 45000);
        HttpConnectionParams.setSoTimeout(basichttpparams, 45000);
        defaulthttpclient = new DefaultHttpClient(basichttpparams);
        String s;
        String s2;
        s = Url;
        if (Url.indexOf("http:") != -1)
        {
            break MISSING_BLOCK_LABEL_185;
        }
        s2 = (new StringBuilder(String.valueOf((new StringBuilder("http://")).append(Global.App_HttpServis).append("/").append(Global.App_HttpServisUrl).append(Url).toString()))).append("?SID=").append(Math.random()).append("&VERSION=").append(Global.App_CurrentVersion).toString();
        s = s2;
        int i = 0;
_L7:
        int l = Parameter.length;
        if (i < l) goto _L2; else goto _L1
_L1:
        HttpPost httppost;
        ArrayList arraylist;
        httppost = new HttpPost(new URI(s));
        httppost.setHeader("User-Agent", (new StringBuilder("otobushatlari ")).append(Global.App_CurrentVersion).append(" ").append(Build.MODEL).append(" ").append(android.os.Build.VERSION.RELEASE).toString());
        arraylist = new ArrayList();
        int j = 0;
_L8:
        if (j < Post.length) goto _L4; else goto _L3
_L3:
        httppost.setEntity(new UrlEncodedFormEntity(arraylist, "UTF-8"));
        int k = 0;
_L9:
        if (k < 2) goto _L6; else goto _L5
_L5:
        return Response;
_L2:
        String s1 = (new StringBuilder(String.valueOf(s))).append("&").append(Parameter[i]).append("=").append(EncodeParameter(Parameter[i + 1])).toString();
        s = s1;
        i = 1 + (i + 1);
          goto _L7
_L4:
        arraylist.add(new BasicNameValuePair(Post[j], Post[j + 1]));
        j = 1 + (j + 1);
          goto _L8
_L6:
        org.apache.http.HttpEntity httpentity;
        HttpResponse httpresponse = defaulthttpclient.execute(httppost);
        ResponseCode = httpresponse.getStatusLine().getStatusCode();
        httpentity = httpresponse.getEntity();
        if (httpentity == null)
        {
            break MISSING_BLOCK_LABEL_591;
        }
        if (ResponseCode != 200)
        {
            break MISSING_BLOCK_LABEL_591;
        }
        Response = EntityUtils.toString(httpentity);
        try
        {
            jToken = new JSONTokener(Response);
            jObject = new JSONObject(jToken);
            if (!jName.equals(""))
            {
                jArray = jObject.getJSONArray(jName);
            }
        }
        catch (Exception exception2)
        {
            try
            {
                ResponseCode = 0;
                jObject = null;
                jArray = null;
            }
            catch (Exception exception)
            {
                Error = true;
                ErrorMessage = exception.getMessage();
            }
        }
          goto _L5
        Error = true;
        ErrorMessage = "Ba\u011Flant\u0131 Sa\u011Flanamad\u0131!";
        k++;
          goto _L9
        Exception exception1;
        exception1;
          goto _L1
    }

    protected volatile void onPostExecute(Object obj)
    {
        onPostExecute((String)obj);
    }

    protected void onPostExecute(String s)
    {
        Iterator iterator = callbacks.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                return;
            }
            ((Callback)iterator.next()).onComplete(Action, s, ResponseCode, Boolean.valueOf(Error), ErrorMessage);
        } while (true);
    }
}
