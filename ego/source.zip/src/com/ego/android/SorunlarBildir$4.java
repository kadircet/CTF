// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.location.Location;
import android.widget.TextView;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            SorunlarBildir, Gps, Map

class this._cls0
    implements this._cls0
{

    final SorunlarBildir this$0;

    public void onComplete(Location location)
    {
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (location == null)
        {
            try
            {
                Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                return;
            }
            catch (Exception exception1)
            {
                return;
            }
        }
        if (gps.GpsAdres.equals(""))
        {
            Toast.makeText(getBaseContext(), "Adres Bulunamad\u0131!", 1).show();
            return;
        }
        SorunlarBildir.this.location = true;
        locationPosition = Map.GP((new StringBuilder()).append(location.getLatitude()).toString(), (new StringBuilder()).append(location.getLongitude()).toString());
        locationAdres = gps.GpsAdres;
        locationIlce = gps.GpsIlce;
        ((TextView)findViewById(0x7f09006d)).setText((new StringBuilder(String.valueOf(locationAdres))).append("\n").append(locationIlce).toString());
        Toast.makeText(getBaseContext(), (new StringBuilder("Konumum\n\n")).append(locationAdres).append("\n").append(locationIlce).toString(), 1).show();
        return;
    }

    ()
    {
        this$0 = SorunlarBildir.this;
        super();
    }
}
