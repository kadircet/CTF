// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.HashMap;

// Referenced classes of package com.ego.android:
//            FavorilerimHat, Global, FavorilerimHatDuzenle

class this._cls0
    implements android.widget.mLongClickListener
{

    final FavorilerimHat this$0;

    public boolean onItemLongClick(AdapterView adapterview, View view, int i, long l)
    {
        Global.App_Favorilerim_Hat_No = (String)((HashMap)((ListView)findViewById(0x7f09002a)).getItemAtPosition(i)).get("no");
        Intent intent = new Intent(getBaseContext(), com/ego/android/FavorilerimHatDuzenle);
        startActivityForResult(intent, 0);
        return true;
    }

    enle()
    {
        this$0 = FavorilerimHat.this;
        super();
    }
}
