// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.location.Location;
import android.widget.Toast;
import java.util.ArrayList;

// Referenced classes of package com.ego.android:
//            AdresAra, Geo

class this._cls0
    implements k
{

    final AdresAra this$0;

    public void onComplete(Location location)
    {
        try
        {
            dialog.dismiss();
        }
        catch (Exception exception) { }
        if (location == null)
        {
            try
            {
                Toast.makeText(getBaseContext(), "Konumunuz Belirlenemedi!\nGps Ayarlar\u0131n\u0131z\u0131 Kontrol Ediniz.", 1).show();
                return;
            }
            catch (Exception exception1)
            {
                return;
            }
        }
        geo = new Geo("Location");
        geo.addObserver(new Geo.Callback() {

            final AdresAra._cls5 this$1;

            public void onComplete(String s, ArrayList arraylist)
            {
                GeoAction(s, arraylist);
            }

            
            {
                this$1 = AdresAra._cls5.this;
                super();
            }
        });
        dialog.show();
        geo.LatLng((new StringBuilder()).append(location.getLatitude()).toString(), (new StringBuilder()).append(location.getLongitude()).toString());
        return;
    }


    _cls1.this._cls1()
    {
        this$0 = AdresAra.this;
        super();
    }
}
