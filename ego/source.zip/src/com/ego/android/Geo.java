// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.ego.android:
//            Http

public class Geo
{
    public static interface Callback
    {

        public abstract void onComplete(String s, ArrayList arraylist);
    }


    public String Action;
    String ServiceAddressUri;
    String ServiceLatLngUri;
    private Set callbacks;
    Http http;

    public Geo()
    {
        Action = "";
        ServiceAddressUri = "http://maps.googleapis.com/maps/api/geocode/json?address=";
        ServiceLatLngUri = "http://maps.googleapis.com/maps/api/geocode/json?latlng=";
        callbacks = new HashSet();
        Action = "";
    }

    public Geo(String s)
    {
        Action = "";
        ServiceAddressUri = "http://maps.googleapis.com/maps/api/geocode/json?address=";
        ServiceLatLngUri = "http://maps.googleapis.com/maps/api/geocode/json?latlng=";
        callbacks = new HashSet();
        Action = s;
    }

    public void Action(String s, String s1, int i, Boolean boolean1, String s2)
    {
        if (i != 200) goto _L2; else goto _L1
_L1:
        if (!s.equals("Address") && !s.equals("LatLng")) goto _L4; else goto _L3
_L3:
        ArrayList arraylist;
        int j;
        int k;
        HashMap hashmap1;
        arraylist = new ArrayList();
        HashMap hashmap = new HashMap();
        j = 0;
        k = 0;
        hashmap1 = hashmap;
_L12:
        int l = http.jArray.length();
        if (k < l) goto _L6; else goto _L5
_L5:
        hashmap1;
_L11:
        Iterator iterator1 = callbacks.iterator();
_L14:
        if (iterator1.hasNext()) goto _L7; else goto _L4
_L4:
        return;
_L6:
        String s3;
        String s4;
        s3 = "";
        s4 = "";
        JSONObject jsonobject;
        JSONArray jsonarray;
        jsonobject = http.jArray.getJSONObject(k);
        if (jsonobject.getString("formatted_address").indexOf("Ankara") == -1)
        {
            break MISSING_BLOCK_LABEL_557;
        }
        jsonarray = jsonobject.getJSONArray("address_components");
        int i1 = 0;
_L13:
        if (i1 < jsonarray.length()) goto _L9; else goto _L8
_L8:
        String s5;
        int j1;
        if (s3.equals(""))
        {
            break MISSING_BLOCK_LABEL_557;
        }
        s5 = jsonobject.getString("formatted_address").replace(" Ankara, T\374rkiye", "").replace("/Ankara, T\374rkiye", "");
        j1 = s5.indexOf(", 06");
        if (j1 == -1)
        {
            break MISSING_BLOCK_LABEL_229;
        }
        if (j1 + 7 == s5.length())
        {
            s5 = s5.split(", 06")[0];
        }
        HashMap hashmap2;
        String s6;
        String s7;
        s6 = jsonobject.getJSONObject("geometry").getJSONObject("location").getString("lat");
        s7 = jsonobject.getJSONObject("geometry").getJSONObject("location").getString("lng");
        hashmap2 = new HashMap();
        hashmap2.put("id", (new StringBuilder()).append(j).toString());
        hashmap2.put("adres", s5);
        hashmap2.put("ilce", s3);
        hashmap2.put("tip", s4);
        hashmap2.put("lat", s6);
        hashmap2.put("lng", s7);
        arraylist.add(hashmap2);
        j++;
        boolean flag = s.equals("LatLng");
        if (flag) goto _L11; else goto _L10
_L10:
        k++;
        hashmap1 = hashmap2;
          goto _L12
_L9:
        String s8;
        JSONObject jsonobject1 = jsonarray.getJSONObject(i1);
        s4 = jsonobject1.getString("types");
        if (s4.indexOf("sublocality") != -1)
        {
            s3 = jsonobject1.getString("long_name");
        }
        if (s4.indexOf("administrative_area_level_1") != -1)
        {
            s3 = jsonobject1.getString("long_name");
        }
        if (s4.indexOf("administrative_area_level_2") == -1)
        {
            break MISSING_BLOCK_LABEL_470;
        }
        s8 = jsonobject1.getString("long_name");
        s3 = s8;
          goto _L8
        Exception exception2;
        exception2;
        i1++;
          goto _L13
_L7:
        ((Callback)iterator1.next()).onComplete(Action, arraylist);
          goto _L14
_L2:
        Iterator iterator = callbacks.iterator();
        while (iterator.hasNext()) 
        {
            ((Callback)iterator.next()).onComplete(Action, null);
        }
          goto _L4
        Exception exception;
        exception;
        hashmap1;
          goto _L11
        Exception exception1;
        exception1;
          goto _L11
        hashmap2 = hashmap1;
          goto _L10
    }

    public void Address(String s)
    {
        String s1 = ServiceAddressUri;
        String s2 = (new StringBuilder(String.valueOf(s1))).append(URLEncoder.encode((new StringBuilder(String.valueOf(s))).append("+Ankara+T\374rkiye").toString(), "UTF-8")).append("&sensor=false&language=tr").toString();
        s1 = s2;
_L2:
        http = new Http("Address", s1, new String[0], new String[0]);
        http.jName = "results";
        http.addObserver(new Http.Callback() {

            final Geo this$0;

            public void onComplete(String s3, String s4, int i, Boolean boolean1, String s5)
            {
                Action(s3, s4, i, boolean1, s5);
            }

            
            {
                this$0 = Geo.this;
                super();
            }
        });
        http.execute(new String[0]);
        return;
        Exception exception;
        exception;
        if (true) goto _L2; else goto _L1
_L1:
    }

    public void LatLng(String s, String s1)
    {
        http = new Http("LatLng", (new StringBuilder(String.valueOf(ServiceLatLngUri))).append(s).append(",").append(s1).append("&sensor=false&language=tr").toString(), new String[0], new String[0]);
        http.jName = "results";
        http.addObserver(new Http.Callback() {

            final Geo this$0;

            public void onComplete(String s2, String s3, int i, Boolean boolean1, String s4)
            {
                Action(s2, s3, i, boolean1, s4);
            }

            
            {
                this$0 = Geo.this;
                super();
            }
        });
        http.execute(new String[0]);
    }

    public void addObserver(Callback callback)
    {
        callbacks.add(callback);
    }
}
