// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Handler;
import android.text.Editable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

// Referenced classes of package com.ego.android:
//            Alarm, Global, Http

class this._cls0
    implements Runnable
{

    final Alarm this$0;

    public void run()
    {
label0:
        {
label1:
            {
                try
                {
                    handler.removeCallbacks(handlerRunnable);
                }
                catch (Exception exception) { }
                if (Global.App_Alarm_Acik)
                {
                    if (!handlerStatus)
                    {
                        break label0;
                    }
                    String s = ((EditText)findViewById(0x7f090007)).getText().toString();
                    String s1 = ((EditText)findViewById(0x7f090009)).getText().toString();
                    handlerStatus = false;
                    if (!s.equals(""))
                    {
                        ((LinearLayout)findViewById(0x7f09000f)).setVisibility(8);
                    } else
                    {
                        ((LinearLayout)findViewById(0x7f09000f)).setVisibility(0);
                    }
                    if (s1.equals(""))
                    {
                        break label1;
                    }
                    if (!s.equals(""))
                    {
                        http = new Http("OtobusAra", "hat.asp", new String[] {
                            "FNC", "OtobusAra"
                        }, new String[] {
                            "QUERY", s, "DURAK", s1, "TYPE", "true"
                        });
                    } else
                    {
                        http = new Http("OtobusDurakAra", "durak.asp", new String[] {
                            "FNC", "DurakAra"
                        }, new String[] {
                            "QUERY", s1, "HATNO", s, "TYPE", "true"
                        });
                    }
                    http.addObserver(new Http.Callback() {

                        final Alarm._cls7 this$1;

                        public void onComplete(String s2, String s3, int i, Boolean boolean1, String s4)
                        {
                            Action(s2, s3, i, boolean1, s4);
                        }

            
            {
                this$1 = Alarm._cls7.this;
                super();
            }
                    });
                    dialog.show();
                    http.execute(new String[0]);
                    ((Button)findViewById(0x7f090011)).setBackgroundColor(Color.parseColor("#FF009900"));
                }
                return;
            }
            Toast.makeText(getBaseContext(), "Durak Numaras\u0131n\u0131 Giriniz!", 1).show();
            return;
        }
        handlerStop();
    }


    _cls1.this._cls1()
    {
        this$0 = Alarm.this;
        super();
    }
}
