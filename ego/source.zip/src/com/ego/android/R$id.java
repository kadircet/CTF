// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.ego.android;


// Referenced classes of package com.ego.android:
//            R

public static final class 
{

    public static final int Aciklama = 0x7f090037;
    public static final int Ad = 0x7f09003a;
    public static final int AdSoyad = 0x7f090013;
    public static final int Adres = 0x7f09006f;
    public static final int Aktif = 0x7f090066;
    public static final int Ara = 0x7f090000;
    public static final int Baslik = 0x7f09002e;
    public static final int Birim = 0x7f090068;
    public static final int Button1 = 0x7f090022;
    public static final int Button2 = 0x7f090023;
    public static final int Button3 = 0x7f090024;
    public static final int Button4 = 0x7f090025;
    public static final int Button5 = 0x7f090026;
    public static final int Button6 = 0x7f090027;
    public static final int Button7 = 0x7f090028;
    public static final int ButtonClose = 0x7f090020;
    public static final int ButtonOk = 0x7f090029;
    public static final int CELL_1 = 0x7f090045;
    public static final int CELL_1A = 0x7f09004c;
    public static final int CELL_1_BTN = 0x7f090053;
    public static final int CELL_1_COLOR = 0x7f090051;
    public static final int CELL_1_TEXT = 0x7f090054;
    public static final int CELL_1_TITLE = 0x7f090052;
    public static final int CELL_2 = 0x7f090046;
    public static final int CELL_2A = 0x7f09004d;
    public static final int CELL_2_BTN = 0x7f090057;
    public static final int CELL_2_COLOR = 0x7f090055;
    public static final int CELL_2_TEXT = 0x7f090058;
    public static final int CELL_2_TITLE = 0x7f090056;
    public static final int CELL_3 = 0x7f090048;
    public static final int CELL_3A = 0x7f09004e;
    public static final int CELL_4 = 0x7f090049;
    public static final int CELL_5 = 0x7f09004a;
    public static final int CELL_6 = 0x7f09004b;
    public static final int CELL_7 = 0x7f09004f;
    public static final int CELL_8 = 0x7f090050;
    public static final int CELL_BTN = 0x7f090047;
    public static final int DaraltGenisle = 0x7f090005;
    public static final int Detay = 0x7f09002f;
    public static final int DurakNo = 0x7f090009;
    public static final int DurakTanim = 0x7f09000a;
    public static final int EPosta = 0x7f090015;
    public static final int Fotograf1 = 0x7f09006b;
    public static final int Fotograf2 = 0x7f09006c;
    public static final int Hat = 0x7f09003f;
    public static final int Hat1 = 0x7f090060;
    public static final int Hat2 = 0x7f090061;
    public static final int HatNo = 0x7f090007;
    public static final int HatTanim = 0x7f090008;
    public static final int Ilce = 0x7f090070;
    public static final int Kategori = 0x7f09002c;
    public static final int Kayit = 0x7f090063;
    public static final int Klavye = 0x7f090039;
    public static final int Konu = 0x7f090069;
    public static final int Konum = 0x7f09006d;
    public static final int LinearLayoutHat = 0x7f09000f;
    public static final int LinearLayoutOtobus = 0x7f090064;
    public static final int Link = 0x7f090030;
    public static final int ListViewAdres = 0x7f090002;
    public static final int ListViewAyarlar = 0x7f090016;
    public static final int ListViewDetay = 0x7f09005f;
    public static final int ListViewDurak = 0x7f090033;
    public static final int ListViewDuyuru = 0x7f09002b;
    public static final int ListViewHat = 0x7f09002a;
    public static final int ListViewMenu = 0x7f090067;
    public static final int ListViewOnemliYer = 0x7f090062;
    public static final int ListViewOtobus = 0x7f090010;
    public static final int ListViewPanel = 0x7f090065;
    public static final int ListViewSaat = 0x7f09003d;
    public static final int ListViewSorun = 0x7f09006e;
    public static final int Map = 0x7f090003;
    public static final int Mesafe = 0x7f09003c;
    public static final int Nereden = 0x7f090059;
    public static final int NeredenIlce = 0x7f09005c;
    public static final int Nereye = 0x7f09005a;
    public static final int NereyeIlce = 0x7f09005d;
    public static final int No = 0x7f090035;
    public static final int OtobusBilgisi = 0x7f090040;
    public static final int OtobusBilgisiText = 0x7f090041;
    public static final int Panel = 0x7f090006;
    public static final int Pause = 0x7f090012;
    public static final int Play = 0x7f090011;
    public static final int Renk = 0x7f090038;
    public static final int Sec = 0x7f090004;
    public static final int Siralama = 0x7f09005b;
    public static final int Sorun = 0x7f09006a;
    public static final int Sure = 0x7f09003b;
    public static final int Tanim = 0x7f090036;
    public static final int Tarih = 0x7f09002d;
    public static final int Telefon = 0x7f090014;
    public static final int Text = 0x7f090021;
    public static final int Title = 0x7f09001f;
    public static final int Tur = 0x7f09005e;
    public static final int Type = 0x7f090001;
    public static final int Yaklasma = 0x7f09000d;
    public static final int Yenile = 0x7f090042;
    public static final int Yenileme = 0x7f09000b;
    public static final int action_settings = 0x7f090071;
    public static final int balloon_button_1 = 0x7f09001c;
    public static final int balloon_button_2 = 0x7f09001d;
    public static final int balloon_button_3 = 0x7f09001e;
    public static final int balloon_inner_layout = 0x7f090018;
    public static final int balloon_item_snippet = 0x7f09001a;
    public static final int balloon_item_title = 0x7f090019;
    public static final int balloon_main_layout = 0x7f090017;
    public static final int close_img_button = 0x7f09001b;
    public static final int group1 = 0x7f090072;
    public static final int item1 = 0x7f090073;
    public static final int item2 = 0x7f090074;
    public static final int seekBar = 0x7f090043;
    public static final int seekBarNumber = 0x7f090044;
    public static final int seekBarYaklasma = 0x7f09000e;
    public static final int seekBarYenileme = 0x7f09000c;
    public static final int tabcontent1 = 0x7f090032;
    public static final int tabcontent2 = 0x7f090034;
    public static final int tabcontent3 = 0x7f09003e;
    public static final int tabhost = 0x7f090031;

    public ()
    {
    }
}
