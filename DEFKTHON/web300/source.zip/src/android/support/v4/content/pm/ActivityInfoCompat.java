// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.content.pm;


public class ActivityInfoCompat
{

    public static final int CONFIG_UI_MODE = 512;

    private ActivityInfoCompat()
    {
    }
}
