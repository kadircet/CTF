// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.content;

import android.content.Intent;

// Referenced classes of package android.support.v4.content:
//            IntentCompatIcsMr1, IntentCompat

static class  extends 
{

    public Intent makeMainSelectorActivity(String s, String s1)
    {
        return IntentCompatIcsMr1.makeMainSelectorActivity(s, s1);
    }

    ()
    {
    }
}
