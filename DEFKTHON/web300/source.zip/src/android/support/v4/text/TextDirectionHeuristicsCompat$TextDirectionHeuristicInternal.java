// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.text;


// Referenced classes of package android.support.v4.text:
//            TextDirectionHeuristicsCompat

private static class <init> extends <init>
{

    private final boolean mDefaultIsRtl;

    protected boolean defaultIsRtl()
    {
        return mDefaultIsRtl;
    }

    private ( , boolean flag)
    {
        super();
        mDefaultIsRtl = flag;
    }

    mDefaultIsRtl(mDefaultIsRtl mdefaultisrtl, boolean flag, mDefaultIsRtl mdefaultisrtl1)
    {
        this(mdefaultisrtl, flag);
    }
}
