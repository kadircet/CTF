// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.widget;


// Referenced classes of package android.support.v4.widget:
//            SearchViewCompat

class val.listener
    implements idge
{

    final val.listener this$0;
    final val.listener val$listener;

    public boolean onClose()
    {
        return val$listener.listener();
    }

    idge()
    {
        this$0 = final_idge;
        val$listener = val.listener.this;
        super();
    }
}
