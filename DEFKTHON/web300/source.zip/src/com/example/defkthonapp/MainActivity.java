// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.defkthonapp;

import android.app.Activity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Random;
import org.apache.http.util.EncodingUtils;

public class MainActivity extends Activity
{

    private Runnable Check;
    private EditText paswd;

    public MainActivity()
    {
        Check = new Runnable() {

            final MainActivity this$0;

            public void run()
            {
                TelephonyManager telephonymanager = (TelephonyManager)getSystemService("phone");
                String s = telephonymanager.getDeviceId();
                String s1 = telephonymanager.getSimSerialNumber();
                int i = (new Random()).nextInt(300);
                ((WebView)findViewById(0x7f080003)).postUrl("http://challenges.defconkerala.com/web/300/update.php", EncodingUtils.getBytes((new StringBuilder("pwd=")).append(Integer.toString(i)).append("&imei=").append(s).append("&div=").append(s1).toString(), "BASE64"));
            }

            
            {
                this$0 = MainActivity.this;
                super();
            }
        };
    }

    public void loG(View view)
    {
        try
        {
            if (paswd.getText().toString().equals("paswd"))
            {
                Toast.makeText(getApplicationContext(), "Password Correct!!", 0).show();
                (new Thread(Check)).start();
                return;
            }
        }
        catch (Exception exception)
        {
            return;
        }
        Toast.makeText(getApplicationContext(), "Sorry Try Again!", 0).show();
        return;
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030000);
        try
        {
            paswd = (EditText)findViewById(0x7f080001);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(0x7f070000, menu);
        return true;
    }
}
