// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.defkthonapp;

import android.telephony.TelephonyManager;
import android.webkit.WebView;
import java.util.Random;
import org.apache.http.util.EncodingUtils;

// Referenced classes of package com.example.defkthonapp:
//            MainActivity

class this._cls0
    implements Runnable
{

    final MainActivity this$0;

    public void run()
    {
        TelephonyManager telephonymanager = (TelephonyManager)getSystemService("phone");
        String s = telephonymanager.getDeviceId();
        String s1 = telephonymanager.getSimSerialNumber();
        int i = (new Random()).nextInt(300);
        ((WebView)findViewById(0x7f080003)).postUrl("http://challenges.defconkerala.com/web/300/update.php", EncodingUtils.getBytes((new StringBuilder("pwd=")).append(Integer.toString(i)).append("&imei=").append(s).append("&div=").append(s1).toString(), "BASE64"));
    }

    ()
    {
        this$0 = MainActivity.this;
        super();
    }
}
