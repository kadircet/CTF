// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.defkthonapp;


public final class R
{
    public static final class attr
    {

        public attr()
        {
        }
    }

    public static final class dimen
    {

        public static final int activity_horizontal_margin = 0x7f040000;
        public static final int activity_vertical_margin = 0x7f040001;

        public dimen()
        {
        }
    }

    public static final class drawable
    {

        public static final int ic_launcher = 0x7f020000;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int action_settings = 0x7f080004;
        public static final int button1 = 0x7f080002;
        public static final int pass = 0x7f080001;
        public static final int passwrd = 0x7f080000;
        public static final int webview = 0x7f080003;

        public id()
        {
        }
    }

    public static final class layout
    {

        public static final int activity_main = 0x7f030000;

        public layout()
        {
        }
    }

    public static final class menu
    {

        public static final int main = 0x7f070000;

        public menu()
        {
        }
    }

    public static final class string
    {

        public static final int action_settings = 0x7f050001;
        public static final int app_name = 0x7f050000;
        public static final int hello_world = 0x7f050002;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int AppBaseTheme = 0x7f060000;
        public static final int AppTheme = 0x7f060001;

        public style()
        {
        }
    }


    public R()
    {
    }
}
